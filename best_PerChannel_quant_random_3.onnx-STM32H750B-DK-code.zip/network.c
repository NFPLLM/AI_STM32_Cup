/**
  ******************************************************************************
  * @file    network.c
  * @author  AST Embedded Analytics Research Platform
  * @date    2025-10-24T02:03:13+0000
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */


#include "network.h"
#include "network_data.h"

#include "ai_platform.h"
#include "ai_platform_interface.h"
#include "ai_math_helpers.h"

#include "core_common.h"
#include "core_convert.h"

#include "layers.h"



#undef AI_NET_OBJ_INSTANCE
#define AI_NET_OBJ_INSTANCE g_network
 
#undef AI_NETWORK_MODEL_SIGNATURE
#define AI_NETWORK_MODEL_SIGNATURE     "0x2a61b20c27e81e0a1616038d19cb87af"

#ifndef AI_TOOLS_REVISION_ID
#define AI_TOOLS_REVISION_ID     ""
#endif

#undef AI_TOOLS_DATE_TIME
#define AI_TOOLS_DATE_TIME   "2025-10-24T02:03:13+0000"

#undef AI_TOOLS_COMPILE_TIME
#define AI_TOOLS_COMPILE_TIME    __DATE__ " " __TIME__

#undef AI_NETWORK_N_BATCHES
#define AI_NETWORK_N_BATCHES         (1)

static ai_ptr g_network_activations_map[1] = AI_C_ARRAY_INIT;
static ai_ptr g_network_weights_map[1] = AI_C_ARRAY_INIT;



/**  Array declarations section  **********************************************/
/* Array#0 */
AI_ARRAY_OBJ_DECLARE(
  images_output_array, AI_ARRAY_FORMAT_S8|AI_FMT_FLAG_IS_IO,
  NULL, NULL, 76800, AI_STATIC)

/* Array#1 */
AI_ARRAY_OBJ_DECLARE(
  images_Transpose_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 76801, AI_STATIC)

/* Array#2 */
AI_ARRAY_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 102400, AI_STATIC)

/* Array#3 */
AI_ARRAY_OBJ_DECLARE(
  _model_0_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 102400, AI_STATIC)

/* Array#4 */
AI_ARRAY_OBJ_DECLARE(
  _model_0_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 102400, AI_STATIC)

/* Array#5 */
AI_ARRAY_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#6 */
AI_ARRAY_OBJ_DECLARE(
  _model_1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#7 */
AI_ARRAY_OBJ_DECLARE(
  _model_1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#8 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#9 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#10 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#11 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#12 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#13 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 28224, AI_STATIC)

/* Array#14 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#15 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#16 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#17 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 28224, AI_STATIC)

/* Array#18 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#19 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#20 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#21 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_Add_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#22 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 76800, AI_STATIC)

/* Array#23 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#24 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#25 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#26 */
AI_ARRAY_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 56448, AI_STATIC)

/* Array#27 */
AI_ARRAY_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#28 */
AI_ARRAY_OBJ_DECLARE(
  _model_3_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#29 */
AI_ARRAY_OBJ_DECLARE(
  _model_3_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#30 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#31 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#32 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#33 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#34 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#35 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15488, AI_STATIC)

/* Array#36 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#37 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#38 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#39 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15488, AI_STATIC)

/* Array#40 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#41 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#42 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#43 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_Add_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#44 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15488, AI_STATIC)

/* Array#45 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#46 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#47 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#48 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15488, AI_STATIC)

/* Array#49 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#50 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#51 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#52 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_Add_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#53 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#54 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#55 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#56 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#57 */
AI_ARRAY_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 30976, AI_STATIC)

/* Array#58 */
AI_ARRAY_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#59 */
AI_ARRAY_OBJ_DECLARE(
  _model_5_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#60 */
AI_ARRAY_OBJ_DECLARE(
  _model_5_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#61 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#62 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#63 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#64 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#65 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#66 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#67 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#68 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#69 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#70 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#71 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#72 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#73 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#74 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_Add_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#75 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#76 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#77 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#78 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#79 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#80 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#81 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#82 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#83 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_Add_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#84 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#85 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#86 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#87 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#88 */
AI_ARRAY_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 18432, AI_STATIC)

/* Array#89 */
AI_ARRAY_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#90 */
AI_ARRAY_OBJ_DECLARE(
  _model_7_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#91 */
AI_ARRAY_OBJ_DECLARE(
  _model_7_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#92 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#93 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#94 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#95 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#96 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#97 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6272, AI_STATIC)

/* Array#98 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#99 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#100 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#101 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6272, AI_STATIC)

/* Array#102 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#103 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#104 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#105 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_Add_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#106 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9600, AI_STATIC)

/* Array#107 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#108 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#109 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#110 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#111 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#112 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#113 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_m_MaxPool_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#114 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_m_1_MaxPool_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#115 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_m_2_MaxPool_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#116 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#117 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#118 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#119 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#120 */
AI_ARRAY_OBJ_DECLARE(
  _model_10_Resize_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#121 */
AI_ARRAY_OBJ_DECLARE(
  _model_11_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 38400, AI_STATIC)

/* Array#122 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#123 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#124 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#125 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#126 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#127 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#128 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#129 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#130 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#131 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#132 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#133 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#134 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#135 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 19200, AI_STATIC)

/* Array#136 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#137 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#138 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#139 */
AI_ARRAY_OBJ_DECLARE(
  _model_13_Resize_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 51200, AI_STATIC)

/* Array#140 */
AI_ARRAY_OBJ_DECLARE(
  _model_14_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 76800, AI_STATIC)

/* Array#141 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#142 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#143 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#144 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#145 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#146 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15488, AI_STATIC)

/* Array#147 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#148 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#149 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#150 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15488, AI_STATIC)

/* Array#151 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#152 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#153 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#154 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 38400, AI_STATIC)

/* Array#155 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#156 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#157 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#158 */
AI_ARRAY_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 30976, AI_STATIC)

/* Array#159 */
AI_ARRAY_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#160 */
AI_ARRAY_OBJ_DECLARE(
  _model_16_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#161 */
AI_ARRAY_OBJ_DECLARE(
  _model_16_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#162 */
AI_ARRAY_OBJ_DECLARE(
  _model_17_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 19200, AI_STATIC)

/* Array#163 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#164 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#165 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#166 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#167 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#168 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#169 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#170 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#171 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#172 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#173 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#174 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#175 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#176 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 19200, AI_STATIC)

/* Array#177 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#178 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#179 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12800, AI_STATIC)

/* Array#180 */
AI_ARRAY_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 18432, AI_STATIC)

/* Array#181 */
AI_ARRAY_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#182 */
AI_ARRAY_OBJ_DECLARE(
  _model_19_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#183 */
AI_ARRAY_OBJ_DECLARE(
  _model_19_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#184 */
AI_ARRAY_OBJ_DECLARE(
  _model_20_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9600, AI_STATIC)

/* Array#185 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#186 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#187 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#188 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#189 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#190 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6272, AI_STATIC)

/* Array#191 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#192 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#193 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#194 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6272, AI_STATIC)

/* Array#195 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#196 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#197 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3200, AI_STATIC)

/* Array#198 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9600, AI_STATIC)

/* Array#199 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#200 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv2_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#201 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv2_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#202 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12544, AI_STATIC)

/* Array#203 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#204 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#205 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#206 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3136, AI_STATIC)

/* Array#207 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#208 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#209 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#210 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25, AI_STATIC)

/* Array#211 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12544, AI_STATIC)

/* Array#212 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#213 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#214 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#215 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3136, AI_STATIC)

/* Array#216 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#217 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#218 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#219 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1600, AI_STATIC)

/* Array#220 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Concat_2_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1625, AI_STATIC)

/* Array#221 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 18432, AI_STATIC)

/* Array#222 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#223 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#224 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#225 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#226 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#227 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#228 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#229 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 100, AI_STATIC)

/* Array#230 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 18432, AI_STATIC)

/* Array#231 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#232 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#233 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#234 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#235 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#236 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#237 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#238 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6400, AI_STATIC)

/* Array#239 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Concat_1_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6500, AI_STATIC)

/* Array#240 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 30976, AI_STATIC)

/* Array#241 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#242 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#243 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#244 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 30976, AI_STATIC)

/* Array#245 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#246 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#247 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#248 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 400, AI_STATIC)

/* Array#249 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 30976, AI_STATIC)

/* Array#250 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#251 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#252 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#253 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 30976, AI_STATIC)

/* Array#254 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#255 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#256 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Mul_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#257 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 25600, AI_STATIC)

/* Array#258 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Concat_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 26000, AI_STATIC)

/* Array#259 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Concat_3_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 34125, AI_STATIC)

/* Array#260 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Split_output_0_output0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 33600, AI_STATIC)

/* Array#261 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Split_output_0_output1_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 525, AI_STATIC)

/* Array#262 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chlast_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 33600, AI_STATIC)

/* Array#263 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 33600, AI_STATIC)

/* Array#264 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 33600, AI_STATIC)

/* Array#265 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Softmax_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 33600, AI_STATIC)

/* Array#266 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 33600, AI_STATIC)

/* Array#267 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Transpose_1_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 33600, AI_STATIC)

/* Array#268 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2100, AI_STATIC)

/* Array#269 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chlast_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2100, AI_STATIC)

/* Array#270 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chfirst_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2100, AI_STATIC)

/* Array#271 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Slice_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#272 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1050, AI_STATIC)

/* Array#273 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Slice_1_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#274 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Add_1_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#275 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Sigmoid_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 525, AI_STATIC)

/* Array#276 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Sub_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1050, AI_STATIC)

/* Array#277 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#278 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Sub_1_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#279 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Add_2_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#280 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1050, AI_STATIC)

/* Array#281 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Div_1_output_0_output_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1050, AI_STATIC)

/* Array#282 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#283 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Concat_4_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2100, AI_STATIC)

/* Array#284 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Mul_2_output_0_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2100, AI_STATIC)

/* Array#285 */
AI_ARRAY_OBJ_DECLARE(
  output0_QuantizeLinear_Input_output_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2625, AI_STATIC)

/* Array#286 */
AI_ARRAY_OBJ_DECLARE(
  output0_QuantizeLinear_Input_Transpose_0_output_array, AI_ARRAY_FORMAT_S8|AI_FMT_FLAG_IS_IO,
  NULL, NULL, 2625, AI_STATIC)

/* Array#287 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Constant_11_output_0_3D_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1, AI_STATIC)

/* Array#288 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 525, AI_STATIC)

/* Array#289 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Constant_10_output_0_DequantizeLinear_Output_const_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1050, AI_STATIC)

/* Array#290 */
AI_ARRAY_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 432, AI_STATIC)

/* Array#291 */
AI_ARRAY_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 16, AI_STATIC)

/* Array#292 */
AI_ARRAY_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4608, AI_STATIC)

/* Array#293 */
AI_ARRAY_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#294 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1024, AI_STATIC)

/* Array#295 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#296 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#297 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2304, AI_STATIC)

/* Array#298 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 16, AI_STATIC)

/* Array#299 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2304, AI_STATIC)

/* Array#300 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 16, AI_STATIC)

/* Array#301 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1536, AI_STATIC)

/* Array#302 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#303 */
AI_ARRAY_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 18432, AI_STATIC)

/* Array#304 */
AI_ARRAY_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#305 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4096, AI_STATIC)

/* Array#306 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#307 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#308 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#309 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#310 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#311 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#312 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#313 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#314 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#315 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#316 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8192, AI_STATIC)

/* Array#317 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#318 */
AI_ARRAY_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 73728, AI_STATIC)

/* Array#319 */
AI_ARRAY_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#320 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 16384, AI_STATIC)

/* Array#321 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#322 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#323 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#324 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#325 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#326 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#327 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#328 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#329 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#330 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#331 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 32768, AI_STATIC)

/* Array#332 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#333 */
AI_ARRAY_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 294912, AI_STATIC)

/* Array#334 */
AI_ARRAY_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 256, AI_STATIC)

/* Array#335 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 65536, AI_STATIC)

/* Array#336 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 256, AI_STATIC)

/* Array#337 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#338 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 147456, AI_STATIC)

/* Array#339 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#340 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 147456, AI_STATIC)

/* Array#341 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#342 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 98304, AI_STATIC)

/* Array#343 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 256, AI_STATIC)

/* Array#344 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 32768, AI_STATIC)

/* Array#345 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#346 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 131072, AI_STATIC)

/* Array#347 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 256, AI_STATIC)

/* Array#348 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 49152, AI_STATIC)

/* Array#349 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#350 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#351 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#352 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#353 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#354 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#355 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 24576, AI_STATIC)

/* Array#356 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#357 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 12288, AI_STATIC)

/* Array#358 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#359 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#360 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#361 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#362 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#363 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 32, AI_STATIC)

/* Array#364 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6144, AI_STATIC)

/* Array#365 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#366 */
AI_ARRAY_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#367 */
AI_ARRAY_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#368 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 24576, AI_STATIC)

/* Array#369 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#370 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#371 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#372 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#373 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#374 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#375 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 24576, AI_STATIC)

/* Array#376 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#377 */
AI_ARRAY_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 147456, AI_STATIC)

/* Array#378 */
AI_ARRAY_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#379 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 98304, AI_STATIC)

/* Array#380 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 256, AI_STATIC)

/* Array#381 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#382 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 147456, AI_STATIC)

/* Array#383 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#384 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 147456, AI_STATIC)

/* Array#385 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 128, AI_STATIC)

/* Array#386 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 98304, AI_STATIC)

/* Array#387 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 256, AI_STATIC)

/* Array#388 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 147456, AI_STATIC)

/* Array#389 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#390 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#391 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#392 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 64, AI_STATIC)

/* Array#393 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#394 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 147456, AI_STATIC)

/* Array#395 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#396 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#397 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#398 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4096, AI_STATIC)

/* Array#399 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#400 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 73728, AI_STATIC)

/* Array#401 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#402 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#403 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#404 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 64, AI_STATIC)

/* Array#405 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#406 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 73728, AI_STATIC)

/* Array#407 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#408 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#409 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#410 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4096, AI_STATIC)

/* Array#411 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#412 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#413 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#414 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#415 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#416 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 64, AI_STATIC)

/* Array#417 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#418 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#419 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#420 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 36864, AI_STATIC)

/* Array#421 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#422 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4096, AI_STATIC)

/* Array#423 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 64, AI_STATIC)

/* Array#424 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Split_output_0_num_or_size_splits_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 2, AI_STATIC)

/* Array#425 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_weights_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 16, AI_STATIC)

/* Array#426 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_bias_array, AI_ARRAY_FORMAT_S32,
  NULL, NULL, 1, AI_STATIC)

/* Array#427 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_Constant_9_output_0_array, AI_ARRAY_FORMAT_FLOAT,
  NULL, NULL, 1050, AI_STATIC)

/* Array#428 */
AI_ARRAY_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1196, AI_STATIC)

/* Array#429 */
AI_ARRAY_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6144, AI_STATIC)

/* Array#430 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 448, AI_STATIC)

/* Array#431 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 5408, AI_STATIC)

/* Array#432 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 5408, AI_STATIC)

/* Array#433 */
AI_ARRAY_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 512, AI_STATIC)

/* Array#434 */
AI_ARRAY_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 7168, AI_STATIC)

/* Array#435 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 896, AI_STATIC)

/* Array#436 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6720, AI_STATIC)

/* Array#437 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6720, AI_STATIC)

/* Array#438 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6720, AI_STATIC)

/* Array#439 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6720, AI_STATIC)

/* Array#440 */
AI_ARRAY_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1152, AI_STATIC)

/* Array#441 */
AI_ARRAY_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 9216, AI_STATIC)

/* Array#442 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1792, AI_STATIC)

/* Array#443 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#444 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#445 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#446 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#447 */
AI_ARRAY_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2304, AI_STATIC)

/* Array#448 */
AI_ARRAY_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 13312, AI_STATIC)

/* Array#449 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 3584, AI_STATIC)

/* Array#450 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 11520, AI_STATIC)

/* Array#451 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 11520, AI_STATIC)

/* Array#452 */
AI_ARRAY_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4096, AI_STATIC)

/* Array#453 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2304, AI_STATIC)

/* Array#454 */
AI_ARRAY_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4608, AI_STATIC)

/* Array#455 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2816, AI_STATIC)

/* Array#456 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#457 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#458 */
AI_ARRAY_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2048, AI_STATIC)

/* Array#459 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1408, AI_STATIC)

/* Array#460 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6720, AI_STATIC)

/* Array#461 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 6720, AI_STATIC)

/* Array#462 */
AI_ARRAY_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 1024, AI_STATIC)

/* Array#463 */
AI_ARRAY_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#464 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2048, AI_STATIC)

/* Array#465 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#466 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#467 */
AI_ARRAY_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 2048, AI_STATIC)

/* Array#468 */
AI_ARRAY_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 11520, AI_STATIC)

/* Array#469 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4096, AI_STATIC)

/* Array#470 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 11520, AI_STATIC)

/* Array#471 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 11520, AI_STATIC)

/* Array#472 */
AI_ARRAY_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 4096, AI_STATIC)

/* Array#473 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15232, AI_STATIC)

/* Array#474 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#475 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 256, AI_STATIC)

/* Array#476 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 15232, AI_STATIC)

/* Array#477 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#478 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 896, AI_STATIC)

/* Array#479 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 10624, AI_STATIC)

/* Array#480 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#481 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 256, AI_STATIC)

/* Array#482 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 10624, AI_STATIC)

/* Array#483 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#484 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 896, AI_STATIC)

/* Array#485 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#486 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#487 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 256, AI_STATIC)

/* Array#488 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#489 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 8320, AI_STATIC)

/* Array#490 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 896, AI_STATIC)

/* Array#491 */
AI_ARRAY_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_scratch0_array, AI_ARRAY_FORMAT_S8,
  NULL, NULL, 64, AI_STATIC)

/**  Array metadata declarations section  *************************************/
/* Int quant #0 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_0_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.12946194410324097f),
    AI_PACK_INTQ_ZP(-126)))

/* Int quant #1 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_0_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921568859368563f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #2 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_0_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.25476816296577454f),
    AI_PACK_INTQ_ZP(-1)))

/* Int quant #3 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_0_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 16,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0966305285692215f, 0.2070993334054947f, 0.06591425836086273f, 0.08904452621936798f, 0.10190745443105698f, 0.05617127940058708f, 0.1038084626197815f, 0.03638365864753723f, 0.07723166048526764f, 0.08307578414678574f, 0.11393070966005325f, 0.20326824486255646f, 0.16467975080013275f, 0.09745227545499802f, 0.03618410602211952f, 0.07938796281814575f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #4 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_10_Resize_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016189144924283028f),
    AI_PACK_INTQ_ZP(-111)))

/* Int quant #5 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_11_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016189144924283028f),
    AI_PACK_INTQ_ZP(-111)))

/* Int quant #6 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01791539043188095f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #7 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0179153885692358f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #8 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0179153885692358f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #9 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0179153885692358f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #10 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003871379652991891f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #11 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05199653282761574f),
    AI_PACK_INTQ_ZP(43)))

/* Int quant #12 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00906942505389452f, 0.0037755814846605062f, 0.008743604645133018f, 0.008590790443122387f, 0.007000529672950506f, 0.006442703772336245f, 0.004545185249298811f, 0.00431543355807662f, 0.007161539979279041f, 0.002951019210740924f, 0.010804635472595692f, 0.007204935420304537f, 0.022751327604055405f, 0.00733784306794405f, 0.006487047765403986f, 0.0024176412262022495f, 0.005664413329213858f, 0.008157722651958466f, 0.011012928560376167f, 0.008921567350625992f, 0.006165755912661552f, 0.004265110474079847f, 0.0031294815707951784f, 0.009759031236171722f, 0.004914022516459227f, 0.005221020430326462f, 0.013648921623826027f, 0.00623129541054368f, 0.007031172048300505f, 0.0042329938150942326f, 0.008196679875254631f, 0.004122588783502579f, 0.007310299202799797f, 0.005275789648294449f, 0.008612649515271187f, 0.007028621155768633f, 0.004032739903777838f, 0.0032351387199014425f, 0.005059061571955681f, 0.0038421025965362787f, 0.0066979690454900265f, 0.005093619227409363f, 0.005360967479646206f, 0.007449908647686243f, 0.005607920698821545f, 0.004837839398533106f, 0.00303588155657053f, 0.005424561910331249f, 0.006091324612498283f, 0.010358501225709915f, 0.005961296614259481f, 0.0053489417769014835f, 0.0037854549009352922f, 0.0053913788869977f, 0.006371611263602972f, 0.006681241560727358f, 0.006403091363608837f, 0.005660390015691519f, 0.007904134690761566f, 0.007586567662656307f, 0.006769764702767134f, 0.0032096379436552525f, 0.003844338236376643f, 0.006798916961997747f, 0.005096161272376776f, 0.004481669049710035f, 0.006861111614853144f, 0.009038129821419716f, 0.005469617899507284f, 0.007154383696615696f, 0.003853385103866458f, 0.021945685148239136f, 0.005027918145060539f, 0.006436959840357304f, 0.007177688181400299f, 0.011716623790562153f, 0.005488563794642687f, 0.010752853006124496f, 0.0056594982743263245f, 0.006961459759622812f, 0.0057417708449065685f, 0.004104722756892443f, 0.006030628457665443f, 0.006408296059817076f, 0.008550607599318027f, 0.006181785371154547f, 0.014638719148933887f, 0.004949215333908796f, 0.005358934868127108f, 0.007029078900814056f, 0.006388634443283081f, 0.0026812972500920296f, 0.0048398952931165695f, 0.0162474624812603f, 0.0059017459861934185f, 0.00541423074901104f, 0.0075913723558187485f, 0.004394945222884417f, 0.00829151552170515f, 0.005682591814547777f, 0.007616895250976086f, 0.0037208718713372946f, 0.004941542632877827f, 0.00418202206492424f, 0.005216559860855341f, 0.005039824638515711f, 0.006340955384075642f, 0.0030586400534957647f, 0.004339711740612984f, 0.006219584960490465f, 0.004026510287076235f, 0.006748962681740522f, 0.00984662864357233f, 0.007546687498688698f, 0.023766273632645607f, 0.002391192829236388f, 0.005581576842814684f, 0.007982088252902031f, 0.005952545907348394f, 0.003459219355136156f, 0.003661270020529628f, 0.00526552926748991f, 0.004123958759009838f, 0.007536786142736673f, 0.006604328285902739f, 0.003208637936040759f, 0.008679134771227837f, 0.004219360649585724f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #13 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00980895385146141f),
    AI_PACK_INTQ_ZP(-100)))

/* Int quant #14 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0036014490760862827f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #15 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02280930057168007f),
    AI_PACK_INTQ_ZP(21)))

/* Int quant #16 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005212271586060524f, 0.004265377763658762f, 0.0042294105514883995f, 0.0034336328972131014f, 0.0027110311202704906f, 0.003923492040485144f, 0.004996195901185274f, 0.0019402586622163653f, 0.002566802315413952f, 0.00382816675119102f, 0.002775718690827489f, 0.003096179571002722f, 0.003195952856913209f, 0.0036530401557683945f, 0.003632491687312722f, 0.0024937372654676437f, 0.002795306034386158f, 0.001521382830105722f, 0.0038281516171991825f, 0.0019519004272297025f, 0.005307873245328665f, 0.004613695200532675f, 0.0043841213919222355f, 0.003807281842455268f, 0.005930950399488211f, 0.003199427155777812f, 0.0061167143285274506f, 0.002928021363914013f, 0.004987865220755339f, 0.003293609479442239f, 0.002997459378093481f, 0.004012862220406532f, 0.002551156561821699f, 0.0036542979069054127f, 0.0038732357788830996f, 0.0042953831143677235f, 0.003982161171734333f, 0.003683909075334668f, 0.002474637469276786f, 0.0030801985412836075f, 0.002233264734968543f, 0.00406505586579442f, 0.0058978162705898285f, 0.0013516921317204833f, 0.0033739195205271244f, 0.004676226992160082f, 0.005215509328991175f, 0.0017331632552668452f, 0.0063138073310256f, 0.006404198706150055f, 0.004459663759917021f, 0.0055231922306120396f, 0.005888982210308313f, 0.005712958984076977f, 0.0040805283933877945f, 0.0014115197118371725f, 0.004001629073172808f, 0.0049230982549488544f, 0.004235626198351383f, 0.0015056951669976115f, 0.001975986175239086f, 0.007528715301305056f, 0.0025784182362258434f, 0.004123861435800791f, 0.0026899862568825483f, 0.0023647930938750505f, 0.0035340304020792246f, 0.0018800485413521528f, 0.0029440296348184347f, 0.0035042236559093f, 0.0024280529469251633f, 0.0041362568736076355f, 0.0028170617297291756f, 0.002080619102343917f, 0.007345405872911215f, 0.005326110869646072f, 0.0027206139639019966f, 0.0011812167940661311f, 0.003085292875766754f, 0.0035574352368712425f, 0.0032265442423522472f, 0.0038291392847895622f, 0.0033837007358670235f, 0.0028705336153507233f, 0.003654400585219264f, 0.004462874494493008f, 0.0035706793423742056f, 0.007639996707439423f, 0.004643114749342203f, 0.005671269726008177f, 0.004232875071465969f, 0.00244241114705801f, 0.0034457335714250803f, 0.0027169655077159405f, 0.004051437601447105f, 0.00399044482037425f, 0.0050574918277561665f, 0.004705601371824741f, 0.00523778423666954f, 0.0026760997716337442f, 0.0030015187803655863f, 0.0048269121907651424f, 0.003270507324486971f, 0.0047738440334796906f, 0.005049843806773424f, 0.003374084597453475f, 0.0016765473410487175f, 0.005499118007719517f, 0.004638704005628824f, 0.0052010901272296906f, 0.006394342519342899f, 0.00360710546374321f, 0.0036954456008970737f, 0.002410483080893755f, 0.0023531904444098473f, 0.0037998559419065714f, 0.0029543284326791763f, 0.0025523118674755096f, 0.005026648752391338f, 0.00432987604290247f, 0.0024608217645436525f, 0.003233154769986868f, 0.009662223979830742f, 0.006661443039774895f, 0.003220601938664913f, 0.015559296123683453f, 0.003056866582483053f, 0.003036708105355501f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #17 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00813550315797329f),
    AI_PACK_INTQ_ZP(-94)))

/* Int quant #18 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003466961905360222f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #19 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02243109606206417f),
    AI_PACK_INTQ_ZP(36)))

/* Int quant #20 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0179153885692358f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #21 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0016205367865040898f, 0.0030364664271473885f, 0.0032069727312773466f, 0.0030899522826075554f, 0.0021565814968198538f, 0.0033591855317354202f, 0.0032149318140000105f, 0.0033717083279043436f, 0.0030650082044303417f, 0.0028946774546056986f, 0.004908501636236906f, 0.003375633852556348f, 0.0027926668990403414f, 0.004464191384613514f, 0.0023045723792165518f, 0.0022092931903898716f, 0.0065715075470507145f, 0.0031879181042313576f, 0.004162305034697056f, 0.00489032594487071f, 0.003610295942053199f, 0.004501702729612589f, 0.003522855695337057f, 0.004021716769784689f, 0.0037903047632426023f, 0.0020042092073708773f, 0.002722743432968855f, 0.0025125055108219385f, 0.00392970209941268f, 0.0017507843440398574f, 0.004796432331204414f, 0.00321912276558578f, 0.0032505702693015337f, 0.006453624926507473f, 0.003395048202946782f, 0.0026006882544606924f, 0.0030739260837435722f, 0.004070199094712734f, 0.006374496500939131f, 0.0031536140013486147f, 0.0026209151837974787f, 0.003676501801237464f, 0.007025375030934811f, 0.002494943095371127f, 0.00367236090824008f, 0.002675178926438093f, 0.002304736990481615f, 0.004321726970374584f, 0.0022734112571924925f, 0.002980690449476242f, 0.00281722960062325f, 0.002459554700180888f, 0.005196582060307264f, 0.004802374634891748f, 0.003767907153815031f, 0.001430467702448368f, 0.0029858748894184828f, 0.004249547608196735f, 0.0016149613074958324f, 0.002087340224534273f, 0.0036801337264478207f, 0.003699082648381591f, 0.002395797288045287f, 0.002899071667343378f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #22 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.008097085170447826f),
    AI_PACK_INTQ_ZP(-94)))

/* Int quant #23 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0034633439499884844f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #24 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.019099432975053787f),
    AI_PACK_INTQ_ZP(21)))

/* Int quant #25 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00813550315797329f),
    AI_PACK_INTQ_ZP(-94)))

/* Int quant #26 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_12_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0031542738433927298f, 0.0030553587712347507f, 0.004620659165084362f, 0.003836313495412469f, 0.002708426211029291f, 0.002896607620641589f, 0.0015854641096666455f, 0.004383231978863478f, 0.003597391303628683f, 0.003979834727942944f, 0.0033859165851026773f, 0.0037227354478091f, 0.003979260567575693f, 0.004668432287871838f, 0.0031776807736605406f, 0.007686140947043896f, 0.0029297342989593744f, 0.0023237126879394054f, 0.0021499425638467073f, 0.0035874182358384132f, 0.004461241886019707f, 0.003911680541932583f, 0.006167282350361347f, 0.003139517270028591f, 0.0046522365882992744f, 0.005567583721131086f, 0.0029842338990420103f, 0.004978576209396124f, 0.0033333906903862953f, 0.004281001165509224f, 0.004500025417655706f, 0.003928075544536114f, 0.003670171834528446f, 0.0023543951101601124f, 0.004285650793462992f, 0.006299867760390043f, 0.004459910094738007f, 0.0024322334211319685f, 0.0021463751327246428f, 0.005155328195542097f, 0.011618304997682571f, 0.003443046472966671f, 0.00443973857909441f, 0.004595870617777109f, 0.004354981239885092f, 0.0037805908359587193f, 0.0029326914809644222f, 0.003615377005189657f, 0.005315989721566439f, 0.007959351874887943f, 0.002697673859074712f, 0.00510810874402523f, 0.0029471449088305235f, 0.00335135986097157f, 0.0036980973090976477f, 0.005279292352497578f, 0.003707439638674259f, 0.0036335031036287546f, 0.0036060817074030638f, 0.0033559149596840143f, 0.009575881063938141f, 0.005284123122692108f, 0.0030834744684398174f, 0.002355547621846199f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #27 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_13_Resize_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00980895385146141f),
    AI_PACK_INTQ_ZP(-100)))

/* Int quant #28 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_14_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.017389710992574692f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #29 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.018013987690210342f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #30 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0099400719627738f),
    AI_PACK_INTQ_ZP(-100)))

/* Int quant #31 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0099400719627738f),
    AI_PACK_INTQ_ZP(-100)))

/* Int quant #32 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0099400719627738f),
    AI_PACK_INTQ_ZP(-100)))

/* Int quant #33 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0036102738231420517f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #34 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.034791190177202225f),
    AI_PACK_INTQ_ZP(57)))

/* Int quant #35 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0026137682143598795f, 0.0023820458445698023f, 0.0037670182064175606f, 0.004252725746482611f, 0.014042209833860397f, 0.002837699605152011f, 0.0026430622674524784f, 0.0028523572254925966f, 0.0021768303122371435f, 0.00707688182592392f, 0.004127908498048782f, 0.004489180166274309f, 0.007020845077931881f, 0.003406292526051402f, 0.003310632426291704f, 0.003046486061066389f, 0.003980385605245829f, 0.009064548648893833f, 0.002544945804402232f, 0.002682570368051529f, 0.00416010245680809f, 0.0021057017147541046f, 0.0018092667451128364f, 0.005165890324860811f, 0.007424686104059219f, 0.002837963169440627f, 0.003231500741094351f, 0.008873401209712029f, 0.00221004500053823f, 0.005911539308726788f, 0.003341426607221365f, 0.0027018787804991007f, 0.007801867090165615f, 0.0029856478795409203f, 0.006416077725589275f, 0.0071527170948684216f, 0.008361187763512135f, 0.004807950463145971f, 0.004841523244976997f, 0.004423688165843487f, 0.003512975759804249f, 0.00993844959884882f, 0.0026702468749135733f, 0.003925346303731203f, 0.005928823258727789f, 0.004696372430771589f, 0.0037487735971808434f, 0.005094950087368488f, 0.005625493358820677f, 0.004753519780933857f, 0.011794953607022762f, 0.007029276341199875f, 0.0061477068811655045f, 0.0023239559959620237f, 0.007546430453658104f, 0.0045299227349460125f, 0.0060482085682451725f, 0.010731914080679417f, 0.003092831699177623f, 0.008784512989223003f, 0.008348079398274422f, 0.0033291189465671778f, 0.002787454519420862f, 0.00848463736474514f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #36 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011754265055060387f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #37 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003711672965437174f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #38 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03500165790319443f),
    AI_PACK_INTQ_ZP(45)))

/* Int quant #39 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005627778358757496f, 0.010392040014266968f, 0.005193958058953285f, 0.012704121880233288f, 0.0033613087143749f, 0.012387598864734173f, 0.006060988642275333f, 0.009223507717251778f, 0.006997731048613787f, 0.007825984619557858f, 0.004885657224804163f, 0.006865081377327442f, 0.007812126539647579f, 0.007180113811045885f, 0.005671241320669651f, 0.008396347053349018f, 0.004799395799636841f, 0.011563623324036598f, 0.003946617245674133f, 0.007062713149935007f, 0.010210996493697166f, 0.0031111245043575764f, 0.008309721946716309f, 0.009000645019114017f, 0.0041901301592588425f, 0.008997748605906963f, 0.0048018936067819595f, 0.007042204961180687f, 0.004355702083557844f, 0.0033123153261840343f, 0.014931020326912403f, 0.006391901057213545f, 0.01377040520310402f, 0.004524147137999535f, 0.00974272470921278f, 0.008629923686385155f, 0.01018246915191412f, 0.009337197989225388f, 0.0049533843994140625f, 0.010132629424333572f, 0.009800614789128304f, 0.004674697294831276f, 0.0043493169359862804f, 0.0057251485995948315f, 0.004045258741825819f, 0.009289918467402458f, 0.0053868540562689304f, 0.011058049276471138f, 0.01020127534866333f, 0.00623597577214241f, 0.004141360521316528f, 0.00552064273506403f, 0.01176580972969532f, 0.009542902000248432f, 0.004059283994138241f, 0.004950240254402161f, 0.010450396686792374f, 0.0045075747184455395f, 0.0049694618210196495f, 0.005596035160124302f, 0.005563551560044289f, 0.013046812266111374f, 0.004198527429252863f, 0.01270375121384859f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #40 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.008238828741014004f),
    AI_PACK_INTQ_ZP(-94)))

/* Int quant #41 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003476562909781933f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #42 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.022990986704826355f),
    AI_PACK_INTQ_ZP(38)))

/* Int quant #43 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0099400719627738f),
    AI_PACK_INTQ_ZP(-100)))

/* Int quant #44 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003762013278901577f, 0.0017298531020060182f, 0.006923343986272812f, 0.006056224927306175f, 0.006113549694418907f, 0.005066525191068649f, 0.005509819835424423f, 0.006769642699509859f, 0.008565550670027733f, 0.0049387565813958645f, 0.0075659737922251225f, 0.005190623924136162f, 0.008961891755461693f, 0.0030365141574293375f, 0.0015895607648417354f, 0.004241195507347584f, 0.006437158677726984f, 0.005382215604186058f, 0.005209273658692837f, 0.0073300437070429325f, 0.006860558409243822f, 0.005926670040935278f, 0.0033920288551598787f, 0.005282708443701267f, 0.003720012027770281f, 0.006453343201428652f, 0.008118169382214546f, 0.0059195286594331264f, 0.005701396148651838f, 0.007609033491462469f, 0.006143862381577492f, 0.006189424078911543f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #45 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.018013987690210342f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #46 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038725617341697216f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #47 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02647252008318901f),
    AI_PACK_INTQ_ZP(-38)))

/* Int quant #48 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.008238828741014004f),
    AI_PACK_INTQ_ZP(-94)))

/* Int quant #49 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_15_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.010327579453587532f, 0.006595132872462273f, 0.011527348309755325f, 0.011186746880412102f, 0.010755794122815132f, 0.010627116076648235f, 0.012338200584053993f, 0.006298178341239691f, 0.010585067793726921f, 0.013033720664680004f, 0.007469760719686747f, 0.015119443647563457f, 0.010519596748054028f, 0.014573577791452408f, 0.011566927656531334f, 0.012124280445277691f, 0.008260371163487434f, 0.009762131609022617f, 0.014332765713334084f, 0.015161090530455112f, 0.005372978281229734f, 0.009760413318872452f, 0.015480504371225834f, 0.011872263625264168f, 0.01061472948640585f, 0.007787239272147417f, 0.007916443981230259f, 0.006005019415169954f, 0.012646636925637722f, 0.012136895209550858f, 0.01074462290853262f, 0.005053124390542507f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #50 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_16_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011476434767246246f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #51 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_16_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0036984155885875225f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #52 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_16_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.026528572663664818f),
    AI_PACK_INTQ_ZP(21)))

/* Int quant #53 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_16_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011754265055060387f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #54 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_16_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0036531288642436266f, 0.004188861697912216f, 0.004164504818618298f, 0.003741465974599123f, 0.004203269723802805f, 0.0010770696680992842f, 0.0031652573961764574f, 0.0020039319060742855f, 0.0028172379825264215f, 0.00357669941149652f, 0.0035271078813821077f, 0.002602268010377884f, 0.004791447892785072f, 0.002194831147789955f, 0.0034862628672271967f, 0.00424240855500102f, 0.004392526112496853f, 0.001969296718016267f, 0.0026696634013205767f, 0.003698221407830715f, 0.005011900328099728f, 0.0017169517232105136f, 0.0030712538864463568f, 0.0024723357055336237f, 0.0029949324671179056f, 0.0027223725337535143f, 0.00211880961433053f, 0.00392920570448041f, 0.0031991417054086924f, 0.002853858284652233f, 0.004111321642994881f, 0.0020663049072027206f, 0.0016260818811133504f, 0.0026063064578920603f, 0.0032992532942444086f, 0.0055786981247365475f, 0.0024142134934663773f, 0.003736077109351754f, 0.0028341973666101694f, 0.0035797636955976486f, 0.0020110015757381916f, 0.003645631019026041f, 0.005097459070384502f, 0.003667706623673439f, 0.0032431099098175764f, 0.005162364803254604f, 0.0025940777268260717f, 0.003589420113712549f, 0.002186079043895006f, 0.002010156400501728f, 0.0036515493411570787f, 0.004227306228131056f, 0.0037964179646223783f, 0.0031037922017276287f, 0.0018099917797371745f, 0.003606367390602827f, 0.0013668849132955074f, 0.004848544951528311f, 0.0036977853160351515f, 0.0020899015944451094f, 0.003445456735789776f, 0.003870426444336772f, 0.005121398251503706f, 0.0041718496941030025f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #55 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_17_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011476434767246246f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #56 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.015442687086760998f),
    AI_PACK_INTQ_ZP(-110)))

/* Int quant #57 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011952594853937626f),
    AI_PACK_INTQ_ZP(-105)))

/* Int quant #58 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011952594853937626f),
    AI_PACK_INTQ_ZP(-105)))

/* Int quant #59 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011952594853937626f),
    AI_PACK_INTQ_ZP(-105)))

/* Int quant #60 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0037206909619271755f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #61 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02808360755443573f),
    AI_PACK_INTQ_ZP(23)))

/* Int quant #62 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005260499194264412f, 0.008591635152697563f, 0.006446748040616512f, 0.009214987978339195f, 0.007085772696882486f, 0.009643305093050003f, 0.007338189519941807f, 0.007641592528671026f, 0.00805540382862091f, 0.004441553261131048f, 0.005876570474356413f, 0.00540655292570591f, 0.004869665484875441f, 0.01008918322622776f, 0.005628963932394981f, 0.008524446748197079f, 0.009007902815937996f, 0.005388591438531876f, 0.008143382146954536f, 0.007207250222563744f, 0.007572058588266373f, 0.0060537466779351234f, 0.007605948485434055f, 0.01534159854054451f, 0.007539218757301569f, 0.00486957048997283f, 0.010699792765080929f, 0.007172734010964632f, 0.006117058452218771f, 0.006276198197156191f, 0.007911124266684055f, 0.00898273941129446f, 0.008117138408124447f, 0.011159984394907951f, 0.0094665652140975f, 0.007249819114804268f, 0.00798131339251995f, 0.006830344442278147f, 0.0053674522787332535f, 0.011820100247859955f, 0.007503935601562262f, 0.005993994418531656f, 0.007804781198501587f, 0.006791539490222931f, 0.009826208464801311f, 0.00962356198579073f, 0.01130018848925829f, 0.0061929915100336075f, 0.008894598111510277f, 0.006464978214353323f, 0.005617977119982243f, 0.011502665467560291f, 0.011834646575152874f, 0.009572166949510574f, 0.011273822747170925f, 0.006030664313584566f, 0.014827587641775608f, 0.004582981113344431f, 0.009893594309687614f, 0.006800993345677853f, 0.008708041161298752f, 0.005820692051202059f, 0.005592170171439648f, 0.008153585717082024f, 0.004637340549379587f, 0.010633722878992558f, 0.008772704750299454f, 0.010228845290839672f, 0.004315102007240057f, 0.004508520010858774f, 0.00999536644667387f, 0.009976516477763653f, 0.008188478648662567f, 0.010066783986985683f, 0.00962251890450716f, 0.009727542288601398f, 0.007344837300479412f, 0.008580336347222328f, 0.007246137596666813f, 0.005257514305412769f, 0.007297513075172901f, 0.008398097939789295f, 0.011054334230720997f, 0.01069303136318922f, 0.007083696313202381f, 0.006956202443689108f, 0.009006934240460396f, 0.00819479487836361f, 0.007992859929800034f, 0.010250515304505825f, 0.012971059419214725f, 0.008947093039751053f, 0.006628699135035276f, 0.011897537857294083f, 0.008865712210536003f, 0.004037050995975733f, 0.006695218849927187f, 0.008836967870593071f, 0.009726558811962605f, 0.005870558321475983f, 0.006771832704544067f, 0.01063879020512104f, 0.010334028862416744f, 0.004207908641546965f, 0.006722952704876661f, 0.009557121433317661f, 0.007245935499668121f, 0.0022869009990245104f, 0.006502172444015741f, 0.00844549760222435f, 0.004917553160339594f, 0.008046351373195648f, 0.011315002106130123f, 0.006448052823543549f, 0.009782573208212852f, 0.005814841482788324f, 0.011676953174173832f, 0.005984777584671974f, 0.010450123809278011f, 0.007048698607832193f, 0.009428645484149456f, 0.011165442876517773f, 0.012799343094229698f, 0.014974337071180344f, 0.0077143399976193905f, 0.011528678238391876f, 0.01069379411637783f, 0.008751650340855122f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #63 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01252904161810875f),
    AI_PACK_INTQ_ZP(-106)))

/* Int quant #64 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0037449223455041647f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #65 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.029808079823851585f),
    AI_PACK_INTQ_ZP(25)))

/* Int quant #66 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.018154269084334373f, 0.004949257709085941f, 0.005507543683052063f, 0.0012988876551389694f, 0.0027621127665042877f, 0.003488235641270876f, 0.003044343087822199f, 0.004022246226668358f, 0.004085941705852747f, 0.005616664886474609f, 0.0052805254235863686f, 0.004283439833670855f, 0.0033722850494086742f, 0.004376139957457781f, 0.002584584290161729f, 0.005429933778941631f, 0.005220919847488403f, 0.0020413838792592287f, 0.00391924986615777f, 0.0013376197312027216f, 0.0023169422056525946f, 0.004062185995280743f, 0.0022182597313076258f, 0.002708959858864546f, 0.0025206238497048616f, 0.0037645152769982815f, 0.004061841405928135f, 0.004183300770819187f, 0.0032244091853499413f, 0.003334225155413151f, 0.005340697709470987f, 0.008697649464011192f, 0.00618113623932004f, 0.004035118967294693f, 0.0030618540477007627f, 0.005517086945474148f, 0.00196674931794405f, 0.0057632592506706715f, 0.005391031503677368f, 0.0025213288608938456f, 0.005201293155550957f, 0.005543902516365051f, 0.005190507974475622f, 0.0028576459735631943f, 0.002652144292369485f, 0.001983215333893895f, 0.008346369490027428f, 0.0014535188674926758f, 0.007071609143167734f, 0.004797287285327911f, 0.003261047415435314f, 0.0021492289379239082f, 0.0025729823391884565f, 0.0025624800473451614f, 0.0043578362092375755f, 0.0063666352070868015f, 0.00844687782227993f, 0.004597142338752747f, 0.009149664081633091f, 0.0013369827065616846f, 0.0035657058469951153f, 0.0031107054091989994f, 0.0038394799921661615f, 0.005817781668156385f, 0.0038172753993421793f, 0.0031646927818655968f, 0.005454353988170624f, 0.003612484084442258f, 0.0023441885132342577f, 0.0029146787710487843f, 0.0032772207632660866f, 0.003175474237650633f, 0.004624566994607449f, 0.005461832042783499f, 0.0077669983729720116f, 0.0013419078895822167f, 0.0015179540496319532f, 0.002393845934420824f, 0.007124097552150488f, 0.0029284092597663403f, 0.006079413928091526f, 0.0049767992459237576f, 0.0033226178493350744f, 0.002746736165136099f, 0.0057814354076981544f, 0.002687248168513179f, 0.0050538042560219765f, 0.008629418909549713f, 0.01475459523499012f, 0.0065381755121052265f, 0.0051610819064080715f, 0.0043702442198991776f, 0.005004195496439934f, 0.005119573790580034f, 0.0016884703654795885f, 0.0018147699302062392f, 0.004328896291553974f, 0.00405636103823781f, 0.007948320358991623f, 0.005051853135228157f, 0.013081305660307407f, 0.002743947086855769f, 0.0017824964597821236f, 0.005539720878005028f, 0.0055837384425103664f, 0.006208421662449837f, 0.004105428699404001f, 0.003073757281526923f, 0.0038781496696174145f, 0.005268021486699581f, 0.004797340836375952f, 0.0016030746046453714f, 0.007077301852405071f, 0.001857686904259026f, 0.00676996074616909f, 0.0017315041041001678f, 0.002211709041148424f, 0.004074073396623135f, 0.0026809191331267357f, 0.003994432277977467f, 0.001746090711094439f, 0.002333803800866008f, 0.0021072488743811846f, 0.0019055084558203816f, 0.0038190886843949556f, 0.00574733130633831f, 0.001523156650364399f, 0.004282928071916103f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #67 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.008295484818518162f),
    AI_PACK_INTQ_ZP(-94)))

/* Int quant #68 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0034817480482161045f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #69 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.019731836393475533f),
    AI_PACK_INTQ_ZP(22)))

/* Int quant #70 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011952594853937626f),
    AI_PACK_INTQ_ZP(-105)))

/* Int quant #71 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0013405814534053206f, 0.002145281760022044f, 0.004152012523263693f, 0.004948180168867111f, 0.006278115324676037f, 0.005510364659130573f, 0.003912495449185371f, 0.004663578700274229f, 0.002738037146627903f, 0.004399288445711136f, 0.0045550218783319f, 0.002799197332933545f, 0.004729643929749727f, 0.0035206498578190804f, 0.002576535101979971f, 0.0023128080647438765f, 0.001941211405210197f, 0.003717095823958516f, 0.0022729584015905857f, 0.004034138284623623f, 0.0003542620106600225f, 0.0019102778751403093f, 0.002855936298146844f, 0.003955300431698561f, 0.002839756431058049f, 0.0027996667195111513f, 0.003125421004369855f, 0.003488676156848669f, 0.0027263204101473093f, 0.005325864534825087f, 0.004458113573491573f, 0.0021528215147554874f, 0.00496990280225873f, 0.003022712655365467f, 0.0038162136916071177f, 0.0013777811545878649f, 0.004233158193528652f, 0.003193605225533247f, 0.0038027423433959484f, 0.0018075454281643033f, 0.00344826583750546f, 0.0032336264848709106f, 0.004841168876737356f, 0.002395392395555973f, 0.002401568228378892f, 0.00291131972335279f, 0.0016601657262071967f, 0.0023920361418277025f, 0.002047406742349267f, 0.004301082342863083f, 0.006356853060424328f, 0.0024460426066070795f, 0.0027512949891388416f, 0.002070622518658638f, 0.002643187064677477f, 0.0033778708893805742f, 0.002463391050696373f, 0.0032862513326108456f, 0.003054219065234065f, 0.00410061189904809f, 0.0045946440659463406f, 0.003909005783498287f, 0.004528532270342112f, 0.002180983079597354f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #72 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.015442687086760998f),
    AI_PACK_INTQ_ZP(-110)))

/* Int quant #73 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038310943637043238f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #74 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.031205786392092705f),
    AI_PACK_INTQ_ZP(7)))

/* Int quant #75 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.008295484818518162f),
    AI_PACK_INTQ_ZP(-94)))

/* Int quant #76 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_18_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.010943497531116009f, 0.012752947397530079f, 0.008011125028133392f, 0.008862363174557686f, 0.003501334460452199f, 0.004476806614547968f, 0.006508856080472469f, 0.007748852483928204f, 0.00675682257860899f, 0.0033351555466651917f, 0.012937120161950588f, 0.004812442231923342f, 0.007863103412091732f, 0.006538668647408485f, 0.013903545215725899f, 0.009512120857834816f, 0.013001171872019768f, 0.007709716912358999f, 0.007421324960887432f, 0.005519034340977669f, 0.007554903626441956f, 0.005350159946829081f, 0.007175067905336618f, 0.0089642945677042f, 0.008294530212879181f, 0.014420976862311363f, 0.0041064429096877575f, 0.009687107056379318f, 0.005128614138811827f, 0.011043617501854897f, 0.011794079095125198f, 0.008957436308264732f, 0.008565927855670452f, 0.012376559898257256f, 0.012371978722512722f, 0.010256980545818806f, 0.004733571782708168f, 0.007498662453144789f, 0.01662677340209484f, 0.0050649503245949745f, 0.006447381339967251f, 0.010550176724791527f, 0.01373995840549469f, 0.006572726648300886f, 0.011618643999099731f, 0.009301887825131416f, 0.004664365202188492f, 0.01120146457105875f, 0.009639427065849304f, 0.0031954545993357897f, 0.005394242703914642f, 0.008943240158259869f, 0.007836529053747654f, 0.010200394317507744f, 0.008994346484541893f, 0.0062761795707046986f, 0.010500811971724033f, 0.006328365299850702f, 0.004456184338778257f, 0.011311077512800694f, 0.011715013533830643f, 0.00977401714771986f, 0.00909497495740652f, 0.005960378795862198f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #77 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_19_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016880832612514496f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #78 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_19_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038572156336158514f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #79 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_19_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.030413111671805382f),
    AI_PACK_INTQ_ZP(-8)))

/* Int quant #80 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_19_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01252904161810875f),
    AI_PACK_INTQ_ZP(-106)))

/* Int quant #81 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_19_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0020691442769020796f, 0.0027625788934528828f, 0.0019107179250568151f, 0.0009820660343393683f, 0.0035138041712343693f, 0.003779059974476695f, 0.004570768214762211f, 0.0021249440032988787f, 0.0022434708662331104f, 0.0028501739725470543f, 0.001653193961828947f, 0.002211872721090913f, 0.0012826623860746622f, 0.002999323420226574f, 0.002203036565333605f, 0.0029462396632879972f, 0.0029292867984622717f, 0.003949328791350126f, 0.0015187779208645225f, 0.0020400797948241234f, 0.0028675429057329893f, 0.0032574848737567663f, 0.004399941768497229f, 0.003392433514818549f, 0.0022906549274921417f, 0.0027111880481243134f, 0.00207005743868649f, 0.003002776997163892f, 0.0018823411082848907f, 0.001612804364413023f, 0.0017683556070551276f, 0.0026594309601932764f, 0.0018809435423463583f, 0.002000984037294984f, 0.0033173649571835995f, 0.0023293483536690474f, 0.001879090559668839f, 0.003053908934816718f, 0.0019012239063158631f, 0.0013292221119627357f, 0.0016738097183406353f, 0.001969401491805911f, 0.002123763784766197f, 0.001997202169150114f, 0.005937893409281969f, 0.0025660961400717497f, 0.0035204056184738874f, 0.0040968032553792f, 0.0020233106333762407f, 0.001200249302200973f, 0.0014790878631174564f, 0.0016159935621544719f, 0.002519465982913971f, 0.0030726464465260506f, 0.001516866497695446f, 0.0028117422480136156f, 0.0027018107939511538f, 0.003045465797185898f, 0.0015860964776948094f, 0.002331714378669858f, 0.0029180687852203846f, 0.0022892728447914124f, 0.0035558908712118864f, 0.002842304529622197f, 0.0034674371127039194f, 0.0024596164003014565f, 0.0017029602313414216f, 0.0037390277720987797f, 0.00207903073169291f, 0.0016415584832429886f, 0.004631483927369118f, 0.0022625166457146406f, 0.0022171034943312407f, 0.0015822738641873002f, 0.0030988759826868773f, 0.0022478103637695312f, 0.001094561885111034f, 0.0017686623614281416f, 0.002976813353598118f, 0.002200186951085925f, 0.003741387976333499f, 0.0025537675246596336f, 0.003327482147142291f, 0.002764241537079215f, 0.003221475752070546f, 0.0023320314940065145f, 0.002777209971100092f, 0.001228070235811174f, 0.0015661458019167185f, 0.00448599923402071f, 0.002581918379291892f, 0.0014168964698910713f, 0.0015304021071642637f, 0.0022472378332167864f, 0.002115109469741583f, 0.001944106537848711f, 0.0018415091326460242f, 0.002355310134589672f, 0.002426345832645893f, 0.001820247620344162f, 0.002219418529421091f, 0.0027899527922272682f, 0.0019540260545909405f, 0.00294136512093246f, 0.002845817245543003f, 0.003082661423832178f, 0.0038989849854260683f, 0.002516251290217042f, 0.001433875411748886f, 0.0019482262432575226f, 0.002017611637711525f, 0.0038717039860785007f, 0.002071286551654339f, 0.0014715923462063074f, 0.0033141858875751495f, 0.0016440714243799448f, 0.001676260493695736f, 0.002151148160919547f, 0.002506176009774208f, 0.0014247781364247203f, 0.0028228694573044777f, 0.001992876874282956f, 0.004954558331519365f, 0.0016723842127248645f, 0.0019064011285081506f, 0.0024729473516345024f, 0.0018380512483417988f, 0.002370929578319192f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #82 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.27615880966186523f),
    AI_PACK_INTQ_ZP(-127)))

/* Int quant #83 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921568859368563f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #84 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.509663999080658f),
    AI_PACK_INTQ_ZP(-11)))

/* Int quant #85 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01702040620148182f, 0.011542832478880882f, 0.028158608824014664f, 0.013739879243075848f, 0.016888469457626343f, 0.014873474836349487f, 0.010429520159959793f, 0.015199031680822372f, 0.017745833843946457f, 0.02614676021039486f, 0.026425285264849663f, 0.008284133858978748f, 0.007756760343909264f, 0.02017456479370594f, 0.010795856826007366f, 0.006465976592153311f, 0.010705912485718727f, 0.024121470749378204f, 0.007708749268203974f, 0.02241312339901924f, 0.008605496026575565f, 0.01207311637699604f, 0.019609345123171806f, 0.017879076302051544f, 0.018336642533540726f, 0.006599963176995516f, 0.012533389031887054f, 0.013397974893450737f, 0.013705954886972904f, 0.009819784201681614f, 0.007261157967150211f, 0.024508772417902946f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #86 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_20_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016880832612514496f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #87 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01875721476972103f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #88 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01875721476972103f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #89 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01875721476972103f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #90 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01875721476972103f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #91 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038806479424238205f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #92 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.04673095792531967f),
    AI_PACK_INTQ_ZP(30)))

/* Int quant #93 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 256,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0035322047770023346f, 0.003983141388744116f, 0.004414735361933708f, 0.003955591470003128f, 0.005201108753681183f, 0.012494612485170364f, 0.004626092500984669f, 0.0033854832872748375f, 0.006193915847688913f, 0.005573025438934565f, 0.0050721364095807076f, 0.004575162194669247f, 0.006935108918696642f, 0.005941650830209255f, 0.008531549014151096f, 0.007399001624435186f, 0.0040801409631967545f, 0.0031207145657390356f, 0.005859103985130787f, 0.004653502721339464f, 0.004975821357220411f, 0.007384032942354679f, 0.006211632397025824f, 0.005372610408812761f, 0.006321764551103115f, 0.0063204471953213215f, 0.006379449274390936f, 0.007175323087722063f, 0.008005981333553791f, 0.005942950956523418f, 0.00415233988314867f, 0.004455310292541981f, 0.002880069660022855f, 0.00998767651617527f, 0.006777576636523008f, 0.00753357307985425f, 0.004831325728446245f, 0.008721763268113136f, 0.006734602153301239f, 0.005417949054390192f, 0.004057570826262236f, 0.0038658813573420048f, 0.00576414167881012f, 0.004991305526345968f, 0.0032694258261471987f, 0.008630466647446156f, 0.006933331955224276f, 0.010913265869021416f, 0.004743628203868866f, 0.003545100335031748f, 0.007839340716600418f, 0.004314236808568239f, 0.005701427813619375f, 0.004355052951723337f, 0.007446535397320986f, 0.005368875805288553f, 0.006113829556852579f, 0.00383972586132586f, 0.004064786247909069f, 0.005409372504800558f, 0.0058140503242611885f, 0.00750892236828804f, 0.0033208834938704967f, 0.005603711120784283f, 0.006883702706545591f, 0.003497906494885683f, 0.0036525623872876167f, 0.004023439716547728f, 0.003074042033404112f, 0.004647976718842983f, 0.006468506995588541f, 0.004162169527262449f, 0.007695886306464672f, 0.0035213588271290064f, 0.00597384013235569f, 0.007138547021895647f, 0.007991486229002476f, 0.003864018712192774f, 0.0035640429705381393f, 0.0065630641765892506f, 0.003955613821744919f, 0.004165872000157833f, 0.008498607203364372f, 0.0054104020819067955f, 0.0056576840579509735f, 0.00796662736684084f, 0.004898255690932274f, 0.004674024414271116f, 0.004288011230528355f, 0.003523657564073801f, 0.005549378227442503f, 0.005669250153005123f, 0.004584400914609432f, 0.004162620287388563f, 0.007404477801173925f, 0.006812646519392729f, 0.005993517115712166f, 0.004295350052416325f, 0.00857046153396368f, 0.006951292976737022f, 0.006059444509446621f, 0.007816032506525517f, 0.0029528208542615175f, 0.0057823616079986095f, 0.0052765170112252235f, 0.005045576952397823f, 0.0034735542722046375f, 0.006173542235046625f, 0.00581198139116168f, 0.003545449348166585f, 0.004465389996767044f, 0.004934430122375488f, 0.004134155344218016f, 0.0067583718337118626f, 0.008418131619691849f, 0.00713012320920825f, 0.0044512152671813965f, 0.0067865983583033085f, 0.006928637623786926f, 0.0044233412481844425f, 0.005655134562402964f, 0.007583949249237776f, 0.00685848668217659f, 0.005852780770510435f, 0.006300061941146851f, 0.004463265649974346f, 0.0063169593922793865f, 0.005923793185502291f, 0.005590084008872509f, 0.005458597093820572f, 0.0034546784590929747f, 0.006383858155459166f, 0.0019324610475450754f, 0.004823800642043352f, 0.004809807986021042f, 0.006978119257837534f, 0.005982197355479002f, 0.013822566717863083f, 0.006575016770511866f, 0.007527461275458336f, 0.007494899909943342f, 0.00441338773816824f, 0.007787379901856184f, 0.01142966840416193f, 0.0070398300886154175f, 0.004171247594058514f, 0.008093596436083317f, 0.003066754899919033f, 0.012002240866422653f, 0.004887329414486885f, 0.003749452531337738f, 0.008089553564786911f, 0.008613341487944126f, 0.00671310443431139f, 0.005711682140827179f, 0.008171243593096733f, 0.004708459135144949f, 0.005599376745522022f, 0.0054872785694897175f, 0.009447993710637093f, 0.0035649233032017946f, 0.003379685804247856f, 0.010975537821650505f, 0.0065919444896280766f, 0.008725937455892563f, 0.006258663721382618f, 0.005205062218010426f, 0.004120535217225552f, 0.006191890686750412f, 0.006344683934003115f, 0.0085506746545434f, 0.009952732361853123f, 0.005326587241142988f, 0.004350649192929268f, 0.004883304238319397f, 0.0059071797877550125f, 0.008802407421171665f, 0.00526501564309001f, 0.0024676278699189425f, 0.005072563420981169f, 0.006018884479999542f, 0.0038912792224437f, 0.003854958573356271f, 0.010219499468803406f, 0.00595070281997323f, 0.0058259665966033936f, 0.007726780138909817f, 0.004876615479588509f, 0.015634188428521156f, 0.005074537359178066f, 0.00793802086263895f, 0.008463839069008827f, 0.005744225811213255f, 0.0076401918195188046f, 0.007657337933778763f, 0.004648134112358093f, 0.0092213349416852f, 0.005220070946961641f, 0.011378921568393707f, 0.010312478989362717f, 0.0032724980264902115f, 0.008007972501218319f, 0.006256735883653164f, 0.006036314647644758f, 0.00647035101428628f, 0.004173727240413427f, 0.006875055842101574f, 0.0037774795200675726f, 0.00525949290022254f, 0.006739968433976173f, 0.006209255196154118f, 0.005356227979063988f, 0.005143092013895512f, 0.005926968529820442f, 0.004214889369904995f, 0.0015607788227498531f, 0.006371932104229927f, 0.004443674348294735f, 0.005766996182501316f, 0.007974404841661453f, 0.004705311264842749f, 0.005855055525898933f, 0.004821621812880039f, 0.005900283344089985f, 0.008829215541481972f, 0.0061306883580982685f, 0.007842151448130608f, 0.004552684258669615f, 0.0030662992503494024f, 0.009603128768503666f, 0.004961697850376368f, 0.004935084842145443f, 0.00626916391775012f, 0.005752588622272015f, 0.004233060870319605f, 0.002655639545992017f, 0.004400626290589571f, 0.007249718066304922f, 0.00414193794131279f, 0.004801605362445116f, 0.009704889729619026f, 0.00403117248788476f, 0.004261831287294626f, 0.009508821181952953f, 0.01169721782207489f, 0.009281706996262074f, 0.005169304087758064f, 0.005529652815312147f, 0.008078214712440968f, 0.002935886848717928f, 0.00877273827791214f, 0.015232936479151249f, 0.006739476229995489f, 0.006962979212403297f, 0.007016509305685759f, 0.006415283773094416f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #94 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011548389680683613f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #95 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003701920621097088f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #96 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.035505931824445724f),
    AI_PACK_INTQ_ZP(47)))

/* Int quant #97 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 256,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.014359921216964722f, 0.0037881743628531694f, 0.0018842151621356606f, 0.0023285329807549715f, 0.001674578175880015f, 0.0012150959810242057f, 0.005116243381053209f, 0.0016052990686148405f, 0.0018856164533644915f, 0.0024897020775824785f, 0.0052611748687922955f, 0.0026199142448604107f, 0.0016645315336063504f, 0.0021644614171236753f, 0.004815037362277508f, 0.0022056654561311007f, 0.006310122087597847f, 0.004861201159656048f, 0.013248829171061516f, 0.002250782446935773f, 0.0007613838533870876f, 0.002051418647170067f, 0.0023156795650720596f, 0.0010927533730864525f, 0.001733632874675095f, 0.006668977439403534f, 0.002221892587840557f, 0.0024002871941775084f, 0.005160572938621044f, 0.005503057036548853f, 0.0032829223200678825f, 0.002154961694031954f, 0.003329445142298937f, 0.0015793098136782646f, 0.00185557478107512f, 0.0033115751575678587f, 0.004050173796713352f, 0.002842345740646124f, 0.002113697584718466f, 0.0026949523016810417f, 0.002430395223200321f, 0.03643918037414551f, 0.0025099848862737417f, 0.003398526692762971f, 0.0020354294683784246f, 0.004175718408077955f, 0.013641953468322754f, 0.001699683372862637f, 0.0014847598504275084f, 0.005623967386782169f, 0.0037717786617577076f, 0.0016950444551184773f, 0.004110518377274275f, 0.002579109976068139f, 0.0027327139396220446f, 0.0014461437240242958f, 0.004026610404253006f, 0.005766415502876043f, 0.0047793458215892315f, 0.0032815870363265276f, 0.0030120350420475006f, 0.002559240208938718f, 0.004692246671766043f, 0.0110399778932333f, 0.001838881871663034f, 0.0026311969850212336f, 0.002201523631811142f, 0.0026509352028369904f, 0.0027899076230823994f, 0.004489097744226456f, 0.003539509139955044f, 0.002604487119242549f, 0.005985104478895664f, 0.003920947201550007f, 0.001920760958455503f, 0.003823400940746069f, 0.0017074112547561526f, 0.007261806167662144f, 0.002060979837551713f, 0.0063808080740273f, 0.0013770301593467593f, 0.0019417498260736465f, 0.002905187662690878f, 0.0027987640351057053f, 0.0027105051558464766f, 0.00428056251257658f, 0.0018540286691859365f, 0.0009247622801922262f, 0.0036551530938595533f, 0.004443270619958639f, 0.0026621492579579353f, 0.006753919180482626f, 0.0018956115236505866f, 0.0025522196665406227f, 0.00281140161678195f, 0.0035777799785137177f, 0.0012703256215900183f, 0.0038340738974511623f, 0.0015736998757347465f, 0.002531364094465971f, 0.005658634938299656f, 0.001954010920599103f, 0.0029053238686174154f, 0.005336293019354343f, 0.0024926643818616867f, 0.0022847093641757965f, 0.0015102257020771503f, 0.0026908896397799253f, 0.0023169603664427996f, 0.002211248269304633f, 0.002706085331737995f, 0.003954797051846981f, 0.006265508476644754f, 0.0023919781669974327f, 0.0023835143074393272f, 0.0029682419262826443f, 0.004242530092597008f, 0.0025718824472278357f, 0.002363784471526742f, 0.0027969235088676214f, 0.0030680459458380938f, 0.005945120472460985f, 0.005825191270560026f, 0.002838118700310588f, 0.0030540318693965673f, 0.004339880309998989f, 0.003633707296103239f, 0.006197118666023016f, 0.006100003141909838f, 0.002419031225144863f, 0.0012487394269555807f, 0.0032550538890063763f, 0.002269107149913907f, 0.003235136391595006f, 0.0023243373725563288f, 0.0210084468126297f, 0.002516803564503789f, 0.0026809379924088717f, 0.002367817098274827f, 0.0009791012853384018f, 0.0066064936108887196f, 0.0022892127744853497f, 0.0017546627204865217f, 0.0029048179276287556f, 0.004120389930903912f, 0.0015946660423651338f, 0.0022439523600041866f, 0.0030022284481674433f, 0.0026887899730354548f, 0.0015877413097769022f, 0.0023626661859452724f, 0.0017010460142046213f, 0.002348522888496518f, 0.002911423798650503f, 0.002617518650367856f, 0.00127363670617342f, 0.001922462834045291f, 0.0037745903246104717f, 0.004686214495450258f, 0.0019455439178273082f, 0.0021618392784148455f, 0.003424304071813822f, 0.0017336687305942178f, 0.0019868554081767797f, 0.00428781658411026f, 0.002089556073769927f, 0.0034738723188638687f, 0.0022491684649139643f, 0.003472913522273302f, 0.002578422427177429f, 0.007634666282683611f, 0.0018738467479124665f, 0.004040786065161228f, 0.003927120007574558f, 0.00317241158336401f, 0.002699857112020254f, 0.0014202042948454618f, 0.003974043298512697f, 0.0017332114512100816f, 0.004581747110933065f, 0.0017618536949157715f, 0.0029390875715762377f, 0.003151926212012768f, 0.0018883562879636884f, 0.0016845455393195152f, 0.003494091797620058f, 0.0021855272352695465f, 0.006090225651860237f, 0.003315815469250083f, 0.0011912118643522263f, 0.0024426602758467197f, 0.0014102786080911756f, 0.011163734830915928f, 0.00539708836004138f, 0.004451470449566841f, 0.0024260308127850294f, 0.002594512887299061f, 0.0034466225188225508f, 0.003156883642077446f, 0.003120221197605133f, 0.0038530752062797546f, 0.0037408065982162952f, 0.0020926198922097683f, 0.0012948870426043868f, 0.008503550663590431f, 0.003047847654670477f, 0.0020772020798176527f, 0.0014978328254073858f, 0.0015554077690467238f, 0.003412265097722411f, 0.010592998005449772f, 0.002481307601556182f, 0.0012352319899946451f, 0.0025604546535760164f, 0.0025857503060251474f, 0.0021179416216909885f, 0.002287289360538125f, 0.0030700876377522945f, 0.002192319603636861f, 0.003566920291632414f, 0.0017931530019268394f, 0.0009260138031095266f, 0.0021711806766688824f, 0.0023439840879291296f, 0.003786397399380803f, 0.0025168205611407757f, 0.0034240782260894775f, 0.0028705119621008635f, 0.0029412121511995792f, 0.0025102803483605385f, 0.002934800460934639f, 0.002540500368922949f, 0.0032637023832648993f, 0.004824707750231028f, 0.006844083778560162f, 0.0017128248000517488f, 0.00223172758705914f, 0.002560647903010249f, 0.004109988454729319f, 0.001743115484714508f, 0.0013548199785873294f, 0.0028218517545610666f, 0.002181245479732752f, 0.0012340240646153688f, 0.0024081305600702763f, 0.005937256384640932f, 0.018290819600224495f, 0.003993947058916092f, 0.004951148293912411f, 0.005874116439372301f, 0.003587542101740837f, 0.002933094510808587f, 0.0027850365731865168f, 0.003650965169072151f, 0.01682848110795021f, 0.001438434817828238f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #98 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.012339718639850616f),
    AI_PACK_INTQ_ZP(-105)))

/* Int quant #99 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0037372775841504335f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #100 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02904662862420082f),
    AI_PACK_INTQ_ZP(23)))

/* Int quant #101 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01875721476972103f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #102 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.002261787187308073f, 0.002332826144993305f, 0.0012458324199542403f, 0.002015115460380912f, 0.0029223270248621702f, 0.003304555779322982f, 0.003045037155970931f, 0.005512160249054432f, 0.000874512130394578f, 0.00284433551132679f, 0.0010041836649179459f, 0.005156476981937885f, 0.0022679476533085108f, 0.0024851320777088404f, 0.0027878000400960445f, 0.002547441516071558f, 0.0027574480045586824f, 0.001836976851336658f, 0.0012264007236808538f, 0.004924854263663292f, 0.0026200725696980953f, 0.001329459948465228f, 0.002864235546439886f, 0.0024983787443488836f, 0.0025641394313424826f, 0.003091922728344798f, 0.003314934903755784f, 0.0031276512891054153f, 0.0022631892934441566f, 0.0015511100646108389f, 0.00446987384930253f, 0.002891617827117443f, 0.00106884038541466f, 0.0023929919116199017f, 0.0013026563683524728f, 0.0022125709801912308f, 0.0036652428098022938f, 0.002493591047823429f, 0.003252963302657008f, 0.00259144464507699f, 0.004129301756620407f, 0.002829462755471468f, 0.0024009442422538996f, 0.0025200292002409697f, 0.0015644824597984552f, 0.0013645876897498965f, 0.0018219173653051257f, 0.0019396531861275434f, 0.0030163845513015985f, 0.0014570781495422125f, 0.0010769906220957637f, 0.0009575982694514096f, 0.002919688355177641f, 0.00268101179972291f, 0.001321932184509933f, 0.003514827461913228f, 0.000977250630967319f, 0.0032543546985834837f, 0.0015994538553059101f, 0.001978348009288311f, 0.0037766979075968266f, 0.0013104606186971068f, 0.0022167644929140806f, 0.0028007107321172953f, 0.0019681467674672604f, 0.003993457183241844f, 0.0012969794915989041f, 0.0018990400712937117f, 0.002403533086180687f, 0.001042430754750967f, 0.001481435028836131f, 0.002037957077845931f, 0.002137952484190464f, 0.003394352039322257f, 0.002366048749536276f, 0.0019037032034248114f, 0.0014508898602798581f, 0.003319401293992996f, 0.0023866405244916677f, 0.0026444473769515753f, 0.0025189982261508703f, 0.0025945971719920635f, 0.0017369113629683852f, 0.0022737798281013966f, 0.0005005776765756309f, 0.005606979131698608f, 0.0026181500870734453f, 0.0029602274298667908f, 0.0010340178851038218f, 0.0018974733538925648f, 0.002472593216225505f, 0.0029286632779985666f, 0.0036544695030897856f, 0.0019179231021553278f, 0.0016578984213992953f, 0.0017170249484479427f, 0.0020627628546208143f, 0.003267912659794092f, 0.0019884996581822634f, 0.0011339867487549782f, 0.0010724739404395223f, 0.0023786667734384537f, 0.002569108037278056f, 0.002622725907713175f, 0.0027077242266386747f, 0.0030849084723740816f, 0.0015692620072513819f, 0.002708393381908536f, 0.002766701392829418f, 0.001837746356613934f, 0.0019082275684922934f, 0.002945112530142069f, 0.002219113055616617f, 0.003489011200144887f, 0.0016162979882210493f, 0.00303537561558187f, 0.0015383012359961867f, 0.0014805597020313144f, 0.0018628567922860384f, 0.002472210442647338f, 0.004122934769839048f, 0.0024374464992433786f, 0.001757002784870565f, 0.0003694994084071368f, 0.0045064277946949005f, 0.0020179187413305044f, 0.001872215187177062f, 0.0014542583376169205f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #103 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.012871840968728065f),
    AI_PACK_INTQ_ZP(-106)))

/* Int quant #104 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003758026286959648f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #105 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.029108913615345955f),
    AI_PACK_INTQ_ZP(19)))

/* Int quant #106 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.012339718639850616f),
    AI_PACK_INTQ_ZP(-105)))

/* Int quant #107 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_21_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005919854622334242f, 0.003135845996439457f, 0.002165363635867834f, 0.002221970120444894f, 0.0033623860217630863f, 0.0028412826359272003f, 0.003403189592063427f, 0.0025688386522233486f, 0.002030262490734458f, 0.002890616189688444f, 0.00897045899182558f, 0.0035854522138834f, 0.00822364166378975f, 0.004304401110857725f, 0.0034184264950454235f, 0.004206879064440727f, 0.0027723205275833607f, 0.0025602818932384253f, 0.006134779658168554f, 0.00293752527795732f, 0.0031897856388241053f, 0.004245034884661436f, 0.003428099676966667f, 0.0037010025698691607f, 0.0030022086575627327f, 0.002935542957857251f, 0.002677166135981679f, 0.0024379543028771877f, 0.003288286505267024f, 0.003529955167323351f, 0.0023586784955114126f, 0.007367665413767099f, 0.0015653130831196904f, 0.0018492558738216758f, 0.0023336010053753853f, 0.003529838752001524f, 0.005606730002909899f, 0.003417497966438532f, 0.003904311917722225f, 0.003267710329964757f, 0.0016108729178085923f, 0.0033945709001272917f, 0.005886336788535118f, 0.0021234971936792135f, 0.0032192817889153957f, 0.002321966690942645f, 0.005444379989057779f, 0.0031751119531691074f, 0.0017723897472023964f, 0.0031315588857978582f, 0.0021319850347936153f, 0.0031651542522013187f, 0.0026177915278822184f, 0.005909878760576248f, 0.004645315930247307f, 0.003460615873336792f, 0.0011675149435177445f, 0.004364874679595232f, 0.004602441098541021f, 0.0032344593200832605f, 0.0030115903355181217f, 0.002308329800143838f, 0.00791619811207056f, 0.003045941237360239f, 0.008548286743462086f, 0.003930003382265568f, 0.004115259740501642f, 0.0024791646283119917f, 0.003055205335840583f, 0.0025394533295184374f, 0.0027278319466859102f, 0.004617406986653805f, 0.003539579687640071f, 0.002507803961634636f, 0.0030453915242105722f, 0.0016748149646446109f, 0.0021574446000158787f, 0.0033636095467954874f, 0.004249852616339922f, 0.002495969645678997f, 0.0031106320675462484f, 0.0018434998346492648f, 0.004022060893476009f, 0.002582638757303357f, 0.003780115395784378f, 0.003314558882266283f, 0.005200669635087252f, 0.00366901489906013f, 0.004636394325643778f, 0.0038201049901545048f, 0.0028343400917947292f, 0.006462814752012491f, 0.003453100798651576f, 0.005425609182566404f, 0.0032698209397494793f, 0.0020439147483557463f, 0.003792435396462679f, 0.005349666345864534f, 0.0026641450822353363f, 0.002581268548965454f, 0.002822865964844823f, 0.002807379001751542f, 0.0034530474804341793f, 0.002211702521890402f, 0.0029939846135675907f, 0.0030395917128771544f, 0.0023752262350171804f, 0.004900177475064993f, 0.0016486486420035362f, 0.0022269634064286947f, 0.005270358175039291f, 0.0035679303109645844f, 0.00246595055796206f, 0.0018533813999965787f, 0.0027117328718304634f, 0.004777810536324978f, 0.002667672699317336f, 0.003971016965806484f, 0.003810102352872491f, 0.0024830056354403496f, 0.006673009600490332f, 0.0029248176142573357f, 0.003687736578285694f, 0.00212762295268476f, 0.0024941598530858755f, 0.00902177207171917f, 0.002912862692028284f, 0.0040452685207128525f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #108 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Add_1_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.08345227688550949f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #109 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Add_2_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.1539447009563446f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #110 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Concat_1_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.07364855706691742f),
    AI_PACK_INTQ_ZP(2)))

/* Int quant #111 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Concat_2_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06830965727567673f),
    AI_PACK_INTQ_ZP(-7)))

/* Int quant #112 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Concat_3_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0821143090724945f),
    AI_PACK_INTQ_ZP(-12)))

/* Int quant #113 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Concat_4_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0769723504781723f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #114 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.08008692413568497f),
    AI_PACK_INTQ_ZP(-15)))

/* Int quant #115 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Constant_10_output_0_DequantizeLinear_Output_const_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.15354330837726593f),
    AI_PACK_INTQ_ZP(0)))

/* Int quant #116 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.25196850299835205f),
    AI_PACK_INTQ_ZP(0)))

/* Int quant #117 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0769723504781723f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #118 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Mul_2_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(1.1799200773239136f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #119 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(4.026959868497215e-05f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #120 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Slice_1_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.028565440326929092f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #121 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Slice_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.028565440326929092f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #122 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0821143090724945f),
    AI_PACK_INTQ_ZP(-12)))

/* Int quant #123 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0821143090724945f),
    AI_PACK_INTQ_ZP(-12)))

/* Int quant #124 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Sub_1_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.050276678055524826f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #125 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.08634960651397705f),
    AI_PACK_INTQ_ZP(-96)))

/* Int quant #126 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_0_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01147537212818861f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #127 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003698363434523344f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #128 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.029939068481326103f),
    AI_PACK_INTQ_ZP(33)))

/* Int quant #129 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011754265055060387f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #130 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005699203349649906f, 0.009713225066661835f, 0.005025273188948631f, 0.009851540438830853f, 0.004407332744449377f, 0.0036137623246759176f, 0.006926055531948805f, 0.0062966844998300076f, 0.0050157830119132996f, 0.0031966296955943108f, 0.004034064710140228f, 0.007112219464033842f, 0.0048662759363651276f, 0.00492698373273015f, 0.002083622617647052f, 0.004682351369410753f, 0.0023135689552873373f, 0.005073606502264738f, 0.0033352409955114126f, 0.008703908883035183f, 0.008414517156779766f, 0.003984963055700064f, 0.004829885438084602f, 0.002148407744243741f, 0.003436810104176402f, 0.00438372977077961f, 0.005580289289355278f, 0.0013969851424917579f, 0.003110752906650305f, 0.0009778771782293916f, 0.001684222836047411f, 0.0032056616619229317f, 0.00401032529771328f, 0.003914198838174343f, 0.0020796870812773705f, 0.0035159196704626083f, 0.0034235259518027306f, 0.0038125473074615f, 0.0032743941992521286f, 0.004545721225440502f, 0.00522536551579833f, 0.004192412830889225f, 0.00343053275719285f, 0.0033577382564544678f, 0.005201518069952726f, 0.007636916358023882f, 0.004873073194175959f, 0.004060961306095123f, 0.0016356513369828463f, 0.005246573127806187f, 0.0030516188126057386f, 0.006494329776614904f, 0.004245367366820574f, 0.0019122164230793715f, 0.003258014563471079f, 0.008574049919843674f, 0.004387491848319769f, 0.0028998462948948145f, 0.0032101781107485294f, 0.004855284001678228f, 0.004745068494230509f, 0.007408910896629095f, 0.003334777196869254f, 0.00882059708237648f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #131 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05269473046064377f),
    AI_PACK_INTQ_ZP(-123)))

/* Int quant #132 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0039215609431266785f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #133 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.08163149654865265f),
    AI_PACK_INTQ_ZP(-34)))

/* Int quant #134 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01147537212818861f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #135 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005821575410664082f, 0.01740535907447338f, 0.005582844838500023f, 0.020290782675147057f, 0.010213430039584637f, 0.01802990213036537f, 0.00816074013710022f, 0.010830295272171497f, 0.01577056758105755f, 0.012208055704832077f, 0.007309975102543831f, 0.019159264862537384f, 0.0083251828327775f, 0.009649500250816345f, 0.01290256716310978f, 0.013207681477069855f, 0.004379573743790388f, 0.02349405363202095f, 0.02462136372923851f, 0.01940331794321537f, 0.010510009713470936f, 0.029210804030299187f, 0.01838945969939232f, 0.011306839063763618f, 0.008529535494744778f, 0.02478821575641632f, 0.011987203732132912f, 0.00559745728969574f, 0.009068049490451813f, 0.02883417159318924f, 0.0077257221564650536f, 0.01986587792634964f, 0.027299178764224052f, 0.01843825727701187f, 0.011174619197845459f, 0.01823863945901394f, 0.025599468499422073f, 0.027622144669294357f, 0.009842352010309696f, 0.006550197955220938f, 0.019182534888386726f, 0.010164923034608364f, 0.00605600094422698f, 0.005094481166452169f, 0.014920342713594437f, 0.017800450325012207f, 0.011273011565208435f, 0.0047922879457473755f, 0.007987471297383308f, 0.006536051165312529f, 0.018136335536837578f, 0.013823708519339561f, 0.006798794027417898f, 0.007861859165132046f, 0.005532574839890003f, 0.023742858320474625f, 0.0068366630002856255f, 0.012265192344784737f, 0.01049269363284111f, 0.010187100619077682f, 0.010606092400848866f, 0.02301289141178131f, 0.004666988272219896f, 0.00853632390499115f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #136 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_2_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.07200699299573898f),
    AI_PACK_INTQ_ZP(-31)))

/* Int quant #137 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_0_cv2_0_2_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.004932403564453125f, 0.005054473876953125f, 0.0046234130859375f, 0.004268646240234375f, 0.004245758056640625f, 0.00440216064453125f, 0.00391387939453125f, 0.0032958984375f, 0.00283050537109375f, 0.0030307769775390625f, 0.002117156982421875f, 0.0015163421630859375f, 0.001407623291015625f, 0.0011434555053710938f, 0.0010986328125f, 0.0014057159423828125f, 0.004638671875f, 0.0048828125f, 0.003993988037109375f, 0.004413604736328125f, 0.004253387451171875f, 0.004741668701171875f, 0.0038814544677734375f, 0.003021240234375f, 0.0027942657470703125f, 0.0026874542236328125f, 0.0018320083618164062f, 0.0016641616821289062f, 0.0015926361083984375f, 0.00139617919921875f, 0.0012025833129882812f, 0.00160980224609375f, 0.004810333251953125f, 0.005077362060546875f, 0.00414276123046875f, 0.003803253173828125f, 0.00469970703125f, 0.004055023193359375f, 0.003612518310546875f, 0.003307342529296875f, 0.002979278564453125f, 0.0027294158935546875f, 0.0018568038940429688f, 0.0015153884887695312f, 0.00128173828125f, 0.0011653900146484375f, 0.001079559326171875f, 0.0012750625610351562f, 0.004482269287109375f, 0.00434112548828125f, 0.0041961669921875f, 0.004184722900390625f, 0.0037784576416015625f, 0.004566192626953125f, 0.003917694091796875f, 0.0035953521728515625f, 0.002948760986328125f, 0.002239227294921875f, 0.0018129348754882812f, 0.0016183853149414062f, 0.0014400482177734375f, 0.0013065338134765625f, 0.0012378692626953125f, 0.001434326171875f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #138 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_0_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.019303278997540474f),
    AI_PACK_INTQ_ZP(-114)))

/* Int quant #139 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003885752521455288f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #140 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.04808717593550682f),
    AI_PACK_INTQ_ZP(30)))

/* Int quant #141 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01252904161810875f),
    AI_PACK_INTQ_ZP(-106)))

/* Int quant #142 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.002308059949427843f, 0.0021582858171314f, 0.006578576751053333f, 0.006534678395837545f, 0.0037315150257200003f, 0.00587575463578105f, 0.005609373562037945f, 0.005443556234240532f, 0.0027337237261235714f, 0.0036258725449442863f, 0.00488706212490797f, 0.0035548885352909565f, 0.0028869330417364836f, 0.0026428501587361097f, 0.0042227162048220634f, 0.0037314908113330603f, 0.0033295045141130686f, 0.0029675252735614777f, 0.003774623852223158f, 0.0027321840170770884f, 0.005821423139423132f, 0.006840292830020189f, 0.0018087546341121197f, 0.002683275379240513f, 0.003387297037988901f, 0.008276836946606636f, 0.0020387405529618263f, 0.003238447243347764f, 0.0027954024262726307f, 0.005489978473633528f, 0.0032153024803847075f, 0.0036323817912489176f, 0.0008803847595117986f, 0.0030317516066133976f, 0.003923394717276096f, 0.0029612346552312374f, 0.0020949626341462135f, 0.002858255058526993f, 0.002259316621348262f, 0.005812925286591053f, 0.004109506029635668f, 0.005864420440047979f, 0.0037558593321591616f, 0.004612649325281382f, 0.003383578499779105f, 0.003945615142583847f, 0.001123084337450564f, 0.0018233639420941472f, 0.004211618565022945f, 0.008872906677424908f, 0.004557539243251085f, 0.0023005881812423468f, 0.006218064110726118f, 0.0012658206978812814f, 0.005229031201452017f, 0.0065109930001199245f, 0.002497543580830097f, 0.00995707605034113f, 0.003035489469766617f, 0.0030311306472867727f, 0.0028105489909648895f, 0.004380476661026478f, 0.004491167608648539f, 0.0031958273611962795f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #143 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.040621060878038406f),
    AI_PACK_INTQ_ZP(-121)))

/* Int quant #144 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921404480934143f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #145 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.07160485535860062f),
    AI_PACK_INTQ_ZP(-14)))

/* Int quant #146 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.019303278997540474f),
    AI_PACK_INTQ_ZP(-114)))

/* Int quant #147 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005003699567168951f, 0.008002332411706448f, 0.0032230557408183813f, 0.003497552592307329f, 0.011057384312152863f, 0.0038366024382412434f, 0.013473212718963623f, 0.009242113679647446f, 0.014936410821974277f, 0.007775791920721531f, 0.010121707804501057f, 0.005030595697462559f, 0.009008491411805153f, 0.005430914461612701f, 0.011742460541427135f, 0.0067391302436590195f, 0.004500386770814657f, 0.004028329160064459f, 0.0022663900163024664f, 0.006132547743618488f, 0.0131208635866642f, 0.009046013467013836f, 0.006700414698570967f, 0.010305732488632202f, 0.0054745799861848354f, 0.006562736816704273f, 0.003025004407390952f, 0.0036036132369190454f, 0.005632523447275162f, 0.007108398713171482f, 0.003593045985326171f, 0.011476638726890087f, 0.004993368871510029f, 0.00498519791290164f, 0.007385185919702053f, 0.0070211938582360744f, 0.013244254514575005f, 0.0037000742740929127f, 0.004482816439121962f, 0.007712347432971001f, 0.013538208790123463f, 0.003624451346695423f, 0.012256190180778503f, 0.0049513718113303185f, 0.007712269201874733f, 0.0063940552063286304f, 0.005460512824356556f, 0.005605160724371672f, 0.005003975238651037f, 0.006481811869889498f, 0.004951452370733023f, 0.009443696588277817f, 0.017068756744265556f, 0.021010946482419968f, 0.0052771419286727905f, 0.005655277520418167f, 0.008175232447683811f, 0.005548542365431786f, 0.010808194987475872f, 0.005320330616086721f, 0.005139379296451807f, 0.004542308859527111f, 0.008165174163877964f, 0.003054959699511528f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #148 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_2_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05624363571405411f),
    AI_PACK_INTQ_ZP(-37)))

/* Int quant #149 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_1_cv2_1_2_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0059051513671875f, 0.00501251220703125f, 0.004070281982421875f, 0.003650665283203125f, 0.00357818603515625f, 0.0036525726318359375f, 0.00315093994140625f, 0.0028839111328125f, 0.0026149749755859375f, 0.0020999908447265625f, 0.001895904541015625f, 0.0016841888427734375f, 0.0018167495727539062f, 0.0017957687377929688f, 0.001705169677734375f, 0.0018939971923828125f, 0.005107879638671875f, 0.00505828857421875f, 0.00469207763671875f, 0.00389862060546875f, 0.003658294677734375f, 0.0032711029052734375f, 0.004055023193359375f, 0.003116607666015625f, 0.0024356842041015625f, 0.0026607513427734375f, 0.0019073486328125f, 0.0014696121215820312f, 0.0016384124755859375f, 0.0016040802001953125f, 0.0014781951904296875f, 0.0018396377563476562f, 0.00525665283203125f, 0.005306243896484375f, 0.005046844482421875f, 0.003997802734375f, 0.00385284423828125f, 0.0033321380615234375f, 0.0033588409423828125f, 0.002887725830078125f, 0.00246429443359375f, 0.001926422119140625f, 0.0016088485717773438f, 0.00156402587890625f, 0.0019054412841796875f, 0.0021190643310546875f, 0.0021820068359375f, 0.00247955322265625f, 0.004970550537109375f, 0.004886627197265625f, 0.004772186279296875f, 0.00385284423828125f, 0.003704071044921875f, 0.004245758056640625f, 0.0035724639892578125f, 0.0032253265380859375f, 0.0027179718017578125f, 0.0032196044921875f, 0.0020580291748046875f, 0.0014543533325195312f, 0.0017919540405273438f, 0.002002716064453125f, 0.00206756591796875f, 0.002391815185546875f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #150 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_0_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016390960663557053f),
    AI_PACK_INTQ_ZP(-111)))

/* Int quant #151 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038492484018206596f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #152 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.034030187875032425f),
    AI_PACK_INTQ_ZP(10)))

/* Int quant #153 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011548389680683613f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #154 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0006850919453427196f, 0.001294796704314649f, 0.002917103236541152f, 0.00212509254924953f, 0.0016910244012251496f, 0.0008112515788525343f, 0.0008748488035053015f, 0.002538984641432762f, 0.001336273388005793f, 0.0032357266172766685f, 0.001005610916763544f, 0.0009600843768566847f, 0.0031297854147851467f, 0.0008977215620689094f, 0.0013342597521841526f, 0.0016148576978594065f, 0.003010180778801441f, 0.0012852440122514963f, 0.0013605108251795173f, 0.0033307187259197235f, 0.003425318282097578f, 0.0030954251997172832f, 0.0016357488930225372f, 0.0020245383493602276f, 0.0008534080698154867f, 0.0029498771764338017f, 0.0037916190922260284f, 0.0034942827187478542f, 0.0012467887718230486f, 0.0036641163751482964f, 0.00201718439348042f, 0.0018841199344024062f, 0.0016951088327914476f, 0.001010216772556305f, 0.002012952696532011f, 0.0014537787064909935f, 0.001206764834932983f, 0.001366534736007452f, 0.0012642276706174016f, 0.0008215145790018141f, 0.001985002774745226f, 0.0031422555912286043f, 0.0011456554057076573f, 0.0017552162753418088f, 0.001509938738308847f, 0.001371636288240552f, 0.0008516351226717234f, 0.002295267768204212f, 0.0016837618313729763f, 0.0018308479338884354f, 0.0026015527546405792f, 0.001435271231457591f, 0.00202960055321455f, 0.0017299785977229476f, 0.0026434354949742556f, 0.0036269384436309338f, 0.002397440606728196f, 0.0015526824863627553f, 0.0016469300026074052f, 0.0011480679968371987f, 0.002183891599997878f, 0.0021944313775748014f, 0.0010381607571616769f, 0.0017931511392816901f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #155 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03287694230675697f),
    AI_PACK_INTQ_ZP(-120)))

/* Int quant #156 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00392038794234395f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #157 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06304850429296494f),
    AI_PACK_INTQ_ZP(-2)))

/* Int quant #158 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016390960663557053f),
    AI_PACK_INTQ_ZP(-111)))

/* Int quant #159 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.006848634220659733f, 0.002846750430762768f, 0.0040883575566112995f, 0.004021648317575455f, 0.004334114026278257f, 0.0037429279182106256f, 0.004583308473229408f, 0.0034631555899977684f, 0.003928632475435734f, 0.004620163701474667f, 0.004357278347015381f, 0.009730763733386993f, 0.0031984138768166304f, 0.002964226994663477f, 0.002244827803224325f, 0.006271918769925833f, 0.005946366582065821f, 0.002437565941363573f, 0.002153402892872691f, 0.002532205544412136f, 0.006986681837588549f, 0.002589683048427105f, 0.006583900190889835f, 0.009696007706224918f, 0.004431557841598988f, 0.002583716996014118f, 0.00402448233217001f, 0.0023389640264213085f, 0.0018011728534474969f, 0.004750523250550032f, 0.0040862346068024635f, 0.004896887112408876f, 0.0024165434297174215f, 0.0077562034130096436f, 0.00781120965257287f, 0.007671501953154802f, 0.0045461151748895645f, 0.0016873393906280398f, 0.00756476167589426f, 0.008080409839749336f, 0.002168127568438649f, 0.015257549472153187f, 0.0014518481912091374f, 0.002714952453970909f, 0.00801132619380951f, 0.0050261481665074825f, 0.003371605882421136f, 0.012334858067333698f, 0.0026868886779993773f, 0.002719310112297535f, 0.0021351913455873728f, 0.003638589521870017f, 0.0019460269249975681f, 0.006553679704666138f, 0.009487057104706764f, 0.002248328411951661f, 0.005246646236628294f, 0.0032405084930360317f, 0.008559259586036205f, 0.0024880499113351107f, 0.01389111764729023f, 0.008092374540865421f, 0.004875377286225557f, 0.013164801523089409f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #160 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_2_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05538519471883774f),
    AI_PACK_INTQ_ZP(-38)))

/* Int quant #161 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv2_2_cv2_2_2_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.004863739013671875f, 0.004650115966796875f, 0.00443267822265625f, 0.004573822021484375f, 0.0036067962646484375f, 0.0032405853271484375f, 0.00310516357421875f, 0.0038394927978515625f, 0.0038299560546875f, 0.0026874542236328125f, 0.003742218017578125f, 0.0030269622802734375f, 0.0026378631591796875f, 0.002719879150390625f, 0.0025119781494140625f, 0.0020656585693359375f, 0.004413604736328125f, 0.004123687744140625f, 0.00447845458984375f, 0.0045928955078125f, 0.0037841796875f, 0.0029582977294921875f, 0.0038661956787109375f, 0.00274658203125f, 0.0033054351806640625f, 0.004039764404296875f, 0.0024318695068359375f, 0.0024623870849609375f, 0.001850128173828125f, 0.0016698837280273438f, 0.001331329345703125f, 0.0008764266967773438f, 0.004589080810546875f, 0.00496673583984375f, 0.004467010498046875f, 0.004741668701171875f, 0.0041351318359375f, 0.00344085693359375f, 0.0043792724609375f, 0.0028018951416015625f, 0.003124237060546875f, 0.003093719482421875f, 0.004032135009765625f, 0.00293731689453125f, 0.0021514892578125f, 0.002841949462890625f, 0.00299835205078125f, 0.0027751922607421875f, 0.005039215087890625f, 0.0046539306640625f, 0.004581451416015625f, 0.003604888916015625f, 0.003589630126953125f, 0.004261016845703125f, 0.004150390625f, 0.003330230712890625f, 0.0032787322998046875f, 0.0036411285400390625f, 0.0029296875f, 0.002651214599609375f, 0.00252532958984375f, 0.0027675628662109375f, 0.00262451171875f, 0.0023403167724609375f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #162 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_0_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.014222539030015469f),
    AI_PACK_INTQ_ZP(-108)))

/* Int quant #163 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038013893645256758f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #164 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.027858445420861244f),
    AI_PACK_INTQ_ZP(3)))

/* Int quant #165 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011754265055060387f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #166 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0025508622638881207f, 0.0023313516285270452f, 0.00237784581258893f, 0.0030982038006186485f, 0.0023017970379441977f, 0.002395791234448552f, 0.002076392527669668f, 0.0028800785075873137f, 0.0025785549078136683f, 0.0029465300031006336f, 0.0032963750418275595f, 0.003363652154803276f, 0.00434946920722723f, 0.0023643379099667072f, 0.0028926250524818897f, 0.0023450017906725407f, 0.003479862818494439f, 0.003539754543453455f, 0.0030042019207030535f, 0.002686908934265375f, 0.002753950422629714f, 0.0028433476109057665f, 0.0033815668430179358f, 0.002583267167210579f, 0.0030958433635532856f, 0.0030688007827848196f, 0.0025372023228555918f, 0.0025279647670686245f, 0.003030750434845686f, 0.0023829813580960035f, 0.002198196481913328f, 0.002628661459311843f, 0.004069119226187468f, 0.002525022253394127f, 0.002738402923569083f, 0.0030542733147740364f, 0.002607865259051323f, 0.002846891526132822f, 0.003342848503962159f, 0.004442770965397358f, 0.0035347493831068277f, 0.002907221671193838f, 0.003304136451333761f, 0.003328442806378007f, 0.00309833069331944f, 0.0035383400972932577f, 0.0033435109071433544f, 0.0024353566113859415f, 0.0030160180758684874f, 0.0023761913180351257f, 0.0025592900346964598f, 0.004484608769416809f, 0.0024893288500607014f, 0.003123752772808075f, 0.0035018499474972486f, 0.002348260022699833f, 0.003295532427728176f, 0.002878938103094697f, 0.0027046508621424437f, 0.002762694377452135f, 0.0024322904646396637f, 0.003440409665927291f, 0.0031366085167974234f, 0.004718499723821878f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #167 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.009270775131881237f),
    AI_PACK_INTQ_ZP(-98)))

/* Int quant #168 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0035627931356430054f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #169 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.022303618490695953f),
    AI_PACK_INTQ_ZP(24)))

/* Int quant #170 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.014222539030015469f),
    AI_PACK_INTQ_ZP(-108)))

/* Int quant #171 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0008886271971277893f, 0.001210153684951365f, 0.0011481514666229486f, 0.0016344974283128977f, 0.0010520941577851772f, 0.0007388819940388203f, 0.0009078236762434244f, 0.0008476338698528707f, 0.0012702889507636428f, 0.0008426478016190231f, 0.0006629429990425706f, 0.0008106936002150178f, 0.0009016211843118072f, 0.0008022423717193305f, 0.0013184522977098823f, 0.0010756744304671884f, 0.0011488771997392178f, 0.0014473627088591456f, 0.001361070666462183f, 0.0013981288066133857f, 0.0011465613497421145f, 0.0009985329816117883f, 0.0011115167289972305f, 0.0009181405184790492f, 0.0013723960146307945f, 0.0010945239337161183f, 0.0015215511666610837f, 0.001180614111945033f, 0.0008015062194317579f, 0.0008981806458905339f, 0.0014831603039056063f, 0.0010752129601314664f, 0.0011139813577756286f, 0.0015056799165904522f, 0.0008343716617673635f, 0.0013240629341453314f, 0.0008343624067492783f, 0.0009774717036634684f, 0.0008385215769521892f, 0.0008661975152790546f, 0.0009361429838463664f, 0.0011151136131957173f, 0.0014458438381552696f, 0.0012499091681092978f, 0.0012236051261425018f, 0.0009523381013423204f, 0.001531548798084259f, 0.0008564747404307127f, 0.001294343383051455f, 0.0012583524221554399f, 0.0009351405897177756f, 0.001131162396632135f, 0.0010161903919652104f, 0.0010586217977106571f, 0.0014454337069764733f, 0.0009051566012203693f, 0.0011110120685771108f, 0.0012043655151501298f, 0.0010902625508606434f, 0.0007667263853363693f, 0.0009704219410195947f, 0.0007384097552858293f, 0.0009870663052424788f, 0.000766694953199476f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #172 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_2_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03543657064437866f),
    AI_PACK_INTQ_ZP(127)))

/* Int quant #173 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_0_cv3_0_2_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.002391815185546875f),
    AI_PACK_INTQ_ZP(0)))

/* Int quant #174 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_0_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011501684784889221f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #175 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0036996512208133936f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #176 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.022047054022550583f),
    AI_PACK_INTQ_ZP(-1)))

/* Int quant #177 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01252904161810875f),
    AI_PACK_INTQ_ZP(-106)))

/* Int quant #178 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0012823332799598575f, 0.0012454588431864977f, 0.0011327939573675394f, 0.002143050078302622f, 0.0019876325968652964f, 0.002305135130882263f, 0.00151642388664186f, 0.0014492907794192433f, 0.0019780683796852827f, 0.001824624021537602f, 0.0012408854672685266f, 0.0019199938978999853f, 0.002258498454466462f, 0.0022281433921307325f, 0.0017068629385903478f, 0.0014256712747737765f, 0.0021101736929267645f, 0.001872918102890253f, 0.0017739561153575778f, 0.0019138043280690908f, 0.0012994830030947924f, 0.002012377604842186f, 0.0013085654936730862f, 0.0017555885715410113f, 0.0016686731250956655f, 0.001424150774255395f, 0.0016176245408132672f, 0.0020480563398450613f, 0.0010552776511758566f, 0.0019934941083192825f, 0.0010871426202356815f, 0.0015664227539673448f, 0.0017021306557580829f, 0.0013371037784963846f, 0.0015885995235294104f, 0.0017549573676660657f, 0.001964481081813574f, 0.002233941573649645f, 0.0017054601339623332f, 0.001792925177142024f, 0.001664214301854372f, 0.0026401791255921125f, 0.0017590377246960998f, 0.0015308924484997988f, 0.0016368707874789834f, 0.0016637699445709586f, 0.0018254838651046157f, 0.0021512883249670267f, 0.0014962167479097843f, 0.0017208191566169262f, 0.001210700487717986f, 0.002071559661999345f, 0.001718732062727213f, 0.0014309423277154565f, 0.002411529654636979f, 0.0023894747719168663f, 0.0015414697118103504f, 0.001972218742594123f, 0.0018836460076272488f, 0.0018342266557738185f, 0.0017408792627975345f, 0.0014426052803173661f, 0.0022781596053391695f, 0.0012767530279234052f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #179 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.012582139112055302f),
    AI_PACK_INTQ_ZP(-106)))

/* Int quant #180 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00374701339751482f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #181 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02588588558137417f),
    AI_PACK_INTQ_ZP(9)))

/* Int quant #182 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011501684784889221f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #183 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0009192408761009574f, 0.001064466661773622f, 0.0007055716123431921f, 0.0011291143018752337f, 0.0010163607075810432f, 0.0009152348502539098f, 0.001234967727214098f, 0.0013162518152967095f, 0.0007437202730216086f, 0.0007718513952568173f, 0.0007605946739204228f, 0.0010789544321596622f, 0.0012441396247595549f, 0.0012827810132876039f, 0.0008878788212314248f, 0.0008305895607918501f, 0.0016276778187602758f, 0.0013148155994713306f, 0.0012910354416817427f, 0.0011917810188606381f, 0.0010785632766783237f, 0.001312309061177075f, 0.0015629997942596674f, 0.0007665555458515882f, 0.0012532438850030303f, 0.002203466137871146f, 0.001794130657799542f, 0.001499229110777378f, 0.0011435931082814932f, 0.0009972304105758667f, 0.0016873462591320276f, 0.0013570567825809121f, 0.0008843013783916831f, 0.001120063359849155f, 0.001034023705869913f, 0.0016250682529062033f, 0.001245044986717403f, 0.0007683434523642063f, 0.00096488295821473f, 0.0012202735524624586f, 0.0010459424229338765f, 0.0010183979757130146f, 0.0012323296396061778f, 0.0006706535932607949f, 0.002510348567739129f, 0.0012350877514109015f, 0.0015069532673805952f, 0.0015440057031810284f, 0.001058940775692463f, 0.0010502432705834508f, 0.0008497634553350508f, 0.0016890967963263392f, 0.0011848550057038665f, 0.0010742461308836937f, 0.0011524248402565718f, 0.0010044592199847102f, 0.0009169793338514864f, 0.0009888899512588978f, 0.0008712525595910847f, 0.001120437984354794f, 0.001807470922358334f, 0.0008828879217617214f, 0.0013687968021258712f, 0.001039816765114665f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #184 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_2_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0374639518558979f),
    AI_PACK_INTQ_ZP(127)))

/* Int quant #185 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_1_cv3_1_2_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.004360198974609375f),
    AI_PACK_INTQ_ZP(0)))

/* Int quant #186 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_0_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.010598366148769855f),
    AI_PACK_INTQ_ZP(-102)))

/* Int quant #187 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0036513276863843203f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #188 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.018258780241012573f),
    AI_PACK_INTQ_ZP(-16)))

/* Int quant #189 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011548389680683613f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #190 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0012263791868463159f, 0.0011305834632366896f, 0.0013879225589334965f, 0.0012388043105602264f, 0.0009313161135651171f, 0.001293783774599433f, 0.0014171497896313667f, 0.0009399078553542495f, 0.0012704032706096768f, 0.001089192577637732f, 0.0010254316730424762f, 0.0019742045551538467f, 0.0011435713386163116f, 0.0008482582052238286f, 0.001271807705052197f, 0.001284909201785922f, 0.0015773799968883395f, 0.0012615075102075934f, 0.0011098749237135053f, 0.0012820414267480373f, 0.0009322024416178465f, 0.0009601755882613361f, 0.0015816264785826206f, 0.0009983337949961424f, 0.001141873886808753f, 0.0014309947146102786f, 0.0011685994686558843f, 0.0010671792551875114f, 0.0009835497476160526f, 0.0009034178219735622f, 0.0016435239231213927f, 0.0009429671918042004f, 0.0012611517449840903f, 0.0008593023521825671f, 0.0011908201267942786f, 0.001400528708472848f, 0.0012898202985525131f, 0.0014278151793405414f, 0.00126737414393574f, 0.00108532200101763f, 0.001263558049686253f, 0.0011488153832033277f, 0.0012516423594206572f, 0.0017786663956940174f, 0.001322206575423479f, 0.0010078557534143329f, 0.0013617371441796422f, 0.0014263271586969495f, 0.0012036158004775643f, 0.001010290696285665f, 0.001101955771446228f, 0.0011084878351539373f, 0.0009388860780745745f, 0.0008818263304419816f, 0.0014139150734990835f, 0.0010593892075121403f, 0.0010401238687336445f, 0.0011325775412842631f, 0.0012348609743639827f, 0.0012970129027962685f, 0.0012720434460788965f, 0.0010549098951742053f, 0.0013351457891985774f, 0.0010846913792192936f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #191 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.007602002006024122f),
    AI_PACK_INTQ_ZP(-91)))

/* Int quant #192 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0034142981749027967f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #193 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01474077720195055f),
    AI_PACK_INTQ_ZP(-2)))

/* Int quant #194 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.010598366148769855f),
    AI_PACK_INTQ_ZP(-102)))

/* Int quant #195 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0027030499186366796f, 0.0029423669911921024f, 0.0016456961166113615f, 0.002421354176476598f, 0.0009903114987537265f, 0.0013850982068106532f, 0.001940957154147327f, 0.001388508826494217f, 0.0016538732452318072f, 0.002973556285724044f, 0.0015443753218278289f, 0.0016830357490107417f, 0.002807190641760826f, 0.0013110698200762272f, 0.0017503179842606187f, 0.002560629742220044f, 0.001238711760379374f, 0.0015616584569215775f, 0.0018700292566791177f, 0.002069460228085518f, 0.002596677513793111f, 0.0015239408239722252f, 0.0013932526344433427f, 0.001185485627502203f, 0.0014652545796707273f, 0.0016431940020993352f, 0.0015465301694348454f, 0.0012580400798469782f, 0.0018056281842291355f, 0.001972361234948039f, 0.001566625782288611f, 0.0019384411862120032f, 0.0017186179757118225f, 0.0019200657261535525f, 0.0012022698065266013f, 0.0014388137497007847f, 0.0012637212639674544f, 0.0012662081280723214f, 0.001976210158318281f, 0.0018774186028167605f, 0.0017251468962058425f, 0.003374010557308793f, 0.0016413716366514564f, 0.0011932606576010585f, 0.001639406313188374f, 0.0013626659056171775f, 0.0029608921613544226f, 0.0013981607044115663f, 0.0013372962130233645f, 0.0013229978503659368f, 0.0015509163495153189f, 0.001352293766103685f, 0.0018147497903555632f, 0.00161583605222404f, 0.00129473686683923f, 0.0028080716729164124f, 0.001510240021161735f, 0.0013743614545091987f, 0.0009421457070857286f, 0.0016243106219917536f, 0.0016055884771049023f, 0.0017205971525982022f, 0.0015519114676862955f, 0.0025296316016465425f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #196 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_2_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03242352977395058f),
    AI_PACK_INTQ_ZP(127)))

/* Int quant #197 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_cv3_2_cv3_2_2_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.004535675048828125f),
    AI_PACK_INTQ_ZP(0)))

/* Int quant #198 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_Reshape_1_output_0_to_chfirst_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.028565440326929092f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #199 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_Reshape_1_output_0_to_chlast_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.028565440326929092f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #200 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_Reshape_output_0_to_chfirst_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0821143090724945f),
    AI_PACK_INTQ_ZP(-12)))

/* Int quant #201 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_Reshape_output_0_to_chlast_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0821143090724945f),
    AI_PACK_INTQ_ZP(-12)))

/* Int quant #202 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921568859368563f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #203 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_Transpose_1_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921568859368563f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #204 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.028565440326929092f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #205 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_22_dfl_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.234375f),
    AI_PACK_INTQ_ZP(0)))

/* Int quant #206 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.10722697526216507f),
    AI_PACK_INTQ_ZP(-123)))

/* Int quant #207 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06972721964120865f),
    AI_PACK_INTQ_ZP(-124)))

/* Int quant #208 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06972721964120865f),
    AI_PACK_INTQ_ZP(-124)))

/* Int quant #209 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06972721964120865f),
    AI_PACK_INTQ_ZP(-124)))

/* Int quant #210 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921568859368563f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #211 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.28016364574432373f),
    AI_PACK_INTQ_ZP(65)))

/* Int quant #212 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005390975624322891f, 0.009220608510077f, 0.004574208986014128f, 0.0035433818120509386f, 0.005273773334920406f, 0.002974391682073474f, 0.0076806023716926575f, 0.0026111523620784283f, 0.008171247318387032f, 0.004051609430462122f, 0.004725175444036722f, 0.006836201064288616f, 0.0089876689016819f, 0.0050865644589066505f, 0.006815070286393166f, 0.017477579414844513f, 0.0011843107640743256f, 0.01499680895358324f, 0.0048514362424612045f, 0.005231907125562429f, 0.002759001450613141f, 0.0032264746259897947f, 0.0056887404061853886f, 0.003529733046889305f, 0.005247901193797588f, 0.002356387209147215f, 0.005260703153908253f, 0.003900450188666582f, 0.005828323774039745f, 0.001809804467484355f, 0.0059422217309474945f, 0.003467782400548458f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #213 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02927125059068203f),
    AI_PACK_INTQ_ZP(-118)))

/* Int quant #214 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003918617032468319f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #215 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.07488927990198135f),
    AI_PACK_INTQ_ZP(31)))

/* Int quant #216 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0029144613072276115f, 0.005844281520694494f, 0.003017525188624859f, 0.0030667916871607304f, 0.002914711134508252f, 0.0050166696310043335f, 0.005881544668227434f, 0.0077824098989367485f, 0.0031218056101351976f, 0.005028094630688429f, 0.0033431623596698046f, 0.00844370387494564f, 0.0031063510105013847f, 0.0038767249789088964f, 0.010191251523792744f, 0.012423836626112461f, 0.0034399505238980055f, 0.005321534350514412f, 0.003953338600695133f, 0.005680859088897705f, 0.007170484866946936f, 0.0036915515083819628f, 0.011540232226252556f, 0.011041630990803242f, 0.013737431727349758f, 0.0046567958779633045f, 0.0035059198271483183f, 0.005424992647022009f, 0.014051501639187336f, 0.006029513198882341f, 0.014760363847017288f, 0.011120835319161415f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #217 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_Add_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.10722697526216507f),
    AI_PACK_INTQ_ZP(-123)))

/* Int quant #218 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.07075316458940506f),
    AI_PACK_INTQ_ZP(-124)))

/* Int quant #219 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921568859368563f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #220 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.13429298996925354f),
    AI_PACK_INTQ_ZP(-5)))

/* Int quant #221 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06972721964120865f),
    AI_PACK_INTQ_ZP(-124)))

/* Int quant #222 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 16,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02058349922299385f, 0.012739991769194603f, 0.025407804176211357f, 0.013683013617992401f, 0.014870639890432358f, 0.014952643774449825f, 0.01562727801501751f, 0.014608930796384811f, 0.028971130028367043f, 0.014297202229499817f, 0.02847844548523426f, 0.01554726343601942f, 0.018684562295675278f, 0.012945577502250671f, 0.018501898273825645f, 0.013680532574653625f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #223 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.08575773239135742f),
    AI_PACK_INTQ_ZP(-125)))

/* Int quant #224 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921568859368563f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #225 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.1647338569164276f),
    AI_PACK_INTQ_ZP(-4)))

/* Int quant #226 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.07075316458940506f),
    AI_PACK_INTQ_ZP(-124)))

/* Int quant #227 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_2_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 16,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00919396337121725f, 0.010710304602980614f, 0.0034597853664308786f, 0.006355763413012028f, 0.008521131239831448f, 0.0045099081471562386f, 0.012672278098762035f, 0.007129861041903496f, 0.007731483317911625f, 0.006490225903689861f, 0.007498915307223797f, 0.01317870058119297f, 0.006566376890987158f, 0.005725029855966568f, 0.006708668544888496f, 0.003349251812323928f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #228 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_3_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.022087249904870987f),
    AI_PACK_INTQ_ZP(-115)))

/* Int quant #229 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_3_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003903554519638419f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #230 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_3_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.044234033674001694f),
    AI_PACK_INTQ_ZP(5)))

/* Int quant #231 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_3_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02927125059068203f),
    AI_PACK_INTQ_ZP(-118)))

/* Int quant #232 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_3_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0016325416509062052f, 0.004089666996151209f, 0.0019527365220710635f, 0.004105020314455032f, 0.0024938632268458605f, 0.0028167893178761005f, 0.004050792660564184f, 0.004266512114554644f, 0.002517880406230688f, 0.0010302362497895956f, 0.004568763077259064f, 0.002682541962713003f, 0.003566083265468478f, 0.004616016522049904f, 0.0031377412378787994f, 0.004799638409167528f, 0.0027240384370088577f, 0.0024048176128417253f, 0.003402429400011897f, 0.004049369134008884f, 0.003402492729946971f, 0.0036872532218694687f, 0.002256915206089616f, 0.0029975192155689f, 0.002221329603344202f, 0.0018408299656584859f, 0.0017166679026558995f, 0.002426485763862729f, 0.0030307748820632696f, 0.0035621076822280884f, 0.002363558392971754f, 0.002098884666338563f, 0.002437921706587076f, 0.0033390535973012447f, 0.003996758721768856f, 0.0016447333618998528f, 0.0027107077185064554f, 0.003694929415360093f, 0.0035444588866084814f, 0.0020603607408702374f, 0.003023287979885936f, 0.003601302392780781f, 0.0027287837583571672f, 0.0029388959519565105f, 0.005869577173143625f, 0.001843972597271204f, 0.0026488180737942457f, 0.0033500120043754578f, 0.001926960307173431f, 0.0037647231947630644f, 0.0035598070826381445f, 0.003548141336068511f, 0.004157353658229113f, 0.002387494780123234f, 0.0035915232729166746f, 0.006366364192217588f, 0.004605756141245365f, 0.0015134495915845037f, 0.003642361843958497f, 0.002431993605569005f, 0.0048657795414328575f, 0.004036072175949812f, 0.003141116350889206f, 0.00507524935528636f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #233 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02893085405230522f),
    AI_PACK_INTQ_ZP(-99)))

/* Int quant #234 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02329687960445881f),
    AI_PACK_INTQ_ZP(-116)))

/* Int quant #235 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02329687960445881f),
    AI_PACK_INTQ_ZP(-116)))

/* Int quant #236 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02329687960445881f),
    AI_PACK_INTQ_ZP(-116)))

/* Int quant #237 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0039082481525838375f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #238 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05555189400911331f),
    AI_PACK_INTQ_ZP(25)))

/* Int quant #239 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.022088948637247086f, 0.015199525281786919f, 0.0153444679453969f, 0.027960630133748055f, 0.021127505227923393f, 0.017146453261375427f, 0.00960934441536665f, 0.015177417546510696f, 0.021317822858691216f, 0.020153796300292015f, 0.008459463715553284f, 0.017918355762958527f, 0.016446486115455627f, 0.017626235261559486f, 0.00856922846287489f, 0.009849293157458305f, 0.007831612601876259f, 0.017050761729478836f, 0.024510642513632774f, 0.016914168372750282f, 0.01848035305738449f, 0.009427519515156746f, 0.01432275865226984f, 0.011270214803516865f, 0.013619768433272839f, 0.009687992744147778f, 0.009527426213026047f, 0.018425464630126953f, 0.02231641672551632f, 0.006399183534085751f, 0.006524553522467613f, 0.018490172922611237f, 0.005634985398501158f, 0.005443356931209564f, 0.006663662381470203f, 0.004279465414583683f, 0.0039331912994384766f, 0.008832733146846294f, 0.007340180221945047f, 0.006396030075848103f, 0.0038041218649595976f, 0.003428300376981497f, 0.0043570976704359055f, 0.006916396785527468f, 0.004963395651429892f, 0.005405009724199772f, 0.0058880518190562725f, 0.0042346203699707985f, 0.003941271919757128f, 0.0052674924954771996f, 0.008307093754410744f, 0.004724634811282158f, 0.004206749610602856f, 0.005696978885680437f, 0.016550056636333466f, 0.007865183986723423f, 0.005426775198429823f, 0.009950058534741402f, 0.004864039830863476f, 0.004254992585629225f, 0.00409957580268383f, 0.003176678204908967f, 0.0064340028911828995f, 0.007944225333631039f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #240 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.017389710992574692f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #241 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038646033499389887f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #242 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.04623742774128914f),
    AI_PACK_INTQ_ZP(36)))

/* Int quant #243 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003348634811118245f, 0.0023936547804623842f, 0.003458030754700303f, 0.012622499838471413f, 0.005951410625129938f, 0.004180818796157837f, 0.006147335283458233f, 0.004169539548456669f, 0.003245755098760128f, 0.0060851676389575005f, 0.006103035528212786f, 0.004783159121870995f, 0.004566628951579332f, 0.004669720772653818f, 0.004261098802089691f, 0.005929043982177973f, 0.005731476470828056f, 0.0030451754573732615f, 0.005596566945314407f, 0.005153963807970285f, 0.004589030519127846f, 0.0028886054642498493f, 0.004988948814570904f, 0.0069482955150306225f, 0.005775857716798782f, 0.00878509134054184f, 0.005817604251205921f, 0.004224924836307764f, 0.003128394717350602f, 0.002838376211002469f, 0.003739783773198724f, 0.0030952482484281063f, 0.003963615279644728f, 0.0041891238652169704f, 0.004510678816586733f, 0.005822998937219381f, 0.002569979289546609f, 0.004944783169776201f, 0.002939416328445077f, 0.005075816530734301f, 0.004728372674435377f, 0.005173248238861561f, 0.003466014750301838f, 0.00756675424054265f, 0.003925896715372801f, 0.003863855730742216f, 0.007938266731798649f, 0.003551541129127145f, 0.0071245403960347176f, 0.008771030232310295f, 0.0046950215473771095f, 0.0060893464833498f, 0.004909780342131853f, 0.004597294144332409f, 0.004200467374175787f, 0.008807951584458351f, 0.007031358778476715f, 0.0031762314029037952f, 0.00517473416402936f, 0.00208518048748374f, 0.007057713344693184f, 0.004730170592665672f, 0.008317575789988041f, 0.004864751826971769f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #244 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_Add_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.017994940280914307f),
    AI_PACK_INTQ_ZP(-97)))

/* Int quant #245 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011780759319663048f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #246 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003712898585945368f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #247 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02569972351193428f),
    AI_PACK_INTQ_ZP(15)))

/* Int quant #248 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02329687960445881f),
    AI_PACK_INTQ_ZP(-116)))

/* Int quant #249 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003268991596996784f, 0.00578243937343359f, 0.004912441596388817f, 0.004349634516984224f, 0.01171908900141716f, 0.004819743800908327f, 0.0054313247092068195f, 0.006726937368512154f, 0.005170213524252176f, 0.006232277024537325f, 0.006436684634536505f, 0.008096672594547272f, 0.004241329152137041f, 0.003850760171189904f, 0.006392679177224636f, 0.005325733218342066f, 0.007700113579630852f, 0.005928608123213053f, 0.0058777169324457645f, 0.006691720336675644f, 0.006562984548509121f, 0.01013960875570774f, 0.005696706008166075f, 0.0042412965558469296f, 0.004689460154622793f, 0.008894960395991802f, 0.00549312774091959f, 0.006720414850860834f, 0.0095332907512784f, 0.0027091375086456537f, 0.005130262114107609f, 0.004312971606850624f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #250 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011954891495406628f),
    AI_PACK_INTQ_ZP(-105)))

/* Int quant #251 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0037207931745797396f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #252 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02847970649600029f),
    AI_PACK_INTQ_ZP(24)))

/* Int quant #253 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.011780759319663048f),
    AI_PACK_INTQ_ZP(-104)))

/* Int quant #254 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.008419296704232693f, 0.01379503682255745f, 0.0048539042472839355f, 0.005825216416269541f, 0.006160014308989048f, 0.006664292421191931f, 0.0063150967471301556f, 0.004941252991557121f, 0.010228295810520649f, 0.007370729930698872f, 0.009031256660819054f, 0.0037050729151815176f, 0.004107293207198381f, 0.004525644239038229f, 0.004133610986173153f, 0.007857157848775387f, 0.00915332417935133f, 0.00791038479655981f, 0.008904578164219856f, 0.01440157275646925f, 0.013491887599229813f, 0.004860462620854378f, 0.011584751307964325f, 0.00573452515527606f, 0.004839144181460142f, 0.009386900812387466f, 0.006687716580927372f, 0.008046782575547695f, 0.006591286510229111f, 0.007652941159904003f, 0.007637416943907738f, 0.005549157038331032f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #255 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_Add_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02893085405230522f),
    AI_PACK_INTQ_ZP(-99)))

/* Int quant #256 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0063448804430663586f),
    AI_PACK_INTQ_ZP(-84)))

/* Int quant #257 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0032670877408236265f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #258 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.021914204582571983f),
    AI_PACK_INTQ_ZP(54)))

/* Int quant #259 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.017994940280914307f),
    AI_PACK_INTQ_ZP(-97)))

/* Int quant #260 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0018967022188007832f, 0.0037299897521734238f, 0.00339175364933908f, 0.005159319844096899f, 0.002766714431345463f, 0.0026152220088988543f, 0.005688723176717758f, 0.002134151291102171f, 0.004348513204604387f, 0.004874376114457846f, 0.004193652421236038f, 0.0023941216059029102f, 0.004354581236839294f, 0.003620659001171589f, 0.004845242016017437f, 0.004094515461474657f, 0.0045992592349648476f, 0.00433251541107893f, 0.003962632734328508f, 0.003400885732844472f, 0.003677948145195842f, 0.003929571248590946f, 0.00568351149559021f, 0.006400733254849911f, 0.005364217795431614f, 0.003659265348687768f, 0.004375031683593988f, 0.002431289292871952f, 0.002613481367006898f, 0.004146007355302572f, 0.003667292883619666f, 0.0032284168992191553f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #261 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016452599316835403f),
    AI_PACK_INTQ_ZP(-111)))

/* Int quant #262 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003850300097838044f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #263 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03358057886362076f),
    AI_PACK_INTQ_ZP(8)))

/* Int quant #264 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0063448804430663586f),
    AI_PACK_INTQ_ZP(-84)))

/* Int quant #265 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_4_m_1_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 32,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.017594045028090477f, 0.013482458889484406f, 0.028405332937836647f, 0.013963252305984497f, 0.017277659848332405f, 0.016746725887060165f, 0.014220655895769596f, 0.015568285249173641f, 0.012962715700268745f, 0.014987870119512081f, 0.020307017490267754f, 0.017138758674263954f, 0.01203078031539917f, 0.012022510170936584f, 0.02017590031027794f, 0.028685305267572403f, 0.011955421417951584f, 0.015670284628868103f, 0.010639343410730362f, 0.01310055609792471f, 0.009705991484224796f, 0.01010798942297697f, 0.015039655379951f, 0.013217207975685596f, 0.021392233669757843f, 0.022530551999807358f, 0.01782820001244545f, 0.012123510241508484f, 0.014420480467379093f, 0.011361755430698395f, 0.01244252547621727f, 0.008142824284732342f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #266 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_5_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02693839743733406f),
    AI_PACK_INTQ_ZP(-118)))

/* Int quant #267 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_5_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003916239831596613f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #268 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_5_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.054721586406230927f),
    AI_PACK_INTQ_ZP(6)))

/* Int quant #269 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_5_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.017389710992574692f),
    AI_PACK_INTQ_ZP(-112)))

/* Int quant #270 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_5_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003312014741823077f, 0.0024956867564469576f, 0.003152991645038128f, 0.006309131626039743f, 0.0018960903398692608f, 0.002033148193731904f, 0.006591062527149916f, 0.003920379560440779f, 0.0036871435586363077f, 0.0046696471981704235f, 0.003261416219174862f, 0.002157017355784774f, 0.004911623429507017f, 0.004486646968871355f, 0.002701523480936885f, 0.0030488017946481705f, 0.0018245019018650055f, 0.0028031961992383003f, 0.00344206765294075f, 0.0023508346639573574f, 0.005596568342298269f, 0.0031047326046973467f, 0.005185927264392376f, 0.0028505385853350163f, 0.003463071072474122f, 0.005837681237608194f, 0.0014179255813360214f, 0.0030430927872657776f, 0.0036994447000324726f, 0.004423581529408693f, 0.002780011622235179f, 0.0030482886359095573f, 0.0029381802305579185f, 0.0034650808665901423f, 0.0017342140199616551f, 0.0032871481962502003f, 0.003445827402174473f, 0.0024610627442598343f, 0.0034363518934696913f, 0.005599173717200756f, 0.0031729305628687143f, 0.0032809788826853037f, 0.0028417024295777082f, 0.0018973253900185227f, 0.001986654009670019f, 0.002395371673628688f, 0.004235092084854841f, 0.00447478424757719f, 0.003491997253149748f, 0.004252313170582056f, 0.002726630074903369f, 0.004943904001265764f, 0.003310195403173566f, 0.003120189066976309f, 0.005988464690744877f, 0.003718153340741992f, 0.0043272590264678f, 0.003413015278056264f, 0.0025239193346351385f, 0.00303015043027699f, 0.003733897814527154f, 0.006178481504321098f, 0.003686866955831647f, 0.0026427197735756636f, 0.003100202651694417f, 0.003233924275264144f, 0.002461823169142008f, 0.0035330308601260185f, 0.004694492090493441f, 0.006248129066079855f, 0.0029875149484723806f, 0.004644356202334166f, 0.0036056386306881905f, 0.0029905647970736027f, 0.0033180168829858303f, 0.0025300648994743824f, 0.006799007300287485f, 0.004238812252879143f, 0.0031349374912679195f, 0.0021824196446686983f, 0.002857137704268098f, 0.003817381337285042f, 0.003538240445777774f, 0.003347541904076934f, 0.0024945756886154413f, 0.006846711505204439f, 0.0053293355740606785f, 0.0026840048376470804f, 0.003153167199343443f, 0.0014222478494048119f, 0.004504059907048941f, 0.005333227571099997f, 0.004249746911227703f, 0.002820528345182538f, 0.005273581016808748f, 0.001954946666955948f, 0.003127190750092268f, 0.004100876860320568f, 0.003171193180605769f, 0.002573219360783696f, 0.003416223218664527f, 0.004654819145798683f, 0.003769479924812913f, 0.0045484090223908424f, 0.0035581854172050953f, 0.0038211399223655462f, 0.002325681736692786f, 0.0014679726446047425f, 0.0025260106194764376f, 0.005470138043165207f, 0.001891008811071515f, 0.005796961486339569f, 0.003705019364133477f, 0.0025841158349066973f, 0.0029829517006874084f, 0.0035556962247937918f, 0.0033749588765203953f, 0.0061087957583367825f, 0.003235897747799754f, 0.0027344420086592436f, 0.00429842434823513f, 0.005624924786388874f, 0.003086805809289217f, 0.005639581475406885f, 0.002858015475794673f, 0.004607550334185362f, 0.0020752456039190292f, 0.0028090295381844044f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #271 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03295884281396866f),
    AI_PACK_INTQ_ZP(-103)))

/* Int quant #272 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03078489750623703f),
    AI_PACK_INTQ_ZP(-119)))

/* Int quant #273 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03078489750623703f),
    AI_PACK_INTQ_ZP(-119)))

/* Int quant #274 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03078489750623703f),
    AI_PACK_INTQ_ZP(-119)))

/* Int quant #275 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003919558599591255f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #276 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06321726739406586f),
    AI_PACK_INTQ_ZP(7)))

/* Int quant #277 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0051454342901706696f, 0.010539610870182514f, 0.006320272572338581f, 0.010263769887387753f, 0.011762809939682484f, 0.012888893485069275f, 0.00839922297745943f, 0.01150776818394661f, 0.016616327688097954f, 0.013641651719808578f, 0.013440009206533432f, 0.01291947066783905f, 0.008420990779995918f, 0.011084879748523235f, 0.007877200841903687f, 0.009186307899653912f, 0.008214990608394146f, 0.016459476202726364f, 0.008910405449569225f, 0.016279565170407295f, 0.010628865100443363f, 0.011017966084182262f, 0.006595605053007603f, 0.010612620040774345f, 0.0080164959654212f, 0.011146504431962967f, 0.01440817303955555f, 0.012434077449142933f, 0.012002743780612946f, 0.00941662397235632f, 0.024264341220259666f, 0.007706780917942524f, 0.007838068529963493f, 0.007500494830310345f, 0.01620285026729107f, 0.011636725626885891f, 0.008916744031012058f, 0.015786368399858475f, 0.021427860483527184f, 0.007759715896099806f, 0.008539200760424137f, 0.008036686107516289f, 0.010310055688023567f, 0.019481202587485313f, 0.010793754830956459f, 0.0077991485595703125f, 0.013981199823319912f, 0.007823423482477665f, 0.0092288414016366f, 0.010296612046658993f, 0.00943771842867136f, 0.009186087176203728f, 0.010596622712910175f, 0.005060847848653793f, 0.007589587010443211f, 0.01322415191680193f, 0.008615322411060333f, 0.03278426453471184f, 0.006659659557044506f, 0.01100790686905384f, 0.00985829345881939f, 0.009992591105401516f, 0.008286136202514172f, 0.024818086996674538f, 0.003659997135400772f, 0.004139601718634367f, 0.005479315761476755f, 0.005790884140878916f, 0.0027623651549220085f, 0.003863992402330041f, 0.006356270518153906f, 0.0035885886754840612f, 0.005755288060754538f, 0.0030842935666441917f, 0.0056677889078855515f, 0.004089099820703268f, 0.004154806956648827f, 0.00419080862775445f, 0.0053403619676828384f, 0.003202645108103752f, 0.0028221518732607365f, 0.002163634402677417f, 0.002694193972274661f, 0.005735279526561499f, 0.00459072832018137f, 0.00381796364672482f, 0.006312188226729631f, 0.002995852380990982f, 0.004453833214938641f, 0.005711565725505352f, 0.006319655571132898f, 0.014475191943347454f, 0.003237916389480233f, 0.005648565944284201f, 0.0040070186369121075f, 0.003768224036321044f, 0.0035695123951882124f, 0.004054651595652103f, 0.008783277124166489f, 0.003957958891987801f, 0.003584072692319751f, 0.007721766363829374f, 0.005922751035541296f, 0.006217682734131813f, 0.006412943359464407f, 0.005997062660753727f, 0.003322061849758029f, 0.005476252641528845f, 0.004365543369203806f, 0.0029638498090207577f, 0.003720361040905118f, 0.004587577190250158f, 0.00996420532464981f, 0.0025572101585566998f, 0.006304662209004164f, 0.0038316843565553427f, 0.006458490155637264f, 0.003815112868323922f, 0.0022710091434419155f, 0.005676492117345333f, 0.009540298022329807f, 0.007174130994826555f, 0.005948624573647976f, 0.006196106784045696f, 0.00496841873973608f, 0.006591063924133778f, 0.002513629850000143f, 0.004055283963680267f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #278 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.013548851013183594f),
    AI_PACK_INTQ_ZP(-107)))

/* Int quant #279 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0037813077215105295f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #280 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.053506020456552505f),
    AI_PACK_INTQ_ZP(65)))

/* Int quant #281 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0009837680263444781f, 0.0016855918802320957f, 0.0011652741814032197f, 0.00373829435557127f, 0.003092483850196004f, 0.0017028766451403499f, 0.0037961401976644993f, 0.002280524466186762f, 0.0033450385089963675f, 0.0023916217032819986f, 0.0022681604605168104f, 0.0031747077591717243f, 0.002974872710183263f, 0.002047234447672963f, 0.004524738062173128f, 0.004431287292391062f, 0.004648818168789148f, 0.0038025458343327045f, 0.0023813636507838964f, 0.0019229624886065722f, 0.003492798889055848f, 0.0018934305990114808f, 0.0015219640918076038f, 0.0033832858316600323f, 0.001174602541141212f, 0.0016568854916840792f, 0.0032448358833789825f, 0.001948772114701569f, 0.0025904772337526083f, 0.0023235438857227564f, 0.0032257274724543095f, 0.0022578202188014984f, 0.005550825968384743f, 0.004263054113835096f, 0.004537178203463554f, 0.0023078073281794786f, 0.0022628905717283487f, 0.002762031741440296f, 0.0016138874925673008f, 0.0022919659968465567f, 0.006778753828257322f, 0.0040449174121022224f, 0.0020313968416303396f, 0.002842509187757969f, 0.0017759688198566437f, 0.003006541868671775f, 0.005157656501978636f, 0.0033651411067694426f, 0.007045895326882601f, 0.0018099932931363583f, 0.003408456454053521f, 0.004229530692100525f, 0.0019375819247215986f, 0.0036739399656653404f, 0.0034824830945581198f, 0.00313401035964489f, 0.002724314108490944f, 0.0022554153110831976f, 0.004066832363605499f, 0.0026550169568508863f, 0.004843520931899548f, 0.0023018300998955965f, 0.003941047471016645f, 0.004697954747825861f, 0.0037837219424545765f, 0.003557132789865136f, 0.002238350221887231f, 0.0018737934296950698f, 0.0030398915987461805f, 0.003518973710015416f, 0.0020433736499398947f, 0.0031452763359993696f, 0.005076274741441011f, 0.0019823398906737566f, 0.0025925575755536556f, 0.005006472114473581f, 0.0021947654895484447f, 0.004937741905450821f, 0.004983107093721628f, 0.0019119487842544913f, 0.0019732879009097815f, 0.004223685245960951f, 0.003819951554760337f, 0.0022537275217473507f, 0.0019014785066246986f, 0.00408433610573411f, 0.003277863608673215f, 0.003232535906136036f, 0.0047525507397949696f, 0.002197830704972148f, 0.0023793771397322416f, 0.003460035426542163f, 0.00232305726967752f, 0.001962692476809025f, 0.00316438521258533f, 0.0023563688155263662f, 0.0029825048986822367f, 0.005746015347540379f, 0.0028028988745063543f, 0.0014305952936410904f, 0.0018173990538343787f, 0.003661306807771325f, 0.002904248656705022f, 0.004068104084581137f, 0.0014596503460779786f, 0.0016077104955911636f, 0.0019790269434452057f, 0.0031748958863317966f, 0.004741384647786617f, 0.004898655693978071f, 0.0025787323247641325f, 0.0024941591545939445f, 0.0028710647020488977f, 0.0032260899897664785f, 0.004278124310076237f, 0.0028917891904711723f, 0.00214783544652164f, 0.002365788444876671f, 0.0027897662948817015f, 0.002651238115504384f, 0.003653650637716055f, 0.002125932602211833f, 0.0025752540677785873f, 0.0027699279598891735f, 0.00392197584733367f, 0.0047272746451199055f, 0.0018330265302211046f, 0.0030084175523370504f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #282 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_Add_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03157258778810501f),
    AI_PACK_INTQ_ZP(-110)))

/* Int quant #283 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02031523734331131f),
    AI_PACK_INTQ_ZP(-114)))

/* Int quant #284 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003893630113452673f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #285 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.055008869618177414f),
    AI_PACK_INTQ_ZP(37)))

/* Int quant #286 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03078489750623703f),
    AI_PACK_INTQ_ZP(-119)))

/* Int quant #287 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005613663699477911f, 0.004927990026772022f, 0.0036929561756551266f, 0.014269129373133183f, 0.007417087443172932f, 0.004517812281847f, 0.006048540119081736f, 0.004761239048093557f, 0.006735107861459255f, 0.004355885554105043f, 0.004852451384067535f, 0.011818190105259418f, 0.005851708818227053f, 0.012311398051679134f, 0.004360326565802097f, 0.005006837658584118f, 0.006910732947289944f, 0.005077022593468428f, 0.0033003089483827353f, 0.005225421395152807f, 0.0069666397757828236f, 0.0031411147210747004f, 0.004724579397588968f, 0.0024865451268851757f, 0.005783854052424431f, 0.005063584074378014f, 0.009676476009190083f, 0.009385993704199791f, 0.00499078631401062f, 0.005248552188277245f, 0.009862110018730164f, 0.005553373601287603f, 0.0047676959075033665f, 0.0037871443200856447f, 0.007930346764624119f, 0.007880927994847298f, 0.00911971926689148f, 0.007238623686134815f, 0.003123014932498336f, 0.007459334097802639f, 0.004234702792018652f, 0.006357970181852579f, 0.003706315765157342f, 0.005772892385721207f, 0.0053652082569897175f, 0.005695916712284088f, 0.005291555542498827f, 0.0040858229622244835f, 0.00454400759190321f, 0.0039814836345613f, 0.0076899537816643715f, 0.006978804245591164f, 0.002821994014084339f, 0.008267304860055447f, 0.006420895457267761f, 0.005427190102636814f, 0.004116282798349857f, 0.0042351591400802135f, 0.006935285869985819f, 0.005287606734782457f, 0.01144946925342083f, 0.005522752646356821f, 0.006302681285887957f, 0.00273897428996861f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #288 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.020864849910140038f),
    AI_PACK_INTQ_ZP(-115)))

/* Int quant #289 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003897173795849085f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #290 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.043228428810834885f),
    AI_PACK_INTQ_ZP(10)))

/* Int quant #291 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02031523734331131f),
    AI_PACK_INTQ_ZP(-114)))

/* Int quant #292 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0037896663416177034f, 0.004585747607052326f, 0.0038915707264095545f, 0.004386445973068476f, 0.00393263716250658f, 0.0025053885765373707f, 0.0034916079603135586f, 0.0034865248017013073f, 0.002580797066912055f, 0.005300720687955618f, 0.0021769842132925987f, 0.007441089954227209f, 0.005469694267958403f, 0.003124473849311471f, 0.005183548200875521f, 0.0023427701089531183f, 0.0022594251204282045f, 0.003346343757584691f, 0.005647672340273857f, 0.005132839549332857f, 0.010595554485917091f, 0.00231715920381248f, 0.0035961242392659187f, 0.009438930079340935f, 0.0044882153160870075f, 0.0034754329826682806f, 0.005928052123636007f, 0.0038813126739114523f, 0.005326611455529928f, 0.0031658317893743515f, 0.003919287119060755f, 0.0025639482773840427f, 0.006726497784256935f, 0.002782464725896716f, 0.0035118316300213337f, 0.004062271676957607f, 0.004297621548175812f, 0.004569635726511478f, 0.002859831554815173f, 0.0038964475970715284f, 0.0037677432410418987f, 0.0020300820469856262f, 0.00248162355273962f, 0.003550770226866007f, 0.004960859660059214f, 0.004581113811582327f, 0.003120566951110959f, 0.007718103006482124f, 0.008189696818590164f, 0.002961300313472748f, 0.0026418869383633137f, 0.009778317995369434f, 0.002658020704984665f, 0.0038413682486861944f, 0.003547873580828309f, 0.003423993242904544f, 0.0031761284917593002f, 0.010359308682382107f, 0.004334374330937862f, 0.004828498233109713f, 0.005138730630278587f, 0.0049725971184670925f, 0.005815626587718725f, 0.0025427627842873335f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #293 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_Add_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.032728616148233414f),
    AI_PACK_INTQ_ZP(-103)))

/* Int quant #294 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.009600956924259663f),
    AI_PACK_INTQ_ZP(-99)))

/* Int quant #295 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003586982609704137f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #296 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03578191250562668f),
    AI_PACK_INTQ_ZP(61)))

/* Int quant #297 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03157258778810501f),
    AI_PACK_INTQ_ZP(-110)))

/* Int quant #298 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003702932968735695f, 0.001681137946434319f, 0.0022261005360633135f, 0.0008540453854948282f, 0.00250710709951818f, 0.0032071152236312628f, 0.0035115545615553856f, 0.0017875974299386144f, 0.0008798588532954454f, 0.0018495541298761964f, 0.0023906962014734745f, 0.003206358291208744f, 0.003217846155166626f, 0.0035083929542452097f, 0.002929551526904106f, 0.002805267693474889f, 0.0032106246799230576f, 0.0020332089625298977f, 0.0030659269541502f, 0.002237647771835327f, 0.0018333978950977325f, 0.0018943850882351398f, 0.0030938091222196817f, 0.0024261760991066694f, 0.003977689426392317f, 0.003133882535621524f, 0.0023272144608199596f, 0.004324807785451412f, 0.0022717455867677927f, 0.0046293544583022594f, 0.0017765741795301437f, 0.0025118053890764713f, 0.003809435060247779f, 0.002527927979826927f, 0.003158742329105735f, 0.0037078780587762594f, 0.002887557726353407f, 0.0038505508564412594f, 0.003931144252419472f, 0.0032087555155158043f, 0.003685120027512312f, 0.003114317776635289f, 0.002138483803719282f, 0.003349562408402562f, 0.0019803994800895452f, 0.00228712591342628f, 0.0016018503811210394f, 0.0021740535739809275f, 0.00214591808617115f, 0.002123540034517646f, 0.0023294121492654085f, 0.0027278740890324116f, 0.002566624665632844f, 0.0020535087678581476f, 0.0032262359745800495f, 0.0023173990193754435f, 0.0025016937870532274f, 0.004595728125423193f, 0.006928230635821819f, 0.0027637004386633635f, 0.003191225230693817f, 0.003973837476223707f, 0.001682253205217421f, 0.002935299649834633f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #299 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.01673215813934803f),
    AI_PACK_INTQ_ZP(-111)))

/* Int quant #300 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00385489035397768f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #301 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02951768971979618f),
    AI_PACK_INTQ_ZP(-10)))

/* Int quant #302 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.009600956924259663f),
    AI_PACK_INTQ_ZP(-99)))

/* Int quant #303 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_6_m_1_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 64,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.006255014333873987f, 0.0076599689200520515f, 0.008931177668273449f, 0.007133348844945431f, 0.005888850428164005f, 0.0052315304055809975f, 0.0045244391076266766f, 0.005994743667542934f, 0.0058830720372498035f, 0.006162213161587715f, 0.004960633814334869f, 0.03513561189174652f, 0.010382476262748241f, 0.008184511214494705f, 0.004742833320051432f, 0.006953383795917034f, 0.004771835170686245f, 0.007363772951066494f, 0.009871072135865688f, 0.008256498724222183f, 0.006350724957883358f, 0.011724703945219517f, 0.00535229966044426f, 0.005749023985117674f, 0.007862037047743797f, 0.0074504525400698185f, 0.006088613998144865f, 0.006759359501302242f, 0.006044046021997929f, 0.006014279555529356f, 0.005812088027596474f, 0.008872597478330135f, 0.005344068165868521f, 0.004856044426560402f, 0.006359293591231108f, 0.006943843327462673f, 0.006425376981496811f, 0.008091808296740055f, 0.004915321245789528f, 0.0038803378120064735f, 0.008395127020776272f, 0.010056504048407078f, 0.005151169840246439f, 0.006562839262187481f, 0.013035657815635204f, 0.004565555136650801f, 0.0037834884133189917f, 0.007024758495390415f, 0.011316563002765179f, 0.006532389670610428f, 0.01098580937832594f, 0.007012887857854366f, 0.006155174691230059f, 0.009121217764914036f, 0.005638741888105869f, 0.009177115745842457f, 0.006633748300373554f, 0.007541180122643709f, 0.009375086985528469f, 0.007128078490495682f, 0.0058114794082939625f, 0.009646927006542683f, 0.005948150996118784f, 0.006899280473589897f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #304 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_7_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.022311581298708916f),
    AI_PACK_INTQ_ZP(-116)))

/* Int quant #305 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_7_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00390453333966434f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #306 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_7_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.04244241490960121f),
    AI_PACK_INTQ_ZP(-1)))

/* Int quant #307 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_7_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.013548851013183594f),
    AI_PACK_INTQ_ZP(-107)))

/* Int quant #308 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_7_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 256,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0023834840394556522f, 0.0017029903829097748f, 0.0023789519909769297f, 0.003237077733501792f, 0.00241629290394485f, 0.003176626982167363f, 0.0024296105839312077f, 0.00341728120110929f, 0.0036094316747039557f, 0.0032431287690997124f, 0.0024442519061267376f, 0.0021557805594056845f, 0.0026601559948176146f, 0.0022498012986034155f, 0.0024454270023852587f, 0.0036805279087275267f, 0.002796935150399804f, 0.0025176601484417915f, 0.0022824739571660757f, 0.003661609487608075f, 0.0012731559108942747f, 0.002339399652555585f, 0.002847755793482065f, 0.0021368605084717274f, 0.00273989699780941f, 0.0024575621355324984f, 0.0033495393581688404f, 0.0016446267254650593f, 0.0038197494577616453f, 0.001785042230039835f, 0.0020956629887223244f, 0.0023178181145340204f, 0.0032996463123708963f, 0.0022135358303785324f, 0.0035896613262593746f, 0.004044506698846817f, 0.003067001234740019f, 0.0031317356042563915f, 0.0029318053275346756f, 0.0035151580814272165f, 0.002249653683975339f, 0.0028497378807514906f, 0.0015649741981178522f, 0.002771049737930298f, 0.0029964277055114508f, 0.002280204091221094f, 0.0024898918345570564f, 0.0020472833421081305f, 0.0017483364790678024f, 0.0021588897798210382f, 0.0024761103559285402f, 0.002389195142313838f, 0.0022861920297145844f, 0.0028099052142351866f, 0.0033027820754796267f, 0.0023691116366535425f, 0.004420456942170858f, 0.0025581989903002977f, 0.0023995579686015844f, 0.0033921629656106234f, 0.0018759358208626509f, 0.0028233639895915985f, 0.0028263835702091455f, 0.0029104682616889477f, 0.0026885410770773888f, 0.0016331094084307551f, 0.0014480615500360727f, 0.00391676789149642f, 0.002512996783480048f, 0.004355424549430609f, 0.0018816007068380713f, 0.007499269209802151f, 0.003234181785956025f, 0.0024231786374002695f, 0.0024692548904567957f, 0.0022756147664040327f, 0.0024200789630413055f, 0.0033223512582480907f, 0.0023272098042070866f, 0.00182751112151891f, 0.002342314925044775f, 0.0019176697824150324f, 0.001667087897658348f, 0.0017543175490573049f, 0.002836492843925953f, 0.0029313936829566956f, 0.0025843088515102863f, 0.0034994331654161215f, 0.0025988509878516197f, 0.002184422453865409f, 0.001905828365124762f, 0.003865238279104233f, 0.0026842670049518347f, 0.003277992131188512f, 0.0023600284475833178f, 0.0018705293769016862f, 0.0037050661630928516f, 0.0019970389548689127f, 0.005130372475832701f, 0.002853351179510355f, 0.0028876573778688908f, 0.003409295342862606f, 0.002579149091616273f, 0.0021775788627564907f, 0.0033972379751503468f, 0.0026841233484447002f, 0.0017395546892657876f, 0.004256250336766243f, 0.002666075713932514f, 0.0021556487772613764f, 0.0036655389703810215f, 0.003272836562246084f, 0.0022159649524837732f, 0.004778171423822641f, 0.0024191869888454676f, 0.0015717846108600497f, 0.002461212920024991f, 0.0029972493648529053f, 0.0022197188809514046f, 0.001968122087419033f, 0.0018999918829649687f, 0.001613086205907166f, 0.0026638356503099203f, 0.002815928077325225f, 0.002806495875120163f, 0.002627461450174451f, 0.003243669169023633f, 0.002561619272455573f, 0.0018710935255512595f, 0.002147132530808449f, 0.0018548326333984733f, 0.0031644892878830433f, 0.0031229443848133087f, 0.003746429458260536f, 0.0024991221725940704f, 0.0028880895115435123f, 0.003231337061151862f, 0.001996732549741864f, 0.001922988216392696f, 0.004541858099400997f, 0.0023614473175257444f, 0.0032552387565374374f, 0.0022288679610937834f, 0.005572082940489054f, 0.0026100524701178074f, 0.0019458197057247162f, 0.0034443121403455734f, 0.0018557292642071843f, 0.0035974052734673023f, 0.003420495428144932f, 0.0021909584756940603f, 0.0037682950496673584f, 0.0032579528633505106f, 0.005528512876480818f, 0.002811228856444359f, 0.0022592798341065645f, 0.002716751303523779f, 0.0025556290056556463f, 0.0032524976413697004f, 0.0031897774897515774f, 0.0027843595016747713f, 0.0028384746983647346f, 0.004229631740599871f, 0.0021939314901828766f, 0.002814155537635088f, 0.005146723240613937f, 0.001556314411573112f, 0.0042777033522725105f, 0.002314570127055049f, 0.0029371173586696386f, 0.003299375530332327f, 0.00230817636474967f, 0.001986344810575247f, 0.0022613490000367165f, 0.0020664946641772985f, 0.004085120279341936f, 0.0016385498456656933f, 0.005632312968373299f, 0.0022379946894943714f, 0.0021568583324551582f, 0.002556425053626299f, 0.0028039980679750443f, 0.0027330664452165365f, 0.003381561255082488f, 0.0023752423003315926f, 0.0024244156666100025f, 0.0025173083413392305f, 0.0020786591339856386f, 0.0026299073360860348f, 0.002211715327575803f, 0.003360783215612173f, 0.0037553890142589808f, 0.002843643771484494f, 0.0024848002940416336f, 0.002476413268595934f, 0.003519086865708232f, 0.0038162986747920513f, 0.003577791154384613f, 0.0021084793843328953f, 0.0029481330420821905f, 0.004656538832932711f, 0.0036935668904334307f, 0.0019157849019393325f, 0.0027868624310940504f, 0.0023119200486689806f, 0.002958964090794325f, 0.0018622737843543291f, 0.002331529976800084f, 0.0024467280600219965f, 0.0030114820692688227f, 0.0016493102302774787f, 0.0021611147094517946f, 0.0024421578273177147f, 0.002532690530642867f, 0.0025802289601415396f, 0.0015218292828649282f, 0.0016956247854977846f, 0.002894483506679535f, 0.0023797249887138605f, 0.002725411904975772f, 0.0031340811401605606f, 0.003021418582648039f, 0.0023485980927944183f, 0.00579140754416585f, 0.002897998783737421f, 0.0013489073608070612f, 0.003567029256373644f, 0.0029060181695967913f, 0.002213274361565709f, 0.0023637358099222183f, 0.0018136685248464346f, 0.002699269214645028f, 0.002219489775598049f, 0.0013342800084501505f, 0.0014840817311778665f, 0.0018458934500813484f, 0.004665891174226999f, 0.0025930232368409634f, 0.006509443279355764f, 0.0020762146450579166f, 0.00241565378382802f, 0.0021426721941679716f, 0.0025520415510982275f, 0.001923475181683898f, 0.0034721666015684605f, 0.00262869312427938f, 0.0026301220059394836f, 0.002530203666538f, 0.002702208235859871f, 0.0034339737612754107f, 0.0017892394680529833f, 0.002666344866156578f, 0.003193741664290428f, 0.002047366462647915f, 0.0022876407019793987f, 0.0025788890197873116f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #309 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.029339419677853584f),
    AI_PACK_INTQ_ZP(-109)))

/* Int quant #310 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_Split_output_0_output0_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02436774969100952f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #311 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_Split_output_0_output1_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02436774969100952f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #312 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02436774969100952f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #313 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003911383915692568f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #314 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05528063327074051f),
    AI_PACK_INTQ_ZP(19)))

/* Int quant #315 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 256,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.008648999035358429f, 0.006841148249804974f, 0.00860433280467987f, 0.006743296515196562f, 0.006411038339138031f, 0.007264626678079367f, 0.00871197134256363f, 0.006534280721098185f, 0.007948003709316254f, 0.00767276668921113f, 0.0066194976679980755f, 0.004916102159768343f, 0.008263605646789074f, 0.006659961771219969f, 0.008885985240340233f, 0.011225536465644836f, 0.007212334778159857f, 0.00677572563290596f, 0.00646423501893878f, 0.00668080011382699f, 0.0072412812151014805f, 0.00581886013969779f, 0.00782590452581644f, 0.008571438491344452f, 0.008562128990888596f, 0.004733181092888117f, 0.005089513026177883f, 0.007190796080976725f, 0.007648071739822626f, 0.008694714866578579f, 0.004881795030087233f, 0.008164617232978344f, 0.007687869481742382f, 0.007389089558273554f, 0.010679428465664387f, 0.008905229158699512f, 0.008111763745546341f, 0.006589144468307495f, 0.007454736158251762f, 0.006971575319766998f, 0.007439036387950182f, 0.007789280731230974f, 0.011213975958526134f, 0.0096200630068779f, 0.005500268191099167f, 0.0065344227477908134f, 0.007039185147732496f, 0.007147499825805426f, 0.007947894744575024f, 0.005903293844312429f, 0.006852597463876009f, 0.00506947934627533f, 0.005435297731310129f, 0.006507263984531164f, 0.005953695625066757f, 0.013871397823095322f, 0.007335542235523462f, 0.008605964481830597f, 0.004327214788645506f, 0.008873343467712402f, 0.010215546935796738f, 0.008218842558562756f, 0.006872016470879316f, 0.019934723153710365f, 0.013212754391133785f, 0.007391803432255983f, 0.00893987063318491f, 0.009434385225176811f, 0.008259354159235954f, 0.00900809932500124f, 0.004509321413934231f, 0.017992742359638214f, 0.00841875933110714f, 0.009445405565202236f, 0.005305494647473097f, 0.01102632749825716f, 0.007071562577039003f, 0.0065335482358932495f, 0.008120697923004627f, 0.005215560086071491f, 0.00973132811486721f, 0.006168047431856394f, 0.005333314649760723f, 0.009702127426862717f, 0.009658997878432274f, 0.008464664220809937f, 0.004267191514372826f, 0.006622582674026489f, 0.008171597495675087f, 0.006806449498981237f, 0.006053193937987089f, 0.011055494658648968f, 0.0062623717822134495f, 0.007553684525191784f, 0.006970413029193878f, 0.005460884887725115f, 0.005468172952532768f, 0.006935466546565294f, 0.013427679426968098f, 0.007016724906861782f, 0.007055568043142557f, 0.005665225442498922f, 0.008322019129991531f, 0.0067464737221598625f, 0.0056741368025541306f, 0.009185031056404114f, 0.012879888527095318f, 0.006724344100803137f, 0.006248823367059231f, 0.011542471125721931f, 0.005445215385407209f, 0.005678328685462475f, 0.009438062086701393f, 0.008270329795777798f, 0.008798855356872082f, 0.008550457656383514f, 0.005910511594265699f, 0.0102922935038805f, 0.006849916186183691f, 0.005499371327459812f, 0.007930271327495575f, 0.005580028519034386f, 0.007921523414552212f, 0.0039798966608941555f, 0.01528188120573759f, 0.00628312723711133f, 0.005071851424872875f, 0.008126147091388702f, 0.0036665243096649647f, 0.006849053781479597f, 0.006249717902392149f, 0.0029913755133748055f, 0.005360736977308989f, 0.007009776774793863f, 0.0025859051384031773f, 0.006630815099924803f, 0.003813382936641574f, 0.006568189710378647f, 0.0044623431749641895f, 0.006171178538352251f, 0.011036129668354988f, 0.005679193418473005f, 0.003545931773260236f, 0.005257035605609417f, 0.003986173775047064f, 0.009826065972447395f, 0.003914209548383951f, 0.0057395342737436295f, 0.006081322208046913f, 0.006582831963896751f, 0.0038523967377841473f, 0.006882282439619303f, 0.006474863272160292f, 0.004884006455540657f, 0.004443913698196411f, 0.002219006884843111f, 0.0022247019223868847f, 0.004146764520555735f, 0.004410186782479286f, 0.006968814413994551f, 0.0034177873749285936f, 0.004269181285053492f, 0.0053171259351074696f, 0.0035182987339794636f, 0.007384512573480606f, 0.004316240549087524f, 0.0065404805354774f, 0.005050431005656719f, 0.0056426022201776505f, 0.0021863989531993866f, 0.003598045092076063f, 0.002879719715565443f, 0.0036601198371499777f, 0.006677396595478058f, 0.0031352294608950615f, 0.00543803907930851f, 0.005515702534466982f, 0.004186168313026428f, 0.004126534331589937f, 0.002591993659734726f, 0.009154249913990498f, 0.003543727332726121f, 0.00325375865213573f, 0.004615706857293844f, 0.004510458093136549f, 0.005440317559987307f, 0.0062415460124611855f, 0.005939569789916277f, 0.008108641020953655f, 0.005303116515278816f, 0.004271747078746557f, 0.005288995336741209f, 0.004572926089167595f, 0.005462429951876402f, 0.008876067586243153f, 0.003633781336247921f, 0.010073640383780003f, 0.007313827518373728f, 0.005315711721777916f, 0.00406075082719326f, 0.0070270816795527935f, 0.005550474859774113f, 0.003202209947630763f, 0.0054168361239135265f, 0.005452340934425592f, 0.00667416350916028f, 0.003400745103135705f, 0.007016007788479328f, 0.0036709944251924753f, 0.005312291439622641f, 0.002881835214793682f, 0.005400819703936577f, 0.00861265603452921f, 0.002697411458939314f, 0.004061675630509853f, 0.00657330546528101f, 0.003434752579778433f, 0.0037359900306910276f, 0.007361216004937887f, 0.006359446793794632f, 0.003672522958368063f, 0.0062423888593912125f, 0.004733947571367025f, 0.005225833039730787f, 0.0042080204002559185f, 0.004446397535502911f, 0.0044774324633181095f, 0.005642282776534557f, 0.0028844885528087616f, 0.0032586492598056793f, 0.004772578831762075f, 0.006985919550061226f, 0.005390333943068981f, 0.005055624060332775f, 0.004288796801120043f, 0.006289322394877672f, 0.003918346483260393f, 0.009082384407520294f, 0.00471108965575695f, 0.003695277264341712f, 0.0059472424909472466f, 0.0037795163225382566f, 0.004352130927145481f, 0.00573811586946249f, 0.0032662362791597843f, 0.0010061707580462098f, 0.0066923052072525024f, 0.003467900212854147f, 0.0036360935773700476f, 0.0026964284479618073f, 0.005981546826660633f, 0.003336625173687935f, 0.005071328021585941f, 0.003788509638980031f, 0.004613299388438463f, 0.005586274899542332f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #316 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.03254569694399834f),
    AI_PACK_INTQ_ZP(-119)))

/* Int quant #317 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003920283634215593f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #318 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05633823946118355f),
    AI_PACK_INTQ_ZP(-15)))

/* Int quant #319 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 256,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0014591633807867765f, 0.003017781302332878f, 0.002844305243343115f, 0.0031310785561800003f, 0.0032860771752893925f, 0.0024645894300192595f, 0.0029038621578365564f, 0.0020355726592242718f, 0.0023003597743809223f, 0.002054811455309391f, 0.003237811615690589f, 0.001898967893794179f, 0.0038737254217267036f, 0.0025344828609377146f, 0.0024243812076747417f, 0.002431144006550312f, 0.0030079707503318787f, 0.002082641003653407f, 0.0031350154895335436f, 0.0028523248620331287f, 0.001957099884748459f, 0.0016226287698373199f, 0.002083938103169203f, 0.0028269272297620773f, 0.0032322388142347336f, 0.0030930880457162857f, 0.002405670704320073f, 0.002787642879411578f, 0.0026504460256546736f, 0.002354575553908944f, 0.0025777150876820087f, 0.005447764415293932f, 0.0015693645691499114f, 0.0025498864706605673f, 0.003771385410800576f, 0.002947558183223009f, 0.0030474928207695484f, 0.0024254813324660063f, 0.0032760798931121826f, 0.002851296216249466f, 0.0019060522317886353f, 0.0024378830567002296f, 0.001954530831426382f, 0.0017883054679259658f, 0.0027768565341830254f, 0.0025008772499859333f, 0.0021568986121565104f, 0.0025318670086562634f, 0.005351862870156765f, 0.0026891969610005617f, 0.001987545983865857f, 0.002303851768374443f, 0.002011240692809224f, 0.0014681157190352678f, 0.006204551551491022f, 0.0032312562689185143f, 0.0030853543430566788f, 0.0026022857055068016f, 0.003373107872903347f, 0.0015080174198374152f, 0.00203743320889771f, 0.002246138406917453f, 0.001586691476404667f, 0.002168697537854314f, 0.0026673327665776014f, 0.001868311665020883f, 0.0027450015768408775f, 0.0033585394266992807f, 0.0026902498211711645f, 0.002316592261195183f, 0.0037215310148894787f, 0.0026677423156797886f, 0.002590455813333392f, 0.001686770818196237f, 0.002161442767828703f, 0.0026949963066726923f, 0.0020571048371493816f, 0.0017123023280873895f, 0.002764460863545537f, 0.0022450746037065983f, 0.0017087403684854507f, 0.0033748175483196974f, 0.002335087163373828f, 0.0021305170375853777f, 0.0028740507550537586f, 0.0024892825167626143f, 0.002793030347675085f, 0.0013666305458173156f, 0.0052766576409339905f, 0.0033952335361391306f, 0.0025306560564786196f, 0.0033256581518799067f, 0.002622160129249096f, 0.0028352648951113224f, 0.002154463669285178f, 0.0017269467934966087f, 0.0028982232324779034f, 0.00458316458389163f, 0.00404938030987978f, 0.003473180579021573f, 0.0021323838736861944f, 0.002169588580727577f, 0.003224901156499982f, 0.005253834184259176f, 0.0021583535708487034f, 0.004041860345751047f, 0.001566971419379115f, 0.0028469255194067955f, 0.0023771878331899643f, 0.0027117819990962744f, 0.0031665111891925335f, 0.003760005347430706f, 0.002733752364292741f, 0.0026216073893010616f, 0.002181094139814377f, 0.0022368573118001223f, 0.002144979313015938f, 0.004043519031256437f, 0.0044152396731078625f, 0.002303807530552149f, 0.002057843841612339f, 0.001644608797505498f, 0.0021132505498826504f, 0.003086772747337818f, 0.002169511979445815f, 0.0019236927619203925f, 0.0027207781095057726f, 0.001984147820621729f, 0.003040568670257926f, 0.002481407718732953f, 0.002300024963915348f, 0.0027181184850633144f, 0.0036791260354220867f, 0.0015384984435513616f, 0.004068251233547926f, 0.0021713252644985914f, 0.002214024541899562f, 0.002246604999527335f, 0.0023152197245508432f, 0.002881934866309166f, 0.0013856254518032074f, 0.002110590459778905f, 0.0034244570415467024f, 0.002382736885920167f, 0.002437880029901862f, 0.00229170941747725f, 0.0020984213333576918f, 0.0012852799845859408f, 0.0018465672619640827f, 0.003526420332491398f, 0.001082646194845438f, 0.003016815287992358f, 0.003578953444957733f, 0.0021646295208483934f, 0.0022144566755741835f, 0.002929452806711197f, 0.0030438329558819532f, 0.0042037502862513065f, 0.001939173904247582f, 0.0035157513339072466f, 0.002716894494369626f, 0.0029424712993204594f, 0.0017335705924779177f, 0.0026800010818988085f, 0.0018560526659712195f, 0.0023572526406496763f, 0.0017624403117224574f, 0.004733142908662558f, 0.0012959270970895886f, 0.002338561462238431f, 0.0019804213661700487f, 0.003519926918670535f, 0.002788484562188387f, 0.0027142176404595375f, 0.0036593766417354345f, 0.0036203882191330194f, 0.0015347935259342194f, 0.003195299534127116f, 0.002163142431527376f, 0.0034503128845244646f, 0.00233197002671659f, 0.002899088431149721f, 0.0025499912444502115f, 0.0029898856300860643f, 0.002633729251101613f, 0.0018204018706455827f, 0.0031690748874098063f, 0.003957158885896206f, 0.0027695188764482737f, 0.0022084808442741632f, 0.0029691339004784822f, 0.0020951793994754553f, 0.0037310239858925343f, 0.002490994054824114f, 0.0018984365742653608f, 0.002163659082725644f, 0.002799875335767865f, 0.003443835536018014f, 0.002227433491498232f, 0.0016539169009774923f, 0.0025231412146240473f, 0.0023491561878472567f, 0.0020713568665087223f, 0.002730568405240774f, 0.0015588750829920173f, 0.0031792239751666784f, 0.0023927059955894947f, 0.002416708040982485f, 0.002896745689213276f, 0.0025979147758334875f, 0.0017719793831929564f, 0.0037639890797436237f, 0.00354468310251832f, 0.004090686794370413f, 0.0020498395897448063f, 0.005349482875317335f, 0.005451733246445656f, 0.0015920434379950166f, 0.0019355324329808354f, 0.0038761221803724766f, 0.0024169853422790766f, 0.004850392695516348f, 0.0045836628414690495f, 0.004841370042413473f, 0.0021616145968437195f, 0.0014842954697087407f, 0.0022536995820701122f, 0.002530774101614952f, 0.0028330201748758554f, 0.0014419270446524024f, 0.001709990669041872f, 0.0032742673065513372f, 0.0016105686081573367f, 0.002336746547371149f, 0.0024230568669736385f, 0.002973070601001382f, 0.004269319586455822f, 0.003028532490134239f, 0.0027772425673902035f, 0.0031154139433056116f, 0.0022905960213392973f, 0.0015863461885601282f, 0.002242225920781493f, 0.0021237325854599476f, 0.002553473459556699f, 0.0028529998380690813f, 0.0027976816054433584f, 0.0025798354763537645f, 0.0023953919298946857f, 0.0020649901125580072f, 0.0029237382113933563f, 0.0035135657526552677f, 0.0017096421215683222f, 0.002638021716848016f, 0.0036884204018861055f, 0.003490842180326581f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #320 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_Add_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.029339419677853584f),
    AI_PACK_INTQ_ZP(-109)))

/* Int quant #321 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.018394840881228447f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #322 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0038768805097788572f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #323 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.06262142211198807f),
    AI_PACK_INTQ_ZP(56)))

/* Int quant #324 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02436774969100952f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #325 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.005135741550475359f, 0.0028179329819977283f, 0.003668319433927536f, 0.0028492489363998175f, 0.0028155457694083452f, 0.003526068292558193f, 0.0027362958062440157f, 0.0040453337132930756f, 0.004465337842702866f, 0.004351627081632614f, 0.00463556544855237f, 0.00534015754237771f, 0.0025727872271090746f, 0.005237111356109381f, 0.003448914038017392f, 0.005006421823054552f, 0.0041352128610014915f, 0.0044606346637010574f, 0.00530276820063591f, 0.0033921028953045607f, 0.0035485548432916403f, 0.0055172801949083805f, 0.0017461709212511778f, 0.0035317137371748686f, 0.0040204268880188465f, 0.002967286854982376f, 0.00489406194537878f, 0.006685125641524792f, 0.004765249323099852f, 0.002982810605317354f, 0.0045572011731565f, 0.0034214667975902557f, 0.00488703278824687f, 0.002569722244516015f, 0.003972569480538368f, 0.003043389180675149f, 0.002765513025224209f, 0.005874586291611195f, 0.005432406440377235f, 0.00476960139349103f, 0.0038748320657759905f, 0.005254493560642004f, 0.005049410741776228f, 0.002817438216879964f, 0.003005471546202898f, 0.002902236068621278f, 0.00328438775613904f, 0.004898927640169859f, 0.004420841578394175f, 0.006451537366956472f, 0.0026244695764034986f, 0.0041722580790519714f, 0.0022325078025460243f, 0.0031797653064131737f, 0.004681350663304329f, 0.006840754300355911f, 0.0052960095927119255f, 0.003290922613814473f, 0.0007494704332202673f, 0.002999573014676571f, 0.004752440378069878f, 0.0053674825467169285f, 0.00537443021312356f, 0.004411549307405949f, 0.0040620919317007065f, 0.0033998526632785797f, 0.0062632132321596146f, 0.00558059848845005f, 0.004071323666721582f, 0.002150237560272217f, 0.0035553774796426296f, 0.0034177503548562527f, 0.004221034236252308f, 0.0030541683081537485f, 0.006230418104678392f, 0.003421987174078822f, 0.005325045436620712f, 0.00516505679115653f, 0.0048016952350735664f, 0.0023191100917756557f, 0.003971866797655821f, 0.004923529457300901f, 0.005890092812478542f, 0.0033680519554764032f, 0.003501353319734335f, 0.002497307723388076f, 0.0060202996246516705f, 0.005063144490122795f, 0.006047384813427925f, 0.002629190683364868f, 0.0025588020216673613f, 0.005706151016056538f, 0.007878507487475872f, 0.00599444005638361f, 0.008421515114605427f, 0.004549080040305853f, 0.005298056174069643f, 0.0037309452891349792f, 0.0054859439842402935f, 0.006033783778548241f, 0.006365435663610697f, 0.004820587113499641f, 0.005249619018286467f, 0.0036136580165475607f, 0.004002136178314686f, 0.004224775824695826f, 0.002802295843139291f, 0.005380415823310614f, 0.005401694215834141f, 0.002631509443745017f, 0.004649061243981123f, 0.005732162389904261f, 0.004042832646518946f, 0.004283216316252947f, 0.007113599684089422f, 0.004708912223577499f, 0.003608194412663579f, 0.0052190073765814304f, 0.003615183290094137f, 0.0031699645332992077f, 0.004298918880522251f, 0.006112589500844479f, 0.004902104381471872f, 0.005552539136260748f, 0.0035529020242393017f, 0.0032189725898206234f, 0.005550996400415897f, 0.005352266598492861f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #326 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.02874833717942238f),
    AI_PACK_INTQ_ZP(-118)))

/* Int quant #327 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003918198402971029f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #328 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.05791030451655388f),
    AI_PACK_INTQ_ZP(5)))

/* Int quant #329 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.018394840881228447f),
    AI_PACK_INTQ_ZP(-113)))

/* Int quant #330 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_8_m_0_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0031980308704078197f, 0.004897766280919313f, 0.004185661673545837f, 0.004134682472795248f, 0.003865378675982356f, 0.0018345596035942435f, 0.003493308322504163f, 0.00606413371860981f, 0.0035123953130096197f, 0.0032277810387313366f, 0.003221256425604224f, 0.0028797038830816746f, 0.004004171583801508f, 0.0024921391159296036f, 0.014292199164628983f, 0.005669990088790655f, 0.002814484992995858f, 0.0047193169593811035f, 0.00210260646417737f, 0.0035023181699216366f, 0.002517788438126445f, 0.003155296202749014f, 0.0019486407982185483f, 0.004917851649224758f, 0.002906028414145112f, 0.002557713072746992f, 0.0027874440420418978f, 0.002484068972989917f, 0.0030564754270017147f, 0.0029738149605691433f, 0.003173137316480279f, 0.0064103808254003525f, 0.0028758698608726263f, 0.0024704409297555685f, 0.003154964419081807f, 0.00624736538156867f, 0.0031355342362076044f, 0.003151179291307926f, 0.0024904818274080753f, 0.0027768006548285484f, 0.005453875754028559f, 0.0019454057328402996f, 0.005073737818747759f, 0.00252473633736372f, 0.002824652474373579f, 0.003153508063405752f, 0.0038831804413348436f, 0.0034271569456905127f, 0.0023400201462209225f, 0.004692276008427143f, 0.002652488648891449f, 0.004539710469543934f, 0.0033283703960478306f, 0.0024270988069474697f, 0.0033586453646421432f, 0.0023271830286830664f, 0.007978349924087524f, 0.00410370621830225f, 0.0027626410592347383f, 0.0027536051347851753f, 0.009175889194011688f, 0.003155521582812071f, 0.004716342780739069f, 0.0034583916421979666f, 0.0024442749563604593f, 0.0031918503809720278f, 0.0031286017037928104f, 0.003163147484883666f, 0.002171378582715988f, 0.0023631963413208723f, 0.003721860470250249f, 0.002683087019249797f, 0.0022800590377300978f, 0.005830918438732624f, 0.0029285040218383074f, 0.0038956678472459316f, 0.002588856965303421f, 0.0035001649521291256f, 0.004398087039589882f, 0.002987705171108246f, 0.004107183311134577f, 0.0026147314347326756f, 0.00468750623986125f, 0.003235332667827606f, 0.002776915207505226f, 0.002920351456850767f, 0.0054425629787147045f, 0.0018756863428279757f, 0.0030205019284039736f, 0.0025110398419201374f, 0.0030197352170944214f, 0.002663777442649007f, 0.0035438898485153913f, 0.002048722468316555f, 0.0025029992684721947f, 0.0030545436311513186f, 0.003991484642028809f, 0.003790306393057108f, 0.003650583093985915f, 0.0022565191611647606f, 0.003465189365670085f, 0.0025950255803763866f, 0.0025798955466598272f, 0.0047585079446434975f, 0.0032469755969941616f, 0.00536714494228363f, 0.002234548330307007f, 0.0025062935892492533f, 0.00690344488248229f, 0.0028251521289348602f, 0.004485371522605419f, 0.0025729078333824873f, 0.0024742584209889174f, 0.003460378386080265f, 0.002903799992054701f, 0.0028279125690460205f, 0.0038261031731963158f, 0.0036059406120330095f, 0.0024404749274253845f, 0.0020428888965398073f, 0.002544593531638384f, 0.003996127750724554f, 0.005203629843890667f, 0.005362102296203375f, 0.0038639444392174482f, 0.00225660833530128f, 0.005127741023898125f, 0.006217353977262974f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #331 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_Concat_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.026356305927038193f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #332 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv1_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.026356305927038193f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #333 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv1_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003915396053344011f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #334 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv1_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.0552196130156517f),
    AI_PACK_INTQ_ZP(10)))

/* Int quant #335 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv1_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 128,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.002401202917098999f, 0.0019051734125241637f, 0.003643601667135954f, 0.0037662305403500795f, 0.003442732384428382f, 0.00296038668602705f, 0.003482246771454811f, 0.012802660465240479f, 0.006093091331422329f, 0.006099783815443516f, 0.004374113865196705f, 0.0027090462390333414f, 0.0020048082806169987f, 0.006480321288108826f, 0.0027157876174896955f, 0.004564865957945585f, 0.004199606366455555f, 0.004131672438234091f, 0.0053457655012607574f, 0.002289183670654893f, 0.004501212853938341f, 0.002804795280098915f, 0.004373111296445131f, 0.0028926909435540438f, 0.0028051992412656546f, 0.0026531119365245104f, 0.005396087188273668f, 0.0025959177874028683f, 0.004118206445127726f, 0.0036375527270138264f, 0.003148392541334033f, 0.0034588829148560762f, 0.008124849759042263f, 0.0030582668259739876f, 0.003509830217808485f, 0.004033028148114681f, 0.0022260400000959635f, 0.002128561260178685f, 0.003410402685403824f, 0.0032445332035422325f, 0.0032486633863300085f, 0.001726503949612379f, 0.005315974820405245f, 0.0028699759859591722f, 0.004355994518846273f, 0.0032446507830172777f, 0.008285404182970524f, 0.0061986506916582584f, 0.003058427246287465f, 0.0022487910464406013f, 0.003323325188830495f, 0.004736709874123335f, 0.0035994998179376125f, 0.0036298863124102354f, 0.002218645764514804f, 0.014360735192894936f, 0.0025795295368880033f, 0.0018188778776675463f, 0.003016242291778326f, 0.002868055133149028f, 0.004721390083432198f, 0.00333032151684165f, 0.007783039938658476f, 0.0024788633454591036f, 0.0027707647532224655f, 0.002817306201905012f, 0.002929795067757368f, 0.004797975532710552f, 0.003102366579696536f, 0.0034538228064775467f, 0.0027477846015244722f, 0.004044065717607737f, 0.0031972145661711693f, 0.0036208622623234987f, 0.004683243110775948f, 0.0035795464646071196f, 0.004655707161873579f, 0.0021738081704825163f, 0.0037972412537783384f, 0.0030201817862689495f, 0.0138699384406209f, 0.004378813318908215f, 0.002610245253890753f, 0.003253281582146883f, 0.002703374484553933f, 0.002468569204211235f, 0.002321690320968628f, 0.002980682998895645f, 0.0069299135357141495f, 0.002297259634360671f, 0.004329090006649494f, 0.0028519935440272093f, 0.008243774063885212f, 0.003141379449516535f, 0.005149131175130606f, 0.0034430676605552435f, 0.0036424945574253798f, 0.0033049581106752157f, 0.003178440732881427f, 0.003480656538158655f, 0.004143185913562775f, 0.002670029643923044f, 0.0037479372695088387f, 0.00532567547634244f, 0.0026568984612822533f, 0.007032428868114948f, 0.004242684692144394f, 0.0027194865979254246f, 0.0027437154203653336f, 0.0030539841391146183f, 0.0036794168408960104f, 0.003480293322354555f, 0.0016519607743248343f, 0.0037855934351682663f, 0.003785550594329834f, 0.0045546879991889f, 0.003005389589816332f, 0.0035297651775181293f, 0.00307639641687274f, 0.0037394382525235415f, 0.001786086242645979f, 0.0027056096587330103f, 0.0022808616049587727f, 0.003844748018309474f, 0.009303742088377476f, 0.0023456192575395107f, 0.0036684281658381224f, 0.0035585868172347546f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #336 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv2_act_Mul_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.016189144924283028f),
    AI_PACK_INTQ_ZP(-111)))

/* Int quant #337 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv2_act_Sigmoid_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003845700528472662f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #338 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv2_conv_Conv_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.041463084518909454f),
    AI_PACK_INTQ_ZP(32)))

/* Int quant #339 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_cv2_conv_Conv_output_0_weights_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 256,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.00030597858130931854f, 0.001775463460944593f, 0.0011895921779796481f, 0.001166379195638001f, 0.0020430427975952625f, 0.001531451940536499f, 0.001813590875826776f, 0.0025441981852054596f, 0.000978107564151287f, 0.0024160558823496103f, 0.0005424490082077682f, 0.0008817547932267189f, 0.000880316598340869f, 0.0013060896890237927f, 0.0012334133498370647f, 0.0008019618690013885f, 0.0012735716300085187f, 0.0005825732368975878f, 0.0009237229241989553f, 0.0010216832160949707f, 0.0005045775324106216f, 0.0016893480205908418f, 0.001221291022375226f, 0.0017394942697137594f, 0.0007655276567675173f, 0.0019407871877774596f, 0.0011762672802433372f, 0.000992884743027389f, 0.0010467005195096135f, 0.0007952300366014242f, 0.0004272575315553695f, 0.0016111716395244002f, 0.000832142133731395f, 0.0009654070599935949f, 0.0017243005568161607f, 0.0010509771527722478f, 0.0017496225191280246f, 0.0014618781860917807f, 0.0013912521535530686f, 0.0006584115326404572f, 0.000599712016992271f, 0.0008197255665436387f, 0.0016287274193018675f, 0.0009517156868241727f, 0.0006284172995947301f, 0.0018808881286531687f, 0.0018193400464951992f, 0.0007073237793520093f, 0.0005222827312536538f, 0.0008813361055217683f, 0.0008811581647023559f, 0.000819159671664238f, 0.001188362599350512f, 0.0006137117743492126f, 0.0005038686213083565f, 0.0015688473358750343f, 0.001156751299276948f, 0.004050693940371275f, 0.0008243121556006372f, 0.0010143263498321176f, 0.0021494340617209673f, 0.0009277254575863481f, 0.000857357052154839f, 0.001444155117496848f, 0.0005943007417954504f, 0.0006800189148634672f, 0.002897972008213401f, 0.0021977799478918314f, 0.0015438193222507834f, 0.0013214477803558111f, 0.0005010287859477103f, 0.0006038520368747413f, 0.0007736522238701582f, 0.002102921949699521f, 0.0011408599093556404f, 0.0006725561106577516f, 0.0014241058379411697f, 0.0007426508818753064f, 0.0029111462645232677f, 0.0004885117523372173f, 0.0007366678910329938f, 0.001840938231907785f, 0.0007475449237972498f, 0.00162966747302562f, 0.0012248632265254855f, 0.0020552226342260838f, 0.002467596670612693f, 0.0008862848626449704f, 0.00046946838847361505f, 0.0021488843485713005f, 0.003907815087586641f, 0.0007005259394645691f, 0.0015412766952067614f, 0.0007501368527300656f, 0.0013974538305774331f, 0.0008163575548678637f, 0.0017215717816725373f, 0.0020937693770974874f, 0.0010254967492073774f, 0.0018630726262927055f, 0.0007051536813378334f, 0.0009040501900017262f, 0.0012852248037233949f, 0.0007772399694658816f, 0.0019209341844543815f, 0.0013909797416999936f, 0.000822658184915781f, 0.0009053605026565492f, 0.000571785494685173f, 0.0014817039482295513f, 0.001903299824334681f, 0.0010612935293465853f, 0.0009802893036976457f, 0.0008447045693174005f, 0.0020113433711230755f, 0.0010022529168054461f, 0.001402632100507617f, 0.0015254175523295999f, 0.0010380507446825504f, 0.0008590928046032786f, 0.0007075525936670601f, 0.0025072358548641205f, 0.0009382020798511803f, 0.0007910918211564422f, 0.000550884404219687f, 0.0016933694714680314f, 0.001009917352348566f, 0.0005505475564859807f, 0.0020974401850253344f, 0.0006103513296693563f, 0.0007969664293341339f, 0.0011464213021099567f, 0.0014837478520348668f, 0.0010671589989215136f, 0.0015857007820159197f, 0.0010047012474387884f, 0.0008270357502624393f, 0.004475036635994911f, 0.0008271282422356308f, 0.0008674736018292606f, 0.0014725596411153674f, 0.0024990926031023264f, 0.0009476798004470766f, 0.0016515410970896482f, 0.00045033005881123245f, 0.0008710630354471505f, 0.0006238966016098857f, 0.0008037092629820108f, 0.00135403114836663f, 0.0011265015928074718f, 0.0013536132173612714f, 0.00135322124697268f, 0.0008624412002973258f, 0.0018299720250070095f, 0.0007136004278436303f, 0.0011574707459658384f, 0.0012804607395082712f, 0.002352270530536771f, 0.0010898556793108582f, 0.0013783008325845003f, 0.0009052365203388035f, 0.0006420611753128469f, 0.0009473023819737136f, 0.0011784073431044817f, 0.0033892998471856117f, 0.001331087201833725f, 0.001225059386342764f, 0.0010066655231639743f, 0.0007311487570405006f, 0.000998979085125029f, 0.0013951208675280213f, 0.0009497137507423759f, 0.001379861612804234f, 0.0011344928061589599f, 0.0007452596328221262f, 0.0009507043287158012f, 0.0014810592401772738f, 0.0009751840843819082f, 0.0020901449024677277f, 0.0013872236013412476f, 0.0012407933827489614f, 0.0012184713268652558f, 0.0018251340370625257f, 0.001569407875649631f, 0.0008237372385337949f, 0.0013689538463950157f, 0.0005229398375377059f, 0.0011719053145498037f, 0.002283709356561303f, 0.0009699410875327885f, 0.0009814841905608773f, 0.0009563405183143914f, 0.0009529706439934671f, 0.0024170957040041685f, 0.0006365862209349871f, 0.0010680722771212459f, 0.0019021553453058004f, 0.00247638626024127f, 0.0005059521645307541f, 0.0010598663939163089f, 0.0013421116163954139f, 0.0014229293446987867f, 0.001704460009932518f, 0.0015554568963125348f, 0.0016175300115719438f, 0.0008517818641848862f, 0.0007428230019286275f, 0.0011184801114723086f, 0.0009404263691976666f, 0.000984041253104806f, 0.0008201994351111352f, 0.0012853409862145782f, 0.0014783996157348156f, 0.0011087189195677638f, 0.0005071791238151491f, 0.0008472295594401658f, 0.0019083985826000571f, 0.003049328224733472f, 0.0017934130737558007f, 0.0013152980245649815f, 0.0014289793325588107f, 0.0006456863484345376f, 0.0007015746086835861f, 0.0015015038661658764f, 0.0009001771686598659f, 0.0007851423579268157f, 0.0011865355772897601f, 0.00045339969801716506f, 0.001011428190395236f, 0.001118736807256937f, 0.0008402704261243343f, 0.0014513013884425163f, 0.0012418256374076009f, 0.0006302624824456871f, 0.000900782470125705f, 0.001217370736412704f, 0.0010106558911502361f, 0.0006408311310224235f, 0.0013980892254039645f, 0.0009072036482393742f, 0.0013789176009595394f, 0.0013020574115216732f, 0.002631173003464937f, 0.001749088754877448f, 0.0006121773621998727f, 0.0015692571178078651f, 0.0006957217119634151f, 0.0012928450014442205f, 0.0015533872647210956f, 0.0006332028424367309f, 0.0007333524408750236f, 0.0014220539014786482f, 0.0019410484237596393f, 0.0026892840396612883f, 0.0010480193886905909f, 0.0015953818801790476f),
    AI_PACK_INTQ_ZP(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)))

/* Int quant #340 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_m_1_MaxPool_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.026356305927038193f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #341 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_m_2_MaxPool_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.026356305927038193f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #342 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(_model_9_m_MaxPool_output_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.026356305927038193f),
    AI_PACK_INTQ_ZP(-117)))

/* Int quant #343 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(images_Transpose_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921566531062126f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #344 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(images_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(0.003921566531062126f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #345 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(output0_QuantizeLinear_Input_Transpose_0_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(1.1799200773239136f),
    AI_PACK_INTQ_ZP(-128)))

/* Int quant #346 */
AI_INTQ_INFO_LIST_OBJ_DECLARE(output0_QuantizeLinear_Input_output_array_intq, AI_STATIC_CONST,
  AI_BUFFER_META_FLAG_SCALE_FLOAT|AI_BUFFER_META_FLAG_ZEROPOINT_S8, 1,
  AI_PACK_INTQ_INFO(
    AI_PACK_INTQ_SCALE(1.1799200773239136f),
    AI_PACK_INTQ_ZP(-128)))

/**  Tensor declarations section  *********************************************/
/* Tensor #0 */
AI_TENSOR_OBJ_DECLARE(
  _model_0_act_Mul_output_0_output, AI_STATIC,
  0, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 80, 80), AI_STRIDE_INIT(4, 1, 1, 16, 1280),
  1, &_model_0_act_Mul_output_0_output_array, &_model_0_act_Mul_output_0_output_array_intq)

/* Tensor #1 */
AI_TENSOR_OBJ_DECLARE(
  _model_0_act_Sigmoid_output_0_output, AI_STATIC,
  1, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 80, 80), AI_STRIDE_INIT(4, 1, 1, 16, 1280),
  1, &_model_0_act_Sigmoid_output_0_output_array, &_model_0_act_Sigmoid_output_0_output_array_intq)

/* Tensor #2 */
AI_TENSOR_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_bias, AI_STATIC,
  2, 0x0,
  AI_SHAPE_INIT(4, 1, 16, 1, 1), AI_STRIDE_INIT(4, 4, 4, 64, 64),
  1, &_model_0_conv_Conv_output_0_bias_array, NULL)

/* Tensor #3 */
AI_TENSOR_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_output, AI_STATIC,
  3, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 80, 80), AI_STRIDE_INIT(4, 1, 1, 16, 1280),
  1, &_model_0_conv_Conv_output_0_output_array, &_model_0_conv_Conv_output_0_output_array_intq)

/* Tensor #4 */
AI_TENSOR_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_scratch0, AI_STATIC,
  4, 0x0,
  AI_SHAPE_INIT(4, 1, 1196, 1, 1), AI_STRIDE_INIT(4, 1, 1, 1196, 1196),
  1, &_model_0_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #5 */
AI_TENSOR_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_weights, AI_STATIC,
  5, 0x1,
  AI_SHAPE_INIT(4, 3, 3, 3, 16), AI_STRIDE_INIT(4, 1, 3, 48, 144),
  1, &_model_0_conv_Conv_output_0_weights_array, &_model_0_conv_Conv_output_0_weights_array_intq)

/* Tensor #6 */
AI_TENSOR_OBJ_DECLARE(
  _model_10_Resize_output_0_output, AI_STATIC,
  6, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 10, 10), AI_STRIDE_INIT(4, 1, 1, 256, 2560),
  1, &_model_10_Resize_output_0_output_array, &_model_10_Resize_output_0_output_array_intq)

/* Tensor #7 */
AI_TENSOR_OBJ_DECLARE(
  _model_11_Concat_output_0_output, AI_STATIC,
  7, 0x1,
  AI_SHAPE_INIT(4, 1, 384, 10, 10), AI_STRIDE_INIT(4, 1, 1, 384, 3840),
  1, &_model_11_Concat_output_0_output_array, &_model_11_Concat_output_0_output_array_intq)

/* Tensor #8 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_Concat_output_0_output, AI_STATIC,
  8, 0x1,
  AI_SHAPE_INIT(4, 1, 192, 10, 10), AI_STRIDE_INIT(4, 1, 1, 192, 1920),
  1, &_model_12_Concat_output_0_output_array, &_model_12_Concat_output_0_output_array_intq)

/* Tensor #9 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_Split_output_0_num_or_size_splits, AI_STATIC,
  9, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_12_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #10 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_Split_output_0_output0, AI_STATIC,
  10, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_Split_output_0_output0_array, &_model_12_Split_output_0_output0_array_intq)

/* Tensor #11 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_Split_output_0_output1, AI_STATIC,
  11, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_Split_output_0_output1_array, &_model_12_Split_output_0_output1_array_intq)

/* Tensor #12 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv1_act_Mul_output_0_output, AI_STATIC,
  12, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_12_cv1_act_Mul_output_0_output_array, &_model_12_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #13 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  13, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_12_cv1_act_Sigmoid_output_0_output_array, &_model_12_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #14 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_bias, AI_STATIC,
  14, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_12_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #15 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_output, AI_STATIC,
  15, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_12_cv1_conv_Conv_output_0_output_array, &_model_12_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #16 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  16, 0x0,
  AI_SHAPE_INIT(4, 1, 2816, 1, 1), AI_STRIDE_INIT(4, 1, 1, 2816, 2816),
  1, &_model_12_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #17 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_weights, AI_STATIC,
  17, 0x1,
  AI_SHAPE_INIT(4, 384, 1, 1, 128), AI_STRIDE_INIT(4, 1, 384, 49152, 49152),
  1, &_model_12_cv1_conv_Conv_output_0_weights_array, &_model_12_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #18 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv2_act_Mul_output_0_output, AI_STATIC,
  18, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_12_cv2_act_Mul_output_0_output_array, &_model_12_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #19 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  19, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_12_cv2_act_Sigmoid_output_0_output_array, &_model_12_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #20 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_bias, AI_STATIC,
  20, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_12_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #21 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_output, AI_STATIC,
  21, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_12_cv2_conv_Conv_output_0_output_array, &_model_12_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #22 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  22, 0x0,
  AI_SHAPE_INIT(4, 1, 2048, 1, 1), AI_STRIDE_INIT(4, 1, 1, 2048, 2048),
  1, &_model_12_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #23 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_weights, AI_STATIC,
  23, 0x1,
  AI_SHAPE_INIT(4, 192, 1, 1, 128), AI_STRIDE_INIT(4, 1, 192, 24576, 24576),
  1, &_model_12_cv2_conv_Conv_output_0_weights_array, &_model_12_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #24 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  24, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_m_0_cv1_act_Mul_output_0_output_array, &_model_12_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #25 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  25, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_12_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #26 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  26, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_12_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #27 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  27, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_m_0_cv1_conv_Conv_output_0_output_array, &_model_12_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #28 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  28, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_12_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_12_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #29 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  29, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_12_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #30 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  30, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_12_m_0_cv1_conv_Conv_output_0_weights_array, &_model_12_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #31 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  31, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_m_0_cv2_act_Mul_output_0_output_array, &_model_12_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #32 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  32, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_12_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #33 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  33, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_12_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #34 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  34, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_12_m_0_cv2_conv_Conv_output_0_output_array, &_model_12_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #35 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  35, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_12_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_12_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #36 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  36, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_12_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #37 */
AI_TENSOR_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  37, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_12_m_0_cv2_conv_Conv_output_0_weights_array, &_model_12_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #38 */
AI_TENSOR_OBJ_DECLARE(
  _model_13_Resize_output_0_output, AI_STATIC,
  38, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 20, 20), AI_STRIDE_INIT(4, 1, 1, 128, 2560),
  1, &_model_13_Resize_output_0_output_array, &_model_13_Resize_output_0_output_array_intq)

/* Tensor #39 */
AI_TENSOR_OBJ_DECLARE(
  _model_14_Concat_output_0_output, AI_STATIC,
  39, 0x1,
  AI_SHAPE_INIT(4, 1, 192, 20, 20), AI_STRIDE_INIT(4, 1, 1, 192, 3840),
  1, &_model_14_Concat_output_0_output_array, &_model_14_Concat_output_0_output_array_intq)

/* Tensor #40 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_Concat_output_0_output, AI_STATIC,
  40, 0x1,
  AI_SHAPE_INIT(4, 1, 96, 20, 20), AI_STRIDE_INIT(4, 1, 1, 96, 1920),
  1, &_model_15_Concat_output_0_output_array, &_model_15_Concat_output_0_output_array_intq)

/* Tensor #41 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_Split_output_0_num_or_size_splits, AI_STATIC,
  41, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_15_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #42 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_Split_output_0_output0, AI_STATIC,
  42, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_Split_output_0_output0_array, &_model_15_Split_output_0_output0_array_intq)

/* Tensor #43 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_Split_output_0_output1, AI_STATIC,
  43, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_Split_output_0_output1_array, &_model_15_Split_output_0_output1_array_intq)

/* Tensor #44 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv1_act_Mul_output_0_output, AI_STATIC,
  44, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_15_cv1_act_Mul_output_0_output_array, &_model_15_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #45 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  45, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_15_cv1_act_Sigmoid_output_0_output_array, &_model_15_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #46 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_bias, AI_STATIC,
  46, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_15_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #47 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_output, AI_STATIC,
  47, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_15_cv1_conv_Conv_output_0_output_array, &_model_15_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #48 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  48, 0x0,
  AI_SHAPE_INIT(4, 1, 1408, 1, 1), AI_STRIDE_INIT(4, 1, 1, 1408, 1408),
  1, &_model_15_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #49 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_weights, AI_STATIC,
  49, 0x1,
  AI_SHAPE_INIT(4, 192, 1, 1, 64), AI_STRIDE_INIT(4, 1, 192, 12288, 12288),
  1, &_model_15_cv1_conv_Conv_output_0_weights_array, &_model_15_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #50 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv2_act_Mul_output_0_output, AI_STATIC,
  50, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_15_cv2_act_Mul_output_0_output_array, &_model_15_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #51 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  51, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_15_cv2_act_Sigmoid_output_0_output_array, &_model_15_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #52 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_bias, AI_STATIC,
  52, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_15_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #53 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_output, AI_STATIC,
  53, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_15_cv2_conv_Conv_output_0_output_array, &_model_15_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #54 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  54, 0x0,
  AI_SHAPE_INIT(4, 1, 1024, 1, 1), AI_STRIDE_INIT(4, 1, 1, 1024, 1024),
  1, &_model_15_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #55 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_weights, AI_STATIC,
  55, 0x1,
  AI_SHAPE_INIT(4, 96, 1, 1, 64), AI_STRIDE_INIT(4, 1, 96, 6144, 6144),
  1, &_model_15_cv2_conv_Conv_output_0_weights_array, &_model_15_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #56 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  56, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_m_0_cv1_act_Mul_output_0_output_array, &_model_15_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #57 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  57, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_15_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #58 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  58, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_15_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #59 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  59, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_m_0_cv1_conv_Conv_output_0_output_array, &_model_15_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #60 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  60, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 22, 22), AI_STRIDE_INIT(4, 1, 1, 32, 704),
  1, &_model_15_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_15_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #61 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  61, 0x0,
  AI_SHAPE_INIT(4, 1, 6720, 1, 1), AI_STRIDE_INIT(4, 1, 1, 6720, 6720),
  1, &_model_15_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #62 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  62, 0x1,
  AI_SHAPE_INIT(4, 32, 3, 3, 32), AI_STRIDE_INIT(4, 1, 32, 1024, 3072),
  1, &_model_15_m_0_cv1_conv_Conv_output_0_weights_array, &_model_15_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #63 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  63, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_m_0_cv2_act_Mul_output_0_output_array, &_model_15_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #64 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  64, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_15_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #65 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  65, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_15_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #66 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  66, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_15_m_0_cv2_conv_Conv_output_0_output_array, &_model_15_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #67 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  67, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 22, 22), AI_STRIDE_INIT(4, 1, 1, 32, 704),
  1, &_model_15_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_15_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #68 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  68, 0x0,
  AI_SHAPE_INIT(4, 1, 6720, 1, 1), AI_STRIDE_INIT(4, 1, 1, 6720, 6720),
  1, &_model_15_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #69 */
AI_TENSOR_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  69, 0x1,
  AI_SHAPE_INIT(4, 32, 3, 3, 32), AI_STRIDE_INIT(4, 1, 32, 1024, 3072),
  1, &_model_15_m_0_cv2_conv_Conv_output_0_weights_array, &_model_15_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #70 */
AI_TENSOR_OBJ_DECLARE(
  _model_16_act_Mul_output_0_output, AI_STATIC,
  70, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_16_act_Mul_output_0_output_array, &_model_16_act_Mul_output_0_output_array_intq)

/* Tensor #71 */
AI_TENSOR_OBJ_DECLARE(
  _model_16_act_Sigmoid_output_0_output, AI_STATIC,
  71, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_16_act_Sigmoid_output_0_output_array, &_model_16_act_Sigmoid_output_0_output_array_intq)

/* Tensor #72 */
AI_TENSOR_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_bias, AI_STATIC,
  72, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_16_conv_Conv_output_0_bias_array, NULL)

/* Tensor #73 */
AI_TENSOR_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_output, AI_STATIC,
  73, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_16_conv_Conv_output_0_output_array, &_model_16_conv_Conv_output_0_output_array_intq)

/* Tensor #74 */
AI_TENSOR_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_pad_before_output, AI_STATIC,
  74, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 22, 22), AI_STRIDE_INIT(4, 1, 1, 64, 1408),
  1, &_model_16_conv_Conv_output_0_pad_before_output_array, &_model_16_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #75 */
AI_TENSOR_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_scratch0, AI_STATIC,
  75, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_16_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #76 */
AI_TENSOR_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_weights, AI_STATIC,
  76, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_16_conv_Conv_output_0_weights_array, &_model_16_conv_Conv_output_0_weights_array_intq)

/* Tensor #77 */
AI_TENSOR_OBJ_DECLARE(
  _model_17_Concat_output_0_output, AI_STATIC,
  77, 0x1,
  AI_SHAPE_INIT(4, 1, 192, 10, 10), AI_STRIDE_INIT(4, 1, 1, 192, 1920),
  1, &_model_17_Concat_output_0_output_array, &_model_17_Concat_output_0_output_array_intq)

/* Tensor #78 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_Concat_output_0_output, AI_STATIC,
  78, 0x1,
  AI_SHAPE_INIT(4, 1, 192, 10, 10), AI_STRIDE_INIT(4, 1, 1, 192, 1920),
  1, &_model_18_Concat_output_0_output_array, &_model_18_Concat_output_0_output_array_intq)

/* Tensor #79 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_Split_output_0_num_or_size_splits, AI_STATIC,
  79, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_18_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #80 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_Split_output_0_output0, AI_STATIC,
  80, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_Split_output_0_output0_array, &_model_18_Split_output_0_output0_array_intq)

/* Tensor #81 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_Split_output_0_output1, AI_STATIC,
  81, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_Split_output_0_output1_array, &_model_18_Split_output_0_output1_array_intq)

/* Tensor #82 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv1_act_Mul_output_0_output, AI_STATIC,
  82, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_18_cv1_act_Mul_output_0_output_array, &_model_18_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #83 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  83, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_18_cv1_act_Sigmoid_output_0_output_array, &_model_18_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #84 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_bias, AI_STATIC,
  84, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_18_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #85 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_output, AI_STATIC,
  85, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_18_cv1_conv_Conv_output_0_output_array, &_model_18_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #86 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  86, 0x0,
  AI_SHAPE_INIT(4, 1, 2048, 1, 1), AI_STRIDE_INIT(4, 1, 1, 2048, 2048),
  1, &_model_18_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #87 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_weights, AI_STATIC,
  87, 0x1,
  AI_SHAPE_INIT(4, 192, 1, 1, 128), AI_STRIDE_INIT(4, 1, 192, 24576, 24576),
  1, &_model_18_cv1_conv_Conv_output_0_weights_array, &_model_18_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #88 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv2_act_Mul_output_0_output, AI_STATIC,
  88, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_18_cv2_act_Mul_output_0_output_array, &_model_18_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #89 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  89, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_18_cv2_act_Sigmoid_output_0_output_array, &_model_18_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #90 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_bias, AI_STATIC,
  90, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_18_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #91 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_output, AI_STATIC,
  91, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_18_cv2_conv_Conv_output_0_output_array, &_model_18_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #92 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  92, 0x0,
  AI_SHAPE_INIT(4, 1, 2048, 1, 1), AI_STRIDE_INIT(4, 1, 1, 2048, 2048),
  1, &_model_18_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #93 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_weights, AI_STATIC,
  93, 0x1,
  AI_SHAPE_INIT(4, 192, 1, 1, 128), AI_STRIDE_INIT(4, 1, 192, 24576, 24576),
  1, &_model_18_cv2_conv_Conv_output_0_weights_array, &_model_18_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #94 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  94, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_m_0_cv1_act_Mul_output_0_output_array, &_model_18_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #95 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  95, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_18_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #96 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  96, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_18_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #97 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  97, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_m_0_cv1_conv_Conv_output_0_output_array, &_model_18_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #98 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  98, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_18_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_18_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #99 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  99, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_18_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #100 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  100, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_18_m_0_cv1_conv_Conv_output_0_weights_array, &_model_18_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #101 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  101, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_m_0_cv2_act_Mul_output_0_output_array, &_model_18_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #102 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  102, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_18_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #103 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  103, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_18_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #104 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  104, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_18_m_0_cv2_conv_Conv_output_0_output_array, &_model_18_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #105 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  105, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_18_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_18_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #106 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  106, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_18_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #107 */
AI_TENSOR_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  107, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_18_m_0_cv2_conv_Conv_output_0_weights_array, &_model_18_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #108 */
AI_TENSOR_OBJ_DECLARE(
  _model_19_act_Mul_output_0_output, AI_STATIC,
  108, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_19_act_Mul_output_0_output_array, &_model_19_act_Mul_output_0_output_array_intq)

/* Tensor #109 */
AI_TENSOR_OBJ_DECLARE(
  _model_19_act_Sigmoid_output_0_output, AI_STATIC,
  109, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_19_act_Sigmoid_output_0_output_array, &_model_19_act_Sigmoid_output_0_output_array_intq)

/* Tensor #110 */
AI_TENSOR_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_bias, AI_STATIC,
  110, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_19_conv_Conv_output_0_bias_array, NULL)

/* Tensor #111 */
AI_TENSOR_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_output, AI_STATIC,
  111, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_19_conv_Conv_output_0_output_array, &_model_19_conv_Conv_output_0_output_array_intq)

/* Tensor #112 */
AI_TENSOR_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_pad_before_output, AI_STATIC,
  112, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 12, 12), AI_STRIDE_INIT(4, 1, 1, 128, 1536),
  1, &_model_19_conv_Conv_output_0_pad_before_output_array, &_model_19_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #113 */
AI_TENSOR_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_scratch0, AI_STATIC,
  113, 0x0,
  AI_SHAPE_INIT(4, 1, 11520, 1, 1), AI_STRIDE_INIT(4, 1, 1, 11520, 11520),
  1, &_model_19_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #114 */
AI_TENSOR_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_weights, AI_STATIC,
  114, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 128), AI_STRIDE_INIT(4, 1, 128, 16384, 49152),
  1, &_model_19_conv_Conv_output_0_weights_array, &_model_19_conv_Conv_output_0_weights_array_intq)

/* Tensor #115 */
AI_TENSOR_OBJ_DECLARE(
  _model_1_act_Mul_output_0_output, AI_STATIC,
  115, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_1_act_Mul_output_0_output_array, &_model_1_act_Mul_output_0_output_array_intq)

/* Tensor #116 */
AI_TENSOR_OBJ_DECLARE(
  _model_1_act_Sigmoid_output_0_output, AI_STATIC,
  116, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_1_act_Sigmoid_output_0_output_array, &_model_1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #117 */
AI_TENSOR_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_bias, AI_STATIC,
  117, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #118 */
AI_TENSOR_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_output, AI_STATIC,
  118, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_1_conv_Conv_output_0_output_array, &_model_1_conv_Conv_output_0_output_array_intq)

/* Tensor #119 */
AI_TENSOR_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_scratch0, AI_STATIC,
  119, 0x0,
  AI_SHAPE_INIT(4, 1, 6144, 1, 1), AI_STRIDE_INIT(4, 1, 1, 6144, 6144),
  1, &_model_1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #120 */
AI_TENSOR_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_weights, AI_STATIC,
  120, 0x1,
  AI_SHAPE_INIT(4, 16, 3, 3, 32), AI_STRIDE_INIT(4, 1, 16, 512, 1536),
  1, &_model_1_conv_Conv_output_0_weights_array, &_model_1_conv_Conv_output_0_weights_array_intq)

/* Tensor #121 */
AI_TENSOR_OBJ_DECLARE(
  _model_20_Concat_output_0_output, AI_STATIC,
  121, 0x1,
  AI_SHAPE_INIT(4, 1, 384, 5, 5), AI_STRIDE_INIT(4, 1, 1, 384, 1920),
  1, &_model_20_Concat_output_0_output_array, &_model_20_Concat_output_0_output_array_intq)

/* Tensor #122 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_Concat_output_0_output, AI_STATIC,
  122, 0x1,
  AI_SHAPE_INIT(4, 1, 384, 5, 5), AI_STRIDE_INIT(4, 1, 1, 384, 1920),
  1, &_model_21_Concat_output_0_output_array, &_model_21_Concat_output_0_output_array_intq)

/* Tensor #123 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_Split_output_0_num_or_size_splits, AI_STATIC,
  123, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_21_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #124 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_Split_output_0_output0, AI_STATIC,
  124, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_Split_output_0_output0_array, &_model_21_Split_output_0_output0_array_intq)

/* Tensor #125 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_Split_output_0_output1, AI_STATIC,
  125, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_Split_output_0_output1_array, &_model_21_Split_output_0_output1_array_intq)

/* Tensor #126 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv1_act_Mul_output_0_output, AI_STATIC,
  126, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_21_cv1_act_Mul_output_0_output_array, &_model_21_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #127 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  127, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_21_cv1_act_Sigmoid_output_0_output_array, &_model_21_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #128 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_bias, AI_STATIC,
  128, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 4, 4, 1024, 1024),
  1, &_model_21_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #129 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_output, AI_STATIC,
  129, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_21_cv1_conv_Conv_output_0_output_array, &_model_21_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #130 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  130, 0x0,
  AI_SHAPE_INIT(4, 1, 4096, 1, 1), AI_STRIDE_INIT(4, 1, 1, 4096, 4096),
  1, &_model_21_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #131 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_weights, AI_STATIC,
  131, 0x1,
  AI_SHAPE_INIT(4, 384, 1, 1, 256), AI_STRIDE_INIT(4, 1, 384, 98304, 98304),
  1, &_model_21_cv1_conv_Conv_output_0_weights_array, &_model_21_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #132 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv2_act_Mul_output_0_output, AI_STATIC,
  132, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_21_cv2_act_Mul_output_0_output_array, &_model_21_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #133 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  133, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_21_cv2_act_Sigmoid_output_0_output_array, &_model_21_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #134 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_bias, AI_STATIC,
  134, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 4, 4, 1024, 1024),
  1, &_model_21_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #135 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_output, AI_STATIC,
  135, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_21_cv2_conv_Conv_output_0_output_array, &_model_21_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #136 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  136, 0x0,
  AI_SHAPE_INIT(4, 1, 4096, 1, 1), AI_STRIDE_INIT(4, 1, 1, 4096, 4096),
  1, &_model_21_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #137 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_weights, AI_STATIC,
  137, 0x1,
  AI_SHAPE_INIT(4, 384, 1, 1, 256), AI_STRIDE_INIT(4, 1, 384, 98304, 98304),
  1, &_model_21_cv2_conv_Conv_output_0_weights_array, &_model_21_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #138 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  138, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_m_0_cv1_act_Mul_output_0_output_array, &_model_21_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #139 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  139, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_21_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #140 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  140, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_21_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #141 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  141, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_m_0_cv1_conv_Conv_output_0_output_array, &_model_21_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #142 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  142, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 7, 7), AI_STRIDE_INIT(4, 1, 1, 128, 896),
  1, &_model_21_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_21_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #143 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  143, 0x0,
  AI_SHAPE_INIT(4, 1, 11520, 1, 1), AI_STRIDE_INIT(4, 1, 1, 11520, 11520),
  1, &_model_21_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #144 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  144, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 128), AI_STRIDE_INIT(4, 1, 128, 16384, 49152),
  1, &_model_21_m_0_cv1_conv_Conv_output_0_weights_array, &_model_21_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #145 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  145, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_m_0_cv2_act_Mul_output_0_output_array, &_model_21_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #146 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  146, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_21_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #147 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  147, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_21_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #148 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  148, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_21_m_0_cv2_conv_Conv_output_0_output_array, &_model_21_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #149 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  149, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 7, 7), AI_STRIDE_INIT(4, 1, 1, 128, 896),
  1, &_model_21_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_21_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #150 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  150, 0x0,
  AI_SHAPE_INIT(4, 1, 11520, 1, 1), AI_STRIDE_INIT(4, 1, 1, 11520, 11520),
  1, &_model_21_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #151 */
AI_TENSOR_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  151, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 128), AI_STRIDE_INIT(4, 1, 128, 16384, 49152),
  1, &_model_21_m_0_cv2_conv_Conv_output_0_weights_array, &_model_21_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #152 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Add_1_output_0_output, AI_STATIC,
  152, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Add_1_output_0_output_array, &_model_22_Add_1_output_0_output_array_intq)

/* Tensor #153 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_output, AI_STATIC,
  153, 0x0,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 4, 4, 8, 8),
  1, &_model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_output_array, NULL)

/* Tensor #154 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Add_2_output_0_output, AI_STATIC,
  154, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Add_2_output_0_output_array, &_model_22_Add_2_output_0_output_array_intq)

/* Tensor #155 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_1_output_0_output, AI_STATIC,
  155, 0x1,
  AI_SHAPE_INIT(4, 1, 65, 10, 10), AI_STRIDE_INIT(4, 1, 1, 65, 650),
  1, &_model_22_Concat_1_output_0_output_array, &_model_22_Concat_1_output_0_output_array_intq)

/* Tensor #156 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_1_output_0_output0, AI_STATIC,
  156, 0x1,
  AI_SHAPE_INIT(4, 1, 65, 1, 100), AI_STRIDE_INIT(4, 1, 1, 65, 65),
  1, &_model_22_Concat_1_output_0_output_array, &_model_22_Concat_1_output_0_output_array_intq)

/* Tensor #157 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_2_output_0_output, AI_STATIC,
  157, 0x1,
  AI_SHAPE_INIT(4, 1, 65, 5, 5), AI_STRIDE_INIT(4, 1, 1, 65, 325),
  1, &_model_22_Concat_2_output_0_output_array, &_model_22_Concat_2_output_0_output_array_intq)

/* Tensor #158 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_2_output_0_output0, AI_STATIC,
  158, 0x1,
  AI_SHAPE_INIT(4, 1, 65, 1, 25), AI_STRIDE_INIT(4, 1, 1, 65, 65),
  1, &_model_22_Concat_2_output_0_output_array, &_model_22_Concat_2_output_0_output_array_intq)

/* Tensor #159 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_3_output_0_output, AI_STATIC,
  159, 0x1,
  AI_SHAPE_INIT(4, 1, 65, 1, 525), AI_STRIDE_INIT(4, 1, 1, 65, 65),
  1, &_model_22_Concat_3_output_0_output_array, &_model_22_Concat_3_output_0_output_array_intq)

/* Tensor #160 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_4_output_0_output, AI_STATIC,
  160, 0x1,
  AI_SHAPE_INIT(4, 1, 4, 1, 525), AI_STRIDE_INIT(4, 1, 1, 4, 4),
  1, &_model_22_Concat_4_output_0_output_array, &_model_22_Concat_4_output_0_output_array_intq)

/* Tensor #161 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_output_0_output, AI_STATIC,
  161, 0x1,
  AI_SHAPE_INIT(4, 1, 65, 20, 20), AI_STRIDE_INIT(4, 1, 1, 65, 1300),
  1, &_model_22_Concat_output_0_output_array, &_model_22_Concat_output_0_output_array_intq)

/* Tensor #162 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Concat_output_0_output0, AI_STATIC,
  162, 0x1,
  AI_SHAPE_INIT(4, 1, 65, 1, 400), AI_STRIDE_INIT(4, 1, 1, 65, 65),
  1, &_model_22_Concat_output_0_output_array, &_model_22_Concat_output_0_output_array_intq)

/* Tensor #163 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Constant_10_output_0_DequantizeLinear_Output_const, AI_STATIC,
  163, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Constant_10_output_0_DequantizeLinear_Output_const_array, &_model_22_Constant_10_output_0_DequantizeLinear_Output_const_array_intq)

/* Tensor #164 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Constant_11_output_0_3D, AI_STATIC,
  164, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_22_Constant_11_output_0_3D_array, NULL)

/* Tensor #165 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D, AI_STATIC,
  165, 0x1,
  AI_SHAPE_INIT(4, 1, 1, 1, 525), AI_STRIDE_INIT(4, 1, 1, 1, 1),
  1, &_model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D_array, &_model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D_array_intq)

/* Tensor #166 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Constant_9_output_0, AI_STATIC,
  166, 0x0,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 4, 4, 8, 8),
  1, &_model_22_Constant_9_output_0_array, NULL)

/* Tensor #167 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output, AI_STATIC,
  167, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output_array, &_model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output_array_intq)

/* Tensor #168 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Div_1_output_0_output, AI_STATIC,
  168, 0x0,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 4, 4, 8, 8),
  1, &_model_22_Div_1_output_0_output_array, NULL)

/* Tensor #169 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Mul_2_output_0_output, AI_STATIC,
  169, 0x1,
  AI_SHAPE_INIT(4, 1, 4, 1, 525), AI_STRIDE_INIT(4, 1, 1, 4, 4),
  1, &_model_22_Mul_2_output_0_output_array, &_model_22_Mul_2_output_0_output_array_intq)

/* Tensor #170 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Sigmoid_output_0_output, AI_STATIC,
  170, 0x1,
  AI_SHAPE_INIT(4, 1, 1, 1, 525), AI_STRIDE_INIT(4, 1, 1, 1, 1),
  1, &_model_22_Sigmoid_output_0_output_array, &_model_22_Sigmoid_output_0_output_array_intq)

/* Tensor #171 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Slice_1_output_0_output, AI_STATIC,
  171, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Slice_1_output_0_output_array, &_model_22_Slice_1_output_0_output_array_intq)

/* Tensor #172 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_output, AI_STATIC,
  172, 0x0,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 4, 4, 8, 8),
  1, &_model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_output_array, NULL)

/* Tensor #173 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Slice_output_0_output, AI_STATIC,
  173, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Slice_output_0_output_array, &_model_22_Slice_output_0_output_array_intq)

/* Tensor #174 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Split_output_0_num_or_size_splits, AI_STATIC,
  174, 0x0,
  AI_SHAPE_INIT(4, 1, 2, 1, 1), AI_STRIDE_INIT(4, 4, 4, 8, 8),
  1, &_model_22_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #175 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Split_output_0_output0, AI_STATIC,
  175, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 1, 525), AI_STRIDE_INIT(4, 1, 1, 64, 64),
  1, &_model_22_Split_output_0_output0_array, &_model_22_Split_output_0_output0_array_intq)

/* Tensor #176 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Split_output_0_output1, AI_STATIC,
  176, 0x1,
  AI_SHAPE_INIT(4, 1, 1, 1, 525), AI_STRIDE_INIT(4, 1, 1, 1, 1),
  1, &_model_22_Split_output_0_output1_array, &_model_22_Split_output_0_output1_array_intq)

/* Tensor #177 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Sub_1_output_0_output, AI_STATIC,
  177, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Sub_1_output_0_output_array, &_model_22_Sub_1_output_0_output_array_intq)

/* Tensor #178 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output, AI_STATIC,
  178, 0x1,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 1, 1, 2, 2),
  1, &_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output_array, &_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output_array_intq)

/* Tensor #179 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_Sub_output_0_output, AI_STATIC,
  179, 0x0,
  AI_SHAPE_INIT(4, 1, 2, 1, 525), AI_STRIDE_INIT(4, 4, 4, 8, 8),
  1, &_model_22_Sub_output_0_output_array, NULL)

/* Tensor #180 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Mul_output_0_output, AI_STATIC,
  180, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv2_0_cv2_0_0_act_Mul_output_0_output_array, &_model_22_cv2_0_cv2_0_0_act_Mul_output_0_output_array_intq)

/* Tensor #181 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output, AI_STATIC,
  181, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output_array, &_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output_array_intq)

/* Tensor #182 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_bias, AI_STATIC,
  182, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_bias_array, NULL)

/* Tensor #183 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output, AI_STATIC,
  183, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output_array, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output_array_intq)

/* Tensor #184 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output, AI_STATIC,
  184, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 22, 22), AI_STRIDE_INIT(4, 1, 1, 64, 1408),
  1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output_array, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #185 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_scratch0, AI_STATIC,
  185, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #186 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights, AI_STATIC,
  186, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights_array, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights_array_intq)

/* Tensor #187 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Mul_output_0_output, AI_STATIC,
  187, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv2_0_cv2_0_1_act_Mul_output_0_output_array, &_model_22_cv2_0_cv2_0_1_act_Mul_output_0_output_array_intq)

/* Tensor #188 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output, AI_STATIC,
  188, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output_array, &_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #189 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_bias, AI_STATIC,
  189, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #190 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output, AI_STATIC,
  190, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output_array, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output_array_intq)

/* Tensor #191 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  191, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 22, 22), AI_STRIDE_INIT(4, 1, 1, 64, 1408),
  1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output_array, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #192 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_scratch0, AI_STATIC,
  192, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #193 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights, AI_STATIC,
  193, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights_array, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights_array_intq)

/* Tensor #194 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_bias, AI_STATIC,
  194, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_0_cv2_0_2_Conv_output_0_bias_array, NULL)

/* Tensor #195 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_output, AI_STATIC,
  195, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv2_0_cv2_0_2_Conv_output_0_output_array, &_model_22_cv2_0_cv2_0_2_Conv_output_0_output_array_intq)

/* Tensor #196 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_scratch0, AI_STATIC,
  196, 0x0,
  AI_SHAPE_INIT(4, 1, 896, 1, 1), AI_STRIDE_INIT(4, 1, 1, 896, 896),
  1, &_model_22_cv2_0_cv2_0_2_Conv_output_0_scratch0_array, NULL)

/* Tensor #197 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_weights, AI_STATIC,
  197, 0x1,
  AI_SHAPE_INIT(4, 64, 1, 1, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 4096),
  1, &_model_22_cv2_0_cv2_0_2_Conv_output_0_weights_array, &_model_22_cv2_0_cv2_0_2_Conv_output_0_weights_array_intq)

/* Tensor #198 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Mul_output_0_output, AI_STATIC,
  198, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv2_1_cv2_1_0_act_Mul_output_0_output_array, &_model_22_cv2_1_cv2_1_0_act_Mul_output_0_output_array_intq)

/* Tensor #199 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output, AI_STATIC,
  199, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output_array, &_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output_array_intq)

/* Tensor #200 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_bias, AI_STATIC,
  200, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_bias_array, NULL)

/* Tensor #201 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output, AI_STATIC,
  201, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output_array, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output_array_intq)

/* Tensor #202 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output, AI_STATIC,
  202, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 12, 12), AI_STRIDE_INIT(4, 1, 1, 128, 1536),
  1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output_array, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #203 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_scratch0, AI_STATIC,
  203, 0x0,
  AI_SHAPE_INIT(4, 1, 10624, 1, 1), AI_STRIDE_INIT(4, 1, 1, 10624, 10624),
  1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #204 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights, AI_STATIC,
  204, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 64), AI_STRIDE_INIT(4, 1, 128, 8192, 24576),
  1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights_array, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights_array_intq)

/* Tensor #205 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Mul_output_0_output, AI_STATIC,
  205, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv2_1_cv2_1_1_act_Mul_output_0_output_array, &_model_22_cv2_1_cv2_1_1_act_Mul_output_0_output_array_intq)

/* Tensor #206 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output, AI_STATIC,
  206, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output_array, &_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #207 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_bias, AI_STATIC,
  207, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #208 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output, AI_STATIC,
  208, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output_array, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output_array_intq)

/* Tensor #209 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  209, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output_array, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #210 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_scratch0, AI_STATIC,
  210, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #211 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights, AI_STATIC,
  211, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights_array, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights_array_intq)

/* Tensor #212 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_bias, AI_STATIC,
  212, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_1_cv2_1_2_Conv_output_0_bias_array, NULL)

/* Tensor #213 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_output, AI_STATIC,
  213, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv2_1_cv2_1_2_Conv_output_0_output_array, &_model_22_cv2_1_cv2_1_2_Conv_output_0_output_array_intq)

/* Tensor #214 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_scratch0, AI_STATIC,
  214, 0x0,
  AI_SHAPE_INIT(4, 1, 896, 1, 1), AI_STRIDE_INIT(4, 1, 1, 896, 896),
  1, &_model_22_cv2_1_cv2_1_2_Conv_output_0_scratch0_array, NULL)

/* Tensor #215 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_weights, AI_STATIC,
  215, 0x1,
  AI_SHAPE_INIT(4, 64, 1, 1, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 4096),
  1, &_model_22_cv2_1_cv2_1_2_Conv_output_0_weights_array, &_model_22_cv2_1_cv2_1_2_Conv_output_0_weights_array_intq)

/* Tensor #216 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Mul_output_0_output, AI_STATIC,
  216, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv2_2_cv2_2_0_act_Mul_output_0_output_array, &_model_22_cv2_2_cv2_2_0_act_Mul_output_0_output_array_intq)

/* Tensor #217 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output, AI_STATIC,
  217, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output_array, &_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output_array_intq)

/* Tensor #218 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_bias, AI_STATIC,
  218, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_bias_array, NULL)

/* Tensor #219 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output, AI_STATIC,
  219, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output_array, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output_array_intq)

/* Tensor #220 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output, AI_STATIC,
  220, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 7, 7), AI_STRIDE_INIT(4, 1, 1, 256, 1792),
  1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output_array, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #221 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_scratch0, AI_STATIC,
  221, 0x0,
  AI_SHAPE_INIT(4, 1, 15232, 1, 1), AI_STRIDE_INIT(4, 1, 1, 15232, 15232),
  1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #222 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights, AI_STATIC,
  222, 0x1,
  AI_SHAPE_INIT(4, 256, 3, 3, 64), AI_STRIDE_INIT(4, 1, 256, 16384, 49152),
  1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights_array, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights_array_intq)

/* Tensor #223 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Mul_output_0_output, AI_STATIC,
  223, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv2_2_cv2_2_1_act_Mul_output_0_output_array, &_model_22_cv2_2_cv2_2_1_act_Mul_output_0_output_array_intq)

/* Tensor #224 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output, AI_STATIC,
  224, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output_array, &_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #225 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_bias, AI_STATIC,
  225, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #226 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output, AI_STATIC,
  226, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output_array, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output_array_intq)

/* Tensor #227 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  227, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 7, 7), AI_STRIDE_INIT(4, 1, 1, 64, 448),
  1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output_array, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #228 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_scratch0, AI_STATIC,
  228, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #229 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights, AI_STATIC,
  229, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights_array, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights_array_intq)

/* Tensor #230 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_bias, AI_STATIC,
  230, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv2_2_cv2_2_2_Conv_output_0_bias_array, NULL)

/* Tensor #231 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_output, AI_STATIC,
  231, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv2_2_cv2_2_2_Conv_output_0_output_array, &_model_22_cv2_2_cv2_2_2_Conv_output_0_output_array_intq)

/* Tensor #232 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_scratch0, AI_STATIC,
  232, 0x0,
  AI_SHAPE_INIT(4, 1, 896, 1, 1), AI_STRIDE_INIT(4, 1, 1, 896, 896),
  1, &_model_22_cv2_2_cv2_2_2_Conv_output_0_scratch0_array, NULL)

/* Tensor #233 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_weights, AI_STATIC,
  233, 0x1,
  AI_SHAPE_INIT(4, 64, 1, 1, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 4096),
  1, &_model_22_cv2_2_cv2_2_2_Conv_output_0_weights_array, &_model_22_cv2_2_cv2_2_2_Conv_output_0_weights_array_intq)

/* Tensor #234 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Mul_output_0_output, AI_STATIC,
  234, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv3_0_cv3_0_0_act_Mul_output_0_output_array, &_model_22_cv3_0_cv3_0_0_act_Mul_output_0_output_array_intq)

/* Tensor #235 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output, AI_STATIC,
  235, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output_array, &_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output_array_intq)

/* Tensor #236 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_bias, AI_STATIC,
  236, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_bias_array, NULL)

/* Tensor #237 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output, AI_STATIC,
  237, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output_array, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output_array_intq)

/* Tensor #238 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output, AI_STATIC,
  238, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 22, 22), AI_STRIDE_INIT(4, 1, 1, 64, 1408),
  1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output_array, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #239 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_scratch0, AI_STATIC,
  239, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #240 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights, AI_STATIC,
  240, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights_array, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights_array_intq)

/* Tensor #241 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Mul_output_0_output, AI_STATIC,
  241, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv3_0_cv3_0_1_act_Mul_output_0_output_array, &_model_22_cv3_0_cv3_0_1_act_Mul_output_0_output_array_intq)

/* Tensor #242 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output, AI_STATIC,
  242, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output_array, &_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #243 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_bias, AI_STATIC,
  243, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #244 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output, AI_STATIC,
  244, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output_array, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output_array_intq)

/* Tensor #245 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  245, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 22, 22), AI_STRIDE_INIT(4, 1, 1, 64, 1408),
  1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output_array, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #246 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_scratch0, AI_STATIC,
  246, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #247 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights, AI_STATIC,
  247, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights_array, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights_array_intq)

/* Tensor #248 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_bias, AI_STATIC,
  248, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_22_cv3_0_cv3_0_2_Conv_output_0_bias_array, NULL)

/* Tensor #249 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_output, AI_STATIC,
  249, 0x1,
  AI_SHAPE_INIT(4, 1, 1, 20, 20), AI_STRIDE_INIT(4, 1, 1, 1, 20),
  1, &_model_22_cv3_0_cv3_0_2_Conv_output_0_output_array, &_model_22_cv3_0_cv3_0_2_Conv_output_0_output_array_intq)

/* Tensor #250 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_scratch0, AI_STATIC,
  250, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 1, 1, 256, 256),
  1, &_model_22_cv3_0_cv3_0_2_Conv_output_0_scratch0_array, NULL)

/* Tensor #251 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_weights, AI_STATIC,
  251, 0x1,
  AI_SHAPE_INIT(4, 64, 1, 1, 1), AI_STRIDE_INIT(4, 1, 64, 64, 64),
  1, &_model_22_cv3_0_cv3_0_2_Conv_output_0_weights_array, &_model_22_cv3_0_cv3_0_2_Conv_output_0_weights_array_intq)

/* Tensor #252 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Mul_output_0_output, AI_STATIC,
  252, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv3_1_cv3_1_0_act_Mul_output_0_output_array, &_model_22_cv3_1_cv3_1_0_act_Mul_output_0_output_array_intq)

/* Tensor #253 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output, AI_STATIC,
  253, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output_array, &_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output_array_intq)

/* Tensor #254 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_bias, AI_STATIC,
  254, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_bias_array, NULL)

/* Tensor #255 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output, AI_STATIC,
  255, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output_array, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output_array_intq)

/* Tensor #256 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output, AI_STATIC,
  256, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 12, 12), AI_STRIDE_INIT(4, 1, 1, 128, 1536),
  1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output_array, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #257 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_scratch0, AI_STATIC,
  257, 0x0,
  AI_SHAPE_INIT(4, 1, 10624, 1, 1), AI_STRIDE_INIT(4, 1, 1, 10624, 10624),
  1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #258 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights, AI_STATIC,
  258, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 64), AI_STRIDE_INIT(4, 1, 128, 8192, 24576),
  1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights_array, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights_array_intq)

/* Tensor #259 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Mul_output_0_output, AI_STATIC,
  259, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv3_1_cv3_1_1_act_Mul_output_0_output_array, &_model_22_cv3_1_cv3_1_1_act_Mul_output_0_output_array_intq)

/* Tensor #260 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output, AI_STATIC,
  260, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output_array, &_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #261 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_bias, AI_STATIC,
  261, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #262 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output, AI_STATIC,
  262, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output_array, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output_array_intq)

/* Tensor #263 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  263, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output_array, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #264 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_scratch0, AI_STATIC,
  264, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #265 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights, AI_STATIC,
  265, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights_array, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights_array_intq)

/* Tensor #266 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_bias, AI_STATIC,
  266, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_22_cv3_1_cv3_1_2_Conv_output_0_bias_array, NULL)

/* Tensor #267 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_output, AI_STATIC,
  267, 0x1,
  AI_SHAPE_INIT(4, 1, 1, 10, 10), AI_STRIDE_INIT(4, 1, 1, 1, 10),
  1, &_model_22_cv3_1_cv3_1_2_Conv_output_0_output_array, &_model_22_cv3_1_cv3_1_2_Conv_output_0_output_array_intq)

/* Tensor #268 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_scratch0, AI_STATIC,
  268, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 1, 1, 256, 256),
  1, &_model_22_cv3_1_cv3_1_2_Conv_output_0_scratch0_array, NULL)

/* Tensor #269 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_weights, AI_STATIC,
  269, 0x1,
  AI_SHAPE_INIT(4, 64, 1, 1, 1), AI_STRIDE_INIT(4, 1, 64, 64, 64),
  1, &_model_22_cv3_1_cv3_1_2_Conv_output_0_weights_array, &_model_22_cv3_1_cv3_1_2_Conv_output_0_weights_array_intq)

/* Tensor #270 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Mul_output_0_output, AI_STATIC,
  270, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv3_2_cv3_2_0_act_Mul_output_0_output_array, &_model_22_cv3_2_cv3_2_0_act_Mul_output_0_output_array_intq)

/* Tensor #271 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output, AI_STATIC,
  271, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output_array, &_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output_array_intq)

/* Tensor #272 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_bias, AI_STATIC,
  272, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_bias_array, NULL)

/* Tensor #273 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output, AI_STATIC,
  273, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output_array, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output_array_intq)

/* Tensor #274 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output, AI_STATIC,
  274, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 7, 7), AI_STRIDE_INIT(4, 1, 1, 256, 1792),
  1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output_array, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #275 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_scratch0, AI_STATIC,
  275, 0x0,
  AI_SHAPE_INIT(4, 1, 15232, 1, 1), AI_STRIDE_INIT(4, 1, 1, 15232, 15232),
  1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #276 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights, AI_STATIC,
  276, 0x1,
  AI_SHAPE_INIT(4, 256, 3, 3, 64), AI_STRIDE_INIT(4, 1, 256, 16384, 49152),
  1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights_array, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights_array_intq)

/* Tensor #277 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Mul_output_0_output, AI_STATIC,
  277, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv3_2_cv3_2_1_act_Mul_output_0_output_array, &_model_22_cv3_2_cv3_2_1_act_Mul_output_0_output_array_intq)

/* Tensor #278 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output, AI_STATIC,
  278, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output_array, &_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #279 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_bias, AI_STATIC,
  279, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #280 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output, AI_STATIC,
  280, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 5, 5), AI_STRIDE_INIT(4, 1, 1, 64, 320),
  1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output_array, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output_array_intq)

/* Tensor #281 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  281, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 7, 7), AI_STRIDE_INIT(4, 1, 1, 64, 448),
  1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output_array, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #282 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_scratch0, AI_STATIC,
  282, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #283 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights, AI_STATIC,
  283, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights_array, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights_array_intq)

/* Tensor #284 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_bias, AI_STATIC,
  284, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_22_cv3_2_cv3_2_2_Conv_output_0_bias_array, NULL)

/* Tensor #285 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_output, AI_STATIC,
  285, 0x1,
  AI_SHAPE_INIT(4, 1, 1, 5, 5), AI_STRIDE_INIT(4, 1, 1, 1, 5),
  1, &_model_22_cv3_2_cv3_2_2_Conv_output_0_output_array, &_model_22_cv3_2_cv3_2_2_Conv_output_0_output_array_intq)

/* Tensor #286 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_scratch0, AI_STATIC,
  286, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 1, 1, 256, 256),
  1, &_model_22_cv3_2_cv3_2_2_Conv_output_0_scratch0_array, NULL)

/* Tensor #287 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_weights, AI_STATIC,
  287, 0x1,
  AI_SHAPE_INIT(4, 64, 1, 1, 1), AI_STRIDE_INIT(4, 1, 64, 64, 64),
  1, &_model_22_cv3_2_cv3_2_2_Conv_output_0_weights_array, &_model_22_cv3_2_cv3_2_2_Conv_output_0_weights_array_intq)

/* Tensor #288 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chfirst_output, AI_STATIC,
  288, 0x1,
  AI_SHAPE_INIT(4, 1, 4, 1, 525), AI_STRIDE_INIT(4, 1, 1, 4, 4),
  1, &_model_22_dfl_Reshape_1_output_0_to_chfirst_output_array, &_model_22_dfl_Reshape_1_output_0_to_chfirst_output_array_intq)

/* Tensor #289 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chlast_output, AI_STATIC,
  289, 0x1,
  AI_SHAPE_INIT(4, 1, 525, 4, 1), AI_STRIDE_INIT(4, 1, 1, 525, 2100),
  1, &_model_22_dfl_Reshape_1_output_0_to_chlast_output_array, &_model_22_dfl_Reshape_1_output_0_to_chlast_output_array_intq)

/* Tensor #290 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chlast_output0, AI_STATIC,
  290, 0x1,
  AI_SHAPE_INIT(4, 1, 525, 1, 4), AI_STRIDE_INIT(4, 1, 1, 525, 525),
  1, &_model_22_dfl_Reshape_1_output_0_to_chlast_output_array, &_model_22_dfl_Reshape_1_output_0_to_chlast_output_array_intq)

/* Tensor #291 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_output, AI_STATIC,
  291, 0x0,
  AI_SHAPE_INIT(4, 1, 4, 525, 16), AI_STRIDE_INIT(4, 4, 4, 16, 8400),
  1, &_model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_output_array, NULL)

/* Tensor #292 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_output, AI_STATIC,
  292, 0x1,
  AI_SHAPE_INIT(4, 1, 4, 525, 16), AI_STRIDE_INIT(4, 1, 1, 4, 2100),
  1, &_model_22_dfl_Reshape_output_0_to_chfirst_output_array, &_model_22_dfl_Reshape_output_0_to_chfirst_output_array_intq)

/* Tensor #293 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chlast_output, AI_STATIC,
  293, 0x1,
  AI_SHAPE_INIT(4, 1, 525, 1, 64), AI_STRIDE_INIT(4, 1, 1, 525, 525),
  1, &_model_22_dfl_Reshape_output_0_to_chlast_output_array, &_model_22_dfl_Reshape_output_0_to_chlast_output_array_intq)

/* Tensor #294 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chlast_output0, AI_STATIC,
  294, 0x1,
  AI_SHAPE_INIT(4, 1, 525, 16, 4), AI_STRIDE_INIT(4, 1, 1, 525, 8400),
  1, &_model_22_dfl_Reshape_output_0_to_chlast_output_array, &_model_22_dfl_Reshape_output_0_to_chlast_output_array_intq)

/* Tensor #295 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output, AI_STATIC,
  295, 0x1,
  AI_SHAPE_INIT(4, 1, 4, 525, 16), AI_STRIDE_INIT(4, 1, 1, 4, 2100),
  1, &_model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output_array, &_model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output_array_intq)

/* Tensor #296 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Softmax_output, AI_STATIC,
  296, 0x0,
  AI_SHAPE_INIT(4, 1, 4, 525, 16), AI_STRIDE_INIT(4, 4, 4, 16, 8400),
  1, &_model_22_dfl_Softmax_output_array, NULL)

/* Tensor #297 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_Transpose_1_output_0_output, AI_STATIC,
  297, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 525, 4), AI_STRIDE_INIT(4, 1, 1, 16, 8400),
  1, &_model_22_dfl_Transpose_1_output_0_output_array, &_model_22_dfl_Transpose_1_output_0_output_array_intq)

/* Tensor #298 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_bias, AI_STATIC,
  298, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_22_dfl_conv_Conv_output_0_bias_array, NULL)

/* Tensor #299 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_output, AI_STATIC,
  299, 0x1,
  AI_SHAPE_INIT(4, 1, 1, 525, 4), AI_STRIDE_INIT(4, 1, 1, 1, 525),
  1, &_model_22_dfl_conv_Conv_output_0_output_array, &_model_22_dfl_conv_Conv_output_0_output_array_intq)

/* Tensor #300 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_scratch0, AI_STATIC,
  300, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 1, 1, 64, 64),
  1, &_model_22_dfl_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #301 */
AI_TENSOR_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_weights, AI_STATIC,
  301, 0x1,
  AI_SHAPE_INIT(4, 16, 1, 1, 1), AI_STRIDE_INIT(4, 1, 16, 16, 16),
  1, &_model_22_dfl_conv_Conv_output_0_weights_array, &_model_22_dfl_conv_Conv_output_0_weights_array_intq)

/* Tensor #302 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_Concat_output_0_output, AI_STATIC,
  302, 0x1,
  AI_SHAPE_INIT(4, 1, 48, 40, 40), AI_STRIDE_INIT(4, 1, 1, 48, 1920),
  1, &_model_2_Concat_output_0_output_array, &_model_2_Concat_output_0_output_array_intq)

/* Tensor #303 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_Split_output_0_num_or_size_splits, AI_STATIC,
  303, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_2_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #304 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_Split_output_0_output0, AI_STATIC,
  304, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_Split_output_0_output0_array, &_model_2_Split_output_0_output0_array_intq)

/* Tensor #305 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_Split_output_0_output1, AI_STATIC,
  305, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_Split_output_0_output1_array, &_model_2_Split_output_0_output1_array_intq)

/* Tensor #306 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv1_act_Mul_output_0_output, AI_STATIC,
  306, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_2_cv1_act_Mul_output_0_output_array, &_model_2_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #307 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  307, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_2_cv1_act_Sigmoid_output_0_output_array, &_model_2_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #308 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_bias, AI_STATIC,
  308, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_2_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #309 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_output, AI_STATIC,
  309, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_2_cv1_conv_Conv_output_0_output_array, &_model_2_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #310 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  310, 0x0,
  AI_SHAPE_INIT(4, 1, 448, 1, 1), AI_STRIDE_INIT(4, 1, 1, 448, 448),
  1, &_model_2_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #311 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_weights, AI_STATIC,
  311, 0x1,
  AI_SHAPE_INIT(4, 32, 1, 1, 32), AI_STRIDE_INIT(4, 1, 32, 1024, 1024),
  1, &_model_2_cv1_conv_Conv_output_0_weights_array, &_model_2_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #312 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv2_act_Mul_output_0_output, AI_STATIC,
  312, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_2_cv2_act_Mul_output_0_output_array, &_model_2_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #313 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  313, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_2_cv2_act_Sigmoid_output_0_output_array, &_model_2_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #314 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_bias, AI_STATIC,
  314, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_2_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #315 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_output, AI_STATIC,
  315, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 40, 40), AI_STRIDE_INIT(4, 1, 1, 32, 1280),
  1, &_model_2_cv2_conv_Conv_output_0_output_array, &_model_2_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #316 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  316, 0x0,
  AI_SHAPE_INIT(4, 1, 512, 1, 1), AI_STRIDE_INIT(4, 1, 1, 512, 512),
  1, &_model_2_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #317 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_weights, AI_STATIC,
  317, 0x1,
  AI_SHAPE_INIT(4, 48, 1, 1, 32), AI_STRIDE_INIT(4, 1, 48, 1536, 1536),
  1, &_model_2_cv2_conv_Conv_output_0_weights_array, &_model_2_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #318 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_Add_output_0_output, AI_STATIC,
  318, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_m_0_Add_output_0_output_array, &_model_2_m_0_Add_output_0_output_array_intq)

/* Tensor #319 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  319, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_m_0_cv1_act_Mul_output_0_output_array, &_model_2_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #320 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  320, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_2_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #321 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  321, 0x0,
  AI_SHAPE_INIT(4, 1, 16, 1, 1), AI_STRIDE_INIT(4, 4, 4, 64, 64),
  1, &_model_2_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #322 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  322, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_m_0_cv1_conv_Conv_output_0_output_array, &_model_2_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #323 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  323, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 42, 42), AI_STRIDE_INIT(4, 1, 1, 16, 672),
  1, &_model_2_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_2_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #324 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  324, 0x0,
  AI_SHAPE_INIT(4, 1, 5408, 1, 1), AI_STRIDE_INIT(4, 1, 1, 5408, 5408),
  1, &_model_2_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #325 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  325, 0x1,
  AI_SHAPE_INIT(4, 16, 3, 3, 16), AI_STRIDE_INIT(4, 1, 16, 256, 768),
  1, &_model_2_m_0_cv1_conv_Conv_output_0_weights_array, &_model_2_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #326 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  326, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_m_0_cv2_act_Mul_output_0_output_array, &_model_2_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #327 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  327, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_2_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #328 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  328, 0x0,
  AI_SHAPE_INIT(4, 1, 16, 1, 1), AI_STRIDE_INIT(4, 4, 4, 64, 64),
  1, &_model_2_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #329 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  329, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 40, 40), AI_STRIDE_INIT(4, 1, 1, 16, 640),
  1, &_model_2_m_0_cv2_conv_Conv_output_0_output_array, &_model_2_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #330 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  330, 0x1,
  AI_SHAPE_INIT(4, 1, 16, 42, 42), AI_STRIDE_INIT(4, 1, 1, 16, 672),
  1, &_model_2_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_2_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #331 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  331, 0x0,
  AI_SHAPE_INIT(4, 1, 5408, 1, 1), AI_STRIDE_INIT(4, 1, 1, 5408, 5408),
  1, &_model_2_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #332 */
AI_TENSOR_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  332, 0x1,
  AI_SHAPE_INIT(4, 16, 3, 3, 16), AI_STRIDE_INIT(4, 1, 16, 256, 768),
  1, &_model_2_m_0_cv2_conv_Conv_output_0_weights_array, &_model_2_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #333 */
AI_TENSOR_OBJ_DECLARE(
  _model_3_act_Mul_output_0_output, AI_STATIC,
  333, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_3_act_Mul_output_0_output_array, &_model_3_act_Mul_output_0_output_array_intq)

/* Tensor #334 */
AI_TENSOR_OBJ_DECLARE(
  _model_3_act_Sigmoid_output_0_output, AI_STATIC,
  334, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_3_act_Sigmoid_output_0_output_array, &_model_3_act_Sigmoid_output_0_output_array_intq)

/* Tensor #335 */
AI_TENSOR_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_bias, AI_STATIC,
  335, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_3_conv_Conv_output_0_bias_array, NULL)

/* Tensor #336 */
AI_TENSOR_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_output, AI_STATIC,
  336, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_3_conv_Conv_output_0_output_array, &_model_3_conv_Conv_output_0_output_array_intq)

/* Tensor #337 */
AI_TENSOR_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_pad_before_output, AI_STATIC,
  337, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 42, 42), AI_STRIDE_INIT(4, 1, 1, 32, 1344),
  1, &_model_3_conv_Conv_output_0_pad_before_output_array, &_model_3_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #338 */
AI_TENSOR_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_scratch0, AI_STATIC,
  338, 0x0,
  AI_SHAPE_INIT(4, 1, 7168, 1, 1), AI_STRIDE_INIT(4, 1, 1, 7168, 7168),
  1, &_model_3_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #339 */
AI_TENSOR_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_weights, AI_STATIC,
  339, 0x1,
  AI_SHAPE_INIT(4, 32, 3, 3, 64), AI_STRIDE_INIT(4, 1, 32, 2048, 6144),
  1, &_model_3_conv_Conv_output_0_weights_array, &_model_3_conv_Conv_output_0_weights_array_intq)

/* Tensor #340 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_Concat_output_0_output, AI_STATIC,
  340, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 20, 20), AI_STRIDE_INIT(4, 1, 1, 128, 2560),
  1, &_model_4_Concat_output_0_output_array, &_model_4_Concat_output_0_output_array_intq)

/* Tensor #341 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_Split_output_0_num_or_size_splits, AI_STATIC,
  341, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_4_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #342 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_Split_output_0_output0, AI_STATIC,
  342, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_Split_output_0_output0_array, &_model_4_Split_output_0_output0_array_intq)

/* Tensor #343 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_Split_output_0_output1, AI_STATIC,
  343, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_Split_output_0_output1_array, &_model_4_Split_output_0_output1_array_intq)

/* Tensor #344 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv1_act_Mul_output_0_output, AI_STATIC,
  344, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_4_cv1_act_Mul_output_0_output_array, &_model_4_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #345 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  345, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_4_cv1_act_Sigmoid_output_0_output_array, &_model_4_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #346 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_bias, AI_STATIC,
  346, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_4_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #347 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_output, AI_STATIC,
  347, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_4_cv1_conv_Conv_output_0_output_array, &_model_4_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #348 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  348, 0x0,
  AI_SHAPE_INIT(4, 1, 896, 1, 1), AI_STRIDE_INIT(4, 1, 1, 896, 896),
  1, &_model_4_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #349 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_weights, AI_STATIC,
  349, 0x1,
  AI_SHAPE_INIT(4, 64, 1, 1, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 4096),
  1, &_model_4_cv1_conv_Conv_output_0_weights_array, &_model_4_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #350 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv2_act_Mul_output_0_output, AI_STATIC,
  350, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_4_cv2_act_Mul_output_0_output_array, &_model_4_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #351 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  351, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_4_cv2_act_Sigmoid_output_0_output_array, &_model_4_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #352 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_bias, AI_STATIC,
  352, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_4_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #353 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_output, AI_STATIC,
  353, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 20, 20), AI_STRIDE_INIT(4, 1, 1, 64, 1280),
  1, &_model_4_cv2_conv_Conv_output_0_output_array, &_model_4_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #354 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  354, 0x0,
  AI_SHAPE_INIT(4, 1, 1152, 1, 1), AI_STRIDE_INIT(4, 1, 1, 1152, 1152),
  1, &_model_4_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #355 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_weights, AI_STATIC,
  355, 0x1,
  AI_SHAPE_INIT(4, 128, 1, 1, 64), AI_STRIDE_INIT(4, 1, 128, 8192, 8192),
  1, &_model_4_cv2_conv_Conv_output_0_weights_array, &_model_4_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #356 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_Add_output_0_output, AI_STATIC,
  356, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_0_Add_output_0_output_array, &_model_4_m_0_Add_output_0_output_array_intq)

/* Tensor #357 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  357, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_0_cv1_act_Mul_output_0_output_array, &_model_4_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #358 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  358, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_4_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #359 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  359, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_4_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #360 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  360, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_0_cv1_conv_Conv_output_0_output_array, &_model_4_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #361 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  361, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 22, 22), AI_STRIDE_INIT(4, 1, 1, 32, 704),
  1, &_model_4_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_4_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #362 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  362, 0x0,
  AI_SHAPE_INIT(4, 1, 6720, 1, 1), AI_STRIDE_INIT(4, 1, 1, 6720, 6720),
  1, &_model_4_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #363 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  363, 0x1,
  AI_SHAPE_INIT(4, 32, 3, 3, 32), AI_STRIDE_INIT(4, 1, 32, 1024, 3072),
  1, &_model_4_m_0_cv1_conv_Conv_output_0_weights_array, &_model_4_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #364 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  364, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_0_cv2_act_Mul_output_0_output_array, &_model_4_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #365 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  365, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_4_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #366 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  366, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_4_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #367 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  367, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_0_cv2_conv_Conv_output_0_output_array, &_model_4_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #368 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  368, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 22, 22), AI_STRIDE_INIT(4, 1, 1, 32, 704),
  1, &_model_4_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_4_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #369 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  369, 0x0,
  AI_SHAPE_INIT(4, 1, 6720, 1, 1), AI_STRIDE_INIT(4, 1, 1, 6720, 6720),
  1, &_model_4_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #370 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  370, 0x1,
  AI_SHAPE_INIT(4, 32, 3, 3, 32), AI_STRIDE_INIT(4, 1, 32, 1024, 3072),
  1, &_model_4_m_0_cv2_conv_Conv_output_0_weights_array, &_model_4_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #371 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_Add_output_0_output, AI_STATIC,
  371, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_1_Add_output_0_output_array, &_model_4_m_1_Add_output_0_output_array_intq)

/* Tensor #372 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Mul_output_0_output, AI_STATIC,
  372, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_1_cv1_act_Mul_output_0_output_array, &_model_4_m_1_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #373 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  373, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_1_cv1_act_Sigmoid_output_0_output_array, &_model_4_m_1_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #374 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_bias, AI_STATIC,
  374, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_4_m_1_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #375 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_output, AI_STATIC,
  375, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_1_cv1_conv_Conv_output_0_output_array, &_model_4_m_1_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #376 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  376, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 22, 22), AI_STRIDE_INIT(4, 1, 1, 32, 704),
  1, &_model_4_m_1_cv1_conv_Conv_output_0_pad_before_output_array, &_model_4_m_1_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #377 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  377, 0x0,
  AI_SHAPE_INIT(4, 1, 6720, 1, 1), AI_STRIDE_INIT(4, 1, 1, 6720, 6720),
  1, &_model_4_m_1_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #378 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_weights, AI_STATIC,
  378, 0x1,
  AI_SHAPE_INIT(4, 32, 3, 3, 32), AI_STRIDE_INIT(4, 1, 32, 1024, 3072),
  1, &_model_4_m_1_cv1_conv_Conv_output_0_weights_array, &_model_4_m_1_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #379 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Mul_output_0_output, AI_STATIC,
  379, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_1_cv2_act_Mul_output_0_output_array, &_model_4_m_1_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #380 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  380, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_1_cv2_act_Sigmoid_output_0_output_array, &_model_4_m_1_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #381 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_bias, AI_STATIC,
  381, 0x0,
  AI_SHAPE_INIT(4, 1, 32, 1, 1), AI_STRIDE_INIT(4, 4, 4, 128, 128),
  1, &_model_4_m_1_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #382 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_output, AI_STATIC,
  382, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 20, 20), AI_STRIDE_INIT(4, 1, 1, 32, 640),
  1, &_model_4_m_1_cv2_conv_Conv_output_0_output_array, &_model_4_m_1_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #383 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  383, 0x1,
  AI_SHAPE_INIT(4, 1, 32, 22, 22), AI_STRIDE_INIT(4, 1, 1, 32, 704),
  1, &_model_4_m_1_cv2_conv_Conv_output_0_pad_before_output_array, &_model_4_m_1_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #384 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  384, 0x0,
  AI_SHAPE_INIT(4, 1, 6720, 1, 1), AI_STRIDE_INIT(4, 1, 1, 6720, 6720),
  1, &_model_4_m_1_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #385 */
AI_TENSOR_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_weights, AI_STATIC,
  385, 0x1,
  AI_SHAPE_INIT(4, 32, 3, 3, 32), AI_STRIDE_INIT(4, 1, 32, 1024, 3072),
  1, &_model_4_m_1_cv2_conv_Conv_output_0_weights_array, &_model_4_m_1_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #386 */
AI_TENSOR_OBJ_DECLARE(
  _model_5_act_Mul_output_0_output, AI_STATIC,
  386, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_5_act_Mul_output_0_output_array, &_model_5_act_Mul_output_0_output_array_intq)

/* Tensor #387 */
AI_TENSOR_OBJ_DECLARE(
  _model_5_act_Sigmoid_output_0_output, AI_STATIC,
  387, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_5_act_Sigmoid_output_0_output_array, &_model_5_act_Sigmoid_output_0_output_array_intq)

/* Tensor #388 */
AI_TENSOR_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_bias, AI_STATIC,
  388, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_5_conv_Conv_output_0_bias_array, NULL)

/* Tensor #389 */
AI_TENSOR_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_output, AI_STATIC,
  389, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_5_conv_Conv_output_0_output_array, &_model_5_conv_Conv_output_0_output_array_intq)

/* Tensor #390 */
AI_TENSOR_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_pad_before_output, AI_STATIC,
  390, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 22, 22), AI_STRIDE_INIT(4, 1, 1, 64, 1408),
  1, &_model_5_conv_Conv_output_0_pad_before_output_array, &_model_5_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #391 */
AI_TENSOR_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_scratch0, AI_STATIC,
  391, 0x0,
  AI_SHAPE_INIT(4, 1, 9216, 1, 1), AI_STRIDE_INIT(4, 1, 1, 9216, 9216),
  1, &_model_5_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #392 */
AI_TENSOR_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_weights, AI_STATIC,
  392, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 128), AI_STRIDE_INIT(4, 1, 64, 8192, 24576),
  1, &_model_5_conv_Conv_output_0_weights_array, &_model_5_conv_Conv_output_0_weights_array_intq)

/* Tensor #393 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_Concat_output_0_output, AI_STATIC,
  393, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 10, 10), AI_STRIDE_INIT(4, 1, 1, 256, 2560),
  1, &_model_6_Concat_output_0_output_array, &_model_6_Concat_output_0_output_array_intq)

/* Tensor #394 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_Split_output_0_num_or_size_splits, AI_STATIC,
  394, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_6_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #395 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_Split_output_0_output0, AI_STATIC,
  395, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_Split_output_0_output0_array, &_model_6_Split_output_0_output0_array_intq)

/* Tensor #396 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_Split_output_0_output1, AI_STATIC,
  396, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_Split_output_0_output1_array, &_model_6_Split_output_0_output1_array_intq)

/* Tensor #397 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv1_act_Mul_output_0_output, AI_STATIC,
  397, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_6_cv1_act_Mul_output_0_output_array, &_model_6_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #398 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  398, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_6_cv1_act_Sigmoid_output_0_output_array, &_model_6_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #399 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_bias, AI_STATIC,
  399, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_6_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #400 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_output, AI_STATIC,
  400, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_6_cv1_conv_Conv_output_0_output_array, &_model_6_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #401 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  401, 0x0,
  AI_SHAPE_INIT(4, 1, 1792, 1, 1), AI_STRIDE_INIT(4, 1, 1, 1792, 1792),
  1, &_model_6_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #402 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_weights, AI_STATIC,
  402, 0x1,
  AI_SHAPE_INIT(4, 128, 1, 1, 128), AI_STRIDE_INIT(4, 1, 128, 16384, 16384),
  1, &_model_6_cv1_conv_Conv_output_0_weights_array, &_model_6_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #403 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv2_act_Mul_output_0_output, AI_STATIC,
  403, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_6_cv2_act_Mul_output_0_output_array, &_model_6_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #404 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  404, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_6_cv2_act_Sigmoid_output_0_output_array, &_model_6_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #405 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_bias, AI_STATIC,
  405, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_6_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #406 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_output, AI_STATIC,
  406, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 10, 10), AI_STRIDE_INIT(4, 1, 1, 128, 1280),
  1, &_model_6_cv2_conv_Conv_output_0_output_array, &_model_6_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #407 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  407, 0x0,
  AI_SHAPE_INIT(4, 1, 2304, 1, 1), AI_STRIDE_INIT(4, 1, 1, 2304, 2304),
  1, &_model_6_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #408 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_weights, AI_STATIC,
  408, 0x1,
  AI_SHAPE_INIT(4, 256, 1, 1, 128), AI_STRIDE_INIT(4, 1, 256, 32768, 32768),
  1, &_model_6_cv2_conv_Conv_output_0_weights_array, &_model_6_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #409 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_Add_output_0_output, AI_STATIC,
  409, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_0_Add_output_0_output_array, &_model_6_m_0_Add_output_0_output_array_intq)

/* Tensor #410 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  410, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_0_cv1_act_Mul_output_0_output_array, &_model_6_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #411 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  411, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_6_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #412 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  412, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_6_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #413 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  413, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_0_cv1_conv_Conv_output_0_output_array, &_model_6_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #414 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  414, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_6_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_6_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #415 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  415, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_6_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #416 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  416, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_6_m_0_cv1_conv_Conv_output_0_weights_array, &_model_6_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #417 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  417, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_0_cv2_act_Mul_output_0_output_array, &_model_6_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #418 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  418, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_6_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #419 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  419, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_6_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #420 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  420, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_0_cv2_conv_Conv_output_0_output_array, &_model_6_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #421 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  421, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_6_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_6_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #422 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  422, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_6_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #423 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  423, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_6_m_0_cv2_conv_Conv_output_0_weights_array, &_model_6_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #424 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_Add_output_0_output, AI_STATIC,
  424, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_1_Add_output_0_output_array, &_model_6_m_1_Add_output_0_output_array_intq)

/* Tensor #425 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Mul_output_0_output, AI_STATIC,
  425, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_1_cv1_act_Mul_output_0_output_array, &_model_6_m_1_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #426 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  426, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_1_cv1_act_Sigmoid_output_0_output_array, &_model_6_m_1_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #427 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_bias, AI_STATIC,
  427, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_6_m_1_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #428 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_output, AI_STATIC,
  428, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_1_cv1_conv_Conv_output_0_output_array, &_model_6_m_1_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #429 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  429, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_6_m_1_cv1_conv_Conv_output_0_pad_before_output_array, &_model_6_m_1_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #430 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  430, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_6_m_1_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #431 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_weights, AI_STATIC,
  431, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_6_m_1_cv1_conv_Conv_output_0_weights_array, &_model_6_m_1_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #432 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Mul_output_0_output, AI_STATIC,
  432, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_1_cv2_act_Mul_output_0_output_array, &_model_6_m_1_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #433 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  433, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_1_cv2_act_Sigmoid_output_0_output_array, &_model_6_m_1_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #434 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_bias, AI_STATIC,
  434, 0x0,
  AI_SHAPE_INIT(4, 1, 64, 1, 1), AI_STRIDE_INIT(4, 4, 4, 256, 256),
  1, &_model_6_m_1_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #435 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_output, AI_STATIC,
  435, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 10, 10), AI_STRIDE_INIT(4, 1, 1, 64, 640),
  1, &_model_6_m_1_cv2_conv_Conv_output_0_output_array, &_model_6_m_1_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #436 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  436, 0x1,
  AI_SHAPE_INIT(4, 1, 64, 12, 12), AI_STRIDE_INIT(4, 1, 1, 64, 768),
  1, &_model_6_m_1_cv2_conv_Conv_output_0_pad_before_output_array, &_model_6_m_1_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #437 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  437, 0x0,
  AI_SHAPE_INIT(4, 1, 8320, 1, 1), AI_STRIDE_INIT(4, 1, 1, 8320, 8320),
  1, &_model_6_m_1_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #438 */
AI_TENSOR_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_weights, AI_STATIC,
  438, 0x1,
  AI_SHAPE_INIT(4, 64, 3, 3, 64), AI_STRIDE_INIT(4, 1, 64, 4096, 12288),
  1, &_model_6_m_1_cv2_conv_Conv_output_0_weights_array, &_model_6_m_1_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #439 */
AI_TENSOR_OBJ_DECLARE(
  _model_7_act_Mul_output_0_output, AI_STATIC,
  439, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_7_act_Mul_output_0_output_array, &_model_7_act_Mul_output_0_output_array_intq)

/* Tensor #440 */
AI_TENSOR_OBJ_DECLARE(
  _model_7_act_Sigmoid_output_0_output, AI_STATIC,
  440, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_7_act_Sigmoid_output_0_output_array, &_model_7_act_Sigmoid_output_0_output_array_intq)

/* Tensor #441 */
AI_TENSOR_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_bias, AI_STATIC,
  441, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 4, 4, 1024, 1024),
  1, &_model_7_conv_Conv_output_0_bias_array, NULL)

/* Tensor #442 */
AI_TENSOR_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_output, AI_STATIC,
  442, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_7_conv_Conv_output_0_output_array, &_model_7_conv_Conv_output_0_output_array_intq)

/* Tensor #443 */
AI_TENSOR_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_pad_before_output, AI_STATIC,
  443, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 12, 12), AI_STRIDE_INIT(4, 1, 1, 128, 1536),
  1, &_model_7_conv_Conv_output_0_pad_before_output_array, &_model_7_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #444 */
AI_TENSOR_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_scratch0, AI_STATIC,
  444, 0x0,
  AI_SHAPE_INIT(4, 1, 13312, 1, 1), AI_STRIDE_INIT(4, 1, 1, 13312, 13312),
  1, &_model_7_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #445 */
AI_TENSOR_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_weights, AI_STATIC,
  445, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 256), AI_STRIDE_INIT(4, 1, 128, 32768, 98304),
  1, &_model_7_conv_Conv_output_0_weights_array, &_model_7_conv_Conv_output_0_weights_array_intq)

/* Tensor #446 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_Concat_output_0_output, AI_STATIC,
  446, 0x1,
  AI_SHAPE_INIT(4, 1, 384, 5, 5), AI_STRIDE_INIT(4, 1, 1, 384, 1920),
  1, &_model_8_Concat_output_0_output_array, &_model_8_Concat_output_0_output_array_intq)

/* Tensor #447 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_Split_output_0_num_or_size_splits, AI_STATIC,
  447, 0x0,
  AI_SHAPE_INIT(4, 1, 1, 1, 1), AI_STRIDE_INIT(4, 4, 4, 4, 4),
  1, &_model_8_Split_output_0_num_or_size_splits_array, NULL)

/* Tensor #448 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_Split_output_0_output0, AI_STATIC,
  448, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_Split_output_0_output0_array, &_model_8_Split_output_0_output0_array_intq)

/* Tensor #449 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_Split_output_0_output1, AI_STATIC,
  449, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_Split_output_0_output1_array, &_model_8_Split_output_0_output1_array_intq)

/* Tensor #450 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv1_act_Mul_output_0_output, AI_STATIC,
  450, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_8_cv1_act_Mul_output_0_output_array, &_model_8_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #451 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  451, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_8_cv1_act_Sigmoid_output_0_output_array, &_model_8_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #452 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_bias, AI_STATIC,
  452, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 4, 4, 1024, 1024),
  1, &_model_8_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #453 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_output, AI_STATIC,
  453, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_8_cv1_conv_Conv_output_0_output_array, &_model_8_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #454 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  454, 0x0,
  AI_SHAPE_INIT(4, 1, 3584, 1, 1), AI_STRIDE_INIT(4, 1, 1, 3584, 3584),
  1, &_model_8_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #455 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_weights, AI_STATIC,
  455, 0x1,
  AI_SHAPE_INIT(4, 256, 1, 1, 256), AI_STRIDE_INIT(4, 1, 256, 65536, 65536),
  1, &_model_8_cv1_conv_Conv_output_0_weights_array, &_model_8_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #456 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv2_act_Mul_output_0_output, AI_STATIC,
  456, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_8_cv2_act_Mul_output_0_output_array, &_model_8_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #457 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  457, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_8_cv2_act_Sigmoid_output_0_output_array, &_model_8_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #458 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_bias, AI_STATIC,
  458, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 4, 4, 1024, 1024),
  1, &_model_8_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #459 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_output, AI_STATIC,
  459, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_8_cv2_conv_Conv_output_0_output_array, &_model_8_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #460 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  460, 0x0,
  AI_SHAPE_INIT(4, 1, 4096, 1, 1), AI_STRIDE_INIT(4, 1, 1, 4096, 4096),
  1, &_model_8_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #461 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_weights, AI_STATIC,
  461, 0x1,
  AI_SHAPE_INIT(4, 384, 1, 1, 256), AI_STRIDE_INIT(4, 1, 384, 98304, 98304),
  1, &_model_8_cv2_conv_Conv_output_0_weights_array, &_model_8_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #462 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_Add_output_0_output, AI_STATIC,
  462, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_m_0_Add_output_0_output_array, &_model_8_m_0_Add_output_0_output_array_intq)

/* Tensor #463 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Mul_output_0_output, AI_STATIC,
  463, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_m_0_cv1_act_Mul_output_0_output_array, &_model_8_m_0_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #464 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  464, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_m_0_cv1_act_Sigmoid_output_0_output_array, &_model_8_m_0_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #465 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_bias, AI_STATIC,
  465, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_8_m_0_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #466 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_output, AI_STATIC,
  466, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_m_0_cv1_conv_Conv_output_0_output_array, &_model_8_m_0_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #467 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_pad_before_output, AI_STATIC,
  467, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 7, 7), AI_STRIDE_INIT(4, 1, 1, 128, 896),
  1, &_model_8_m_0_cv1_conv_Conv_output_0_pad_before_output_array, &_model_8_m_0_cv1_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #468 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  468, 0x0,
  AI_SHAPE_INIT(4, 1, 11520, 1, 1), AI_STRIDE_INIT(4, 1, 1, 11520, 11520),
  1, &_model_8_m_0_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #469 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_weights, AI_STATIC,
  469, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 128), AI_STRIDE_INIT(4, 1, 128, 16384, 49152),
  1, &_model_8_m_0_cv1_conv_Conv_output_0_weights_array, &_model_8_m_0_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #470 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Mul_output_0_output, AI_STATIC,
  470, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_m_0_cv2_act_Mul_output_0_output_array, &_model_8_m_0_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #471 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  471, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_m_0_cv2_act_Sigmoid_output_0_output_array, &_model_8_m_0_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #472 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_bias, AI_STATIC,
  472, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_8_m_0_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #473 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_output, AI_STATIC,
  473, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_8_m_0_cv2_conv_Conv_output_0_output_array, &_model_8_m_0_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #474 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_pad_before_output, AI_STATIC,
  474, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 7, 7), AI_STRIDE_INIT(4, 1, 1, 128, 896),
  1, &_model_8_m_0_cv2_conv_Conv_output_0_pad_before_output_array, &_model_8_m_0_cv2_conv_Conv_output_0_pad_before_output_array_intq)

/* Tensor #475 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  475, 0x0,
  AI_SHAPE_INIT(4, 1, 11520, 1, 1), AI_STRIDE_INIT(4, 1, 1, 11520, 11520),
  1, &_model_8_m_0_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #476 */
AI_TENSOR_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_weights, AI_STATIC,
  476, 0x1,
  AI_SHAPE_INIT(4, 128, 3, 3, 128), AI_STRIDE_INIT(4, 1, 128, 16384, 49152),
  1, &_model_8_m_0_cv2_conv_Conv_output_0_weights_array, &_model_8_m_0_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #477 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_Concat_output_0_output, AI_STATIC,
  477, 0x1,
  AI_SHAPE_INIT(4, 1, 512, 5, 5), AI_STRIDE_INIT(4, 1, 1, 512, 2560),
  1, &_model_9_Concat_output_0_output_array, &_model_9_Concat_output_0_output_array_intq)

/* Tensor #478 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv1_act_Mul_output_0_output, AI_STATIC,
  478, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_9_cv1_act_Mul_output_0_output_array, &_model_9_cv1_act_Mul_output_0_output_array_intq)

/* Tensor #479 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv1_act_Sigmoid_output_0_output, AI_STATIC,
  479, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_9_cv1_act_Sigmoid_output_0_output_array, &_model_9_cv1_act_Sigmoid_output_0_output_array_intq)

/* Tensor #480 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_bias, AI_STATIC,
  480, 0x0,
  AI_SHAPE_INIT(4, 1, 128, 1, 1), AI_STRIDE_INIT(4, 4, 4, 512, 512),
  1, &_model_9_cv1_conv_Conv_output_0_bias_array, NULL)

/* Tensor #481 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_output, AI_STATIC,
  481, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_9_cv1_conv_Conv_output_0_output_array, &_model_9_cv1_conv_Conv_output_0_output_array_intq)

/* Tensor #482 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_scratch0, AI_STATIC,
  482, 0x0,
  AI_SHAPE_INIT(4, 1, 2304, 1, 1), AI_STRIDE_INIT(4, 1, 1, 2304, 2304),
  1, &_model_9_cv1_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #483 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_weights, AI_STATIC,
  483, 0x1,
  AI_SHAPE_INIT(4, 256, 1, 1, 128), AI_STRIDE_INIT(4, 1, 256, 32768, 32768),
  1, &_model_9_cv1_conv_Conv_output_0_weights_array, &_model_9_cv1_conv_Conv_output_0_weights_array_intq)

/* Tensor #484 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv2_act_Mul_output_0_output, AI_STATIC,
  484, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_9_cv2_act_Mul_output_0_output_array, &_model_9_cv2_act_Mul_output_0_output_array_intq)

/* Tensor #485 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv2_act_Sigmoid_output_0_output, AI_STATIC,
  485, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_9_cv2_act_Sigmoid_output_0_output_array, &_model_9_cv2_act_Sigmoid_output_0_output_array_intq)

/* Tensor #486 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_bias, AI_STATIC,
  486, 0x0,
  AI_SHAPE_INIT(4, 1, 256, 1, 1), AI_STRIDE_INIT(4, 4, 4, 1024, 1024),
  1, &_model_9_cv2_conv_Conv_output_0_bias_array, NULL)

/* Tensor #487 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_output, AI_STATIC,
  487, 0x1,
  AI_SHAPE_INIT(4, 1, 256, 5, 5), AI_STRIDE_INIT(4, 1, 1, 256, 1280),
  1, &_model_9_cv2_conv_Conv_output_0_output_array, &_model_9_cv2_conv_Conv_output_0_output_array_intq)

/* Tensor #488 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_scratch0, AI_STATIC,
  488, 0x0,
  AI_SHAPE_INIT(4, 1, 4608, 1, 1), AI_STRIDE_INIT(4, 1, 1, 4608, 4608),
  1, &_model_9_cv2_conv_Conv_output_0_scratch0_array, NULL)

/* Tensor #489 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_weights, AI_STATIC,
  489, 0x1,
  AI_SHAPE_INIT(4, 512, 1, 1, 256), AI_STRIDE_INIT(4, 1, 512, 131072, 131072),
  1, &_model_9_cv2_conv_Conv_output_0_weights_array, &_model_9_cv2_conv_Conv_output_0_weights_array_intq)

/* Tensor #490 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_m_1_MaxPool_output_0_output, AI_STATIC,
  490, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_9_m_1_MaxPool_output_0_output_array, &_model_9_m_1_MaxPool_output_0_output_array_intq)

/* Tensor #491 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_m_2_MaxPool_output_0_output, AI_STATIC,
  491, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_9_m_2_MaxPool_output_0_output_array, &_model_9_m_2_MaxPool_output_0_output_array_intq)

/* Tensor #492 */
AI_TENSOR_OBJ_DECLARE(
  _model_9_m_MaxPool_output_0_output, AI_STATIC,
  492, 0x1,
  AI_SHAPE_INIT(4, 1, 128, 5, 5), AI_STRIDE_INIT(4, 1, 1, 128, 640),
  1, &_model_9_m_MaxPool_output_0_output_array, &_model_9_m_MaxPool_output_0_output_array_intq)

/* Tensor #493 */
AI_TENSOR_OBJ_DECLARE(
  images_Transpose_output, AI_STATIC,
  493, 0x1,
  AI_SHAPE_INIT(4, 1, 3, 160, 160), AI_STRIDE_INIT(4, 1, 1, 3, 480),
  1, &images_Transpose_output_array, &images_Transpose_output_array_intq)

/* Tensor #494 */
AI_TENSOR_OBJ_DECLARE(
  images_output, AI_STATIC,
  494, 0x1,
  AI_SHAPE_INIT(4, 1, 160, 160, 3), AI_STRIDE_INIT(4, 1, 1, 160, 25600),
  1, &images_output_array, &images_output_array_intq)

/* Tensor #495 */
AI_TENSOR_OBJ_DECLARE(
  output0_QuantizeLinear_Input_Transpose_0_output, AI_STATIC,
  495, 0x1,
  AI_SHAPE_INIT(4, 1, 525, 1, 5), AI_STRIDE_INIT(4, 1, 1, 525, 525),
  1, &output0_QuantizeLinear_Input_Transpose_0_output_array, &output0_QuantizeLinear_Input_Transpose_0_output_array_intq)

/* Tensor #496 */
AI_TENSOR_OBJ_DECLARE(
  output0_QuantizeLinear_Input_output, AI_STATIC,
  496, 0x1,
  AI_SHAPE_INIT(4, 1, 5, 1, 525), AI_STRIDE_INIT(4, 1, 1, 5, 5),
  1, &output0_QuantizeLinear_Input_output_array, &output0_QuantizeLinear_Input_output_array_intq)



/**  Layer declarations section  **********************************************/


AI_TENSOR_CHAIN_OBJ_DECLARE(
  output0_QuantizeLinear_Input_Transpose_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &output0_QuantizeLinear_Input_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &output0_QuantizeLinear_Input_Transpose_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  output0_QuantizeLinear_Input_Transpose_0_layer, 1,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &output0_QuantizeLinear_Input_Transpose_0_chain,
  NULL, &output0_QuantizeLinear_Input_Transpose_0_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_HEIGHT, AI_SHAPE_WIDTH, AI_SHAPE_CHANNEL, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  output0_QuantizeLinear_Input_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Mul_2_output_0_output, &_model_22_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &output0_QuantizeLinear_Input_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  output0_QuantizeLinear_Input_layer, 844,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &output0_QuantizeLinear_Input_chain,
  NULL, &output0_QuantizeLinear_Input_Transpose_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Mul_2_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Concat_4_output_0_output, &_model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Mul_2_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Mul_2_output_0_layer, 841,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_Mul_2_output_0_chain,
  NULL, &output0_QuantizeLinear_Input_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Concat_4_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output, &_model_22_Sub_1_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Concat_4_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Concat_4_output_0_layer, 838,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_22_Concat_4_output_0_chain,
  NULL, &_model_22_Mul_2_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Div_1_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_layer, 835,
  NL_TYPE, 0x0, NULL,
  nl, node_convert,
  &_model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_chain,
  NULL, &_model_22_Concat_4_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Div_1_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_output, &_model_22_Constant_11_output_0_3D),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Div_1_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Div_1_output_0_layer, 835,
  ELTWISE_TYPE, 0x0, NULL,
  eltwise, forward_eltwise,
  &_model_22_Div_1_output_0_chain,
  NULL, &_model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_layer, AI_STATIC, 
  .operation = ai_div_f32, 
  .buffer_operation = ai_div_buffer_f32, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Add_2_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_layer, 829,
  NL_TYPE, 0x0, NULL,
  nl, node_convert,
  &_model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_chain,
  NULL, &_model_22_Div_1_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Add_2_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output, &_model_22_Add_1_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Add_2_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Add_2_output_0_layer, 829,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_Add_2_output_0_chain,
  NULL, &_model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Sub_1_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Add_1_output_0_output, &_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Sub_1_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Sub_1_output_0_layer, 830,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_Sub_1_output_0_chain,
  NULL, &_model_22_Add_2_output_0_layer, AI_STATIC, 
  .operation = ai_sub_f32, 
  .buffer_operation = ai_sub_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Sub_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_layer, 822,
  NL_TYPE, 0x0, NULL,
  nl, node_convert,
  &_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_chain,
  NULL, &_model_22_Sub_1_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Sub_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Constant_9_output_0, &_model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Sub_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Sub_output_0_layer, 822,
  ELTWISE_TYPE, 0x0, NULL,
  eltwise, forward_eltwise,
  &_model_22_Sub_output_0_chain,
  NULL, &_model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_layer, AI_STATIC, 
  .operation = ai_sub_f32, 
  .buffer_operation = ai_sub_buffer_f32, 
)


AI_STATIC_CONST ai_i8 _model_22_Sigmoid_output_0_nl_params_data[] = { -126, -126, -126, -126, -125, -125, -125, -125, -125, -124, -124, -124, -123, -123, -122, -122, -121, -121, -120, -119, -119, -118, -117, -116, -115, -114, -113, -111, -110, -108, -107, -105, -103, -101, -98, -96, -93, -90, -87, -84, -80, -76, -71, -66, -61, -55, -49, -42, -35, -27, -18, -9, 1, 12, 24, 37, 51, 66, 82, 100, 120, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_Sigmoid_output_0_nl_params_data, _model_22_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Sigmoid_output_0_layer, 802,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_Sigmoid_output_0_chain,
  NULL, &_model_22_Sub_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Add_1_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Constant_10_output_0_DequantizeLinear_Output_const, &_model_22_Slice_1_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Add_1_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Add_1_output_0_layer, 825,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_Add_1_output_0_chain,
  NULL, &_model_22_Sigmoid_output_0_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)


AI_STATIC_CONST ai_u8 _model_22_Slice_1_output_0_axes_data[] = { 2 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_Slice_1_output_0_axes, AI_ARRAY_FORMAT_U8,
    _model_22_Slice_1_output_0_axes_data, _model_22_Slice_1_output_0_axes_data, 1, AI_STATIC_CONST)

AI_STATIC_CONST ai_i16 _model_22_Slice_1_output_0_starts_data[] = { 2 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_Slice_1_output_0_starts, AI_ARRAY_FORMAT_S16,
    _model_22_Slice_1_output_0_starts_data, _model_22_Slice_1_output_0_starts_data, 1, AI_STATIC_CONST)

AI_STATIC_CONST ai_i16 _model_22_Slice_1_output_0_ends_data[] = { 4 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_Slice_1_output_0_ends, AI_ARRAY_FORMAT_S16,
    _model_22_Slice_1_output_0_ends_data, _model_22_Slice_1_output_0_ends_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Slice_1_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_1_output_0_to_chfirst_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Slice_1_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Slice_1_output_0_layer, 819,
  SLICE_TYPE, 0x0, NULL,
  slice, forward_slice,
  &_model_22_Slice_1_output_0_chain,
  NULL, &_model_22_Add_1_output_0_layer, AI_STATIC, 
  .axes = &_model_22_Slice_1_output_0_axes, 
  .starts = &_model_22_Slice_1_output_0_starts, 
  .ends = &_model_22_Slice_1_output_0_ends, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Slice_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_layer, 820,
  NL_TYPE, 0x0, NULL,
  nl, node_convert,
  &_model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_chain,
  NULL, &_model_22_Slice_1_output_0_layer, AI_STATIC, 
)


AI_STATIC_CONST ai_u8 _model_22_Slice_output_0_axes_data[] = { 2 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_Slice_output_0_axes, AI_ARRAY_FORMAT_U8,
    _model_22_Slice_output_0_axes_data, _model_22_Slice_output_0_axes_data, 1, AI_STATIC_CONST)

AI_STATIC_CONST ai_i16 _model_22_Slice_output_0_starts_data[] = { 0 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_Slice_output_0_starts, AI_ARRAY_FORMAT_S16,
    _model_22_Slice_output_0_starts_data, _model_22_Slice_output_0_starts_data, 1, AI_STATIC_CONST)

AI_STATIC_CONST ai_i16 _model_22_Slice_output_0_ends_data[] = { 2 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_Slice_output_0_ends, AI_ARRAY_FORMAT_S16,
    _model_22_Slice_output_0_ends_data, _model_22_Slice_output_0_ends_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Slice_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_1_output_0_to_chfirst_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Slice_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Slice_output_0_layer, 820,
  SLICE_TYPE, 0x0, NULL,
  slice, forward_slice,
  &_model_22_Slice_output_0_chain,
  NULL, &_model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_layer, AI_STATIC, 
  .axes = &_model_22_Slice_output_0_axes, 
  .starts = &_model_22_Slice_output_0_starts, 
  .ends = &_model_22_Slice_output_0_ends, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chfirst_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_1_output_0_to_chlast_output0),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_1_output_0_to_chfirst_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chfirst_layer, 816,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &_model_22_dfl_Reshape_1_output_0_to_chfirst_chain,
  NULL, &_model_22_Slice_output_0_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_HEIGHT, AI_SHAPE_WIDTH, AI_SHAPE_CHANNEL, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chlast_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_1_output_0_to_chlast_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Reshape_1_output_0_to_chlast_layer, 816,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &_model_22_dfl_Reshape_1_output_0_to_chlast_chain,
  NULL, &_model_22_dfl_Reshape_1_output_0_to_chfirst_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_WIDTH, AI_SHAPE_HEIGHT, AI_SHAPE_CHANNEL, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Transpose_1_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_dfl_conv_Conv_output_0_weights, &_model_22_dfl_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_conv_Conv_output_0_layer, 813,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_integer_SSSA,
  &_model_22_dfl_conv_Conv_output_0_chain,
  NULL, &_model_22_dfl_Reshape_1_output_0_to_chlast_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Transpose_1_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Transpose_1_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Transpose_1_output_0_layer, 810,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &_model_22_dfl_Transpose_1_output_0_chain,
  NULL, &_model_22_dfl_conv_Conv_output_0_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_HEIGHT, AI_SHAPE_WIDTH, AI_SHAPE_CHANNEL, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Softmax_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_layer, 807,
  NL_TYPE, 0x0, NULL,
  nl, node_convert,
  &_model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_chain,
  NULL, &_model_22_dfl_Transpose_1_output_0_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Softmax_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Softmax_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Softmax_layer, 807,
  SM_TYPE, 0x0, NULL,
  sm, forward_sm,
  &_model_22_dfl_Softmax_chain,
  NULL, &_model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_layer, AI_STATIC, 
  .nl_params = NULL, 
  .axis = AI_SHAPE_HEIGHT, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_output_0_to_chfirst_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_layer, 801,
  NL_TYPE, 0x0, NULL,
  nl, node_convert,
  &_model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_chain,
  NULL, &_model_22_dfl_Softmax_layer, AI_STATIC, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_output_0_to_chlast_output0),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_output_0_to_chfirst_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chfirst_layer, 801,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &_model_22_dfl_Reshape_output_0_to_chfirst_chain,
  NULL, &_model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_HEIGHT, AI_SHAPE_CHANNEL, AI_SHAPE_WIDTH, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chlast_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Split_output_0_output0),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_dfl_Reshape_output_0_to_chlast_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_dfl_Reshape_output_0_to_chlast_layer, 801,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &_model_22_dfl_Reshape_output_0_to_chlast_chain,
  NULL, &_model_22_dfl_Reshape_output_0_to_chfirst_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_HEIGHT, AI_SHAPE_WIDTH, AI_SHAPE_CHANNEL, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Concat_3_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_Split_output_0_output0, &_model_22_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Split_output_0_layer, 796,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_22_Split_output_0_chain,
  NULL, &_model_22_dfl_Reshape_output_0_to_chlast_layer, AI_STATIC, 
  .outer_elems = 525, 
  .outer_elems_stride = 65, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Concat_3_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_Concat_output_0_output0, &_model_22_Concat_1_output_0_output0, &_model_22_Concat_2_output_0_output0),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Concat_3_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Concat_3_output_0_layer, 793,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_22_Concat_3_output_0_chain,
  NULL, &_model_22_Split_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_HEIGHT, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_0_cv2_0_2_Conv_output_0_output, &_model_22_cv3_0_cv3_0_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Concat_output_0_layer, 601,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_22_Concat_output_0_chain,
  NULL, &_model_22_Concat_3_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_0_cv2_0_2_Conv_output_0_weights, &_model_22_cv2_0_cv2_0_2_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_2_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_2_Conv_output_0_layer, 593,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_22_cv2_0_cv2_0_2_Conv_output_0_chain,
  NULL, &_model_22_Concat_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output, &_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Mul_output_0_layer, 584,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv2_0_cv2_0_1_act_Mul_output_0_chain,
  NULL, &_model_22_cv2_0_cv2_0_2_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -124, -124, -124, -123, -123, -123, -122, -122, -121, -121, -120, -119, -119, -118, -117, -116, -115, -114, -113, -112, -111, -109, -108, -106, -104, -103, -101, -99, -96, -94, -92, -89, -86, -83, -80, -77, -74, -70, -66, -62, -58, -54, -50, -45, -41, -36, -31, -26, -21, -16, -11, -6, 0, 5, 10, 15, 20, 25, 30, 35, 40, 44, 49, 53, 57, 61, 65, 69, 73, 76, 79, 82, 85, 88, 91, 93, 95, 98, 100, 102, 103, 105, 107, 108, 110, 111, 112, 113, 114, 115, 116, 117, 118, 118, 119, 120, 120, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_nl_params_data, _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_layer, 575,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv2_0_cv2_0_1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_layer, 566,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_chain,
  NULL, &_model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_value_data, _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_layer, 566,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output, &_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Mul_output_0_layer, 557,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv2_0_cv2_0_0_act_Mul_output_0_chain,
  NULL, &_model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_nl_params_data[] = { -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -105, -105, -104, -103, -103, -102, -101, -101, -100, -99, -98, -98, -97, -96, -95, -94, -93, -92, -91, -91, -90, -89, -88, -86, -85, -84, -83, -82, -81, -80, -79, -77, -76, -75, -74, -72, -71, -70, -68, -67, -65, -64, -62, -61, -59, -58, -56, -55, -53, -51, -50, -48, -46, -45, -43, -41, -39, -38, -36, -34, -32, -30, -28, -26, -25, -23, -21, -19, -17, -15, -13, -11, -9, -7, -5, -3, -1, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 48, 50, 52, 54, 56, 57, 59, 61, 62, 64, 66, 67, 69, 71, 72, 74, 75, 77, 78, 80, 81, 83, 84, 85, 87, 88, 89, 90, 92, 93, 94, 95, 96, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 109, 110, 111, 112, 113, 114, 114, 115, 116, 117, 117, 118, 119, 119, 120, 120, 121, 122, 122, 123, 123, 124, 124, 125, 125, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_nl_params_data, _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_layer, 548,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv2_0_cv2_0_0_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_layer, 539,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_chain,
  NULL, &_model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_value_data, _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_layer, 539,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_0_cv3_0_2_Conv_output_0_weights, &_model_22_cv3_0_cv3_0_2_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_2_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_2_Conv_output_0_layer, 592,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_integer_SSSA,
  &_model_22_cv3_0_cv3_0_2_Conv_output_0_chain,
  NULL, &_model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output, &_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Mul_output_0_layer, 583,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv3_0_cv3_0_1_act_Mul_output_0_chain,
  NULL, &_model_22_cv3_0_cv3_0_2_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_nl_params_data[] = { -119, -119, -118, -118, -118, -118, -118, -117, -117, -117, -117, -116, -116, -116, -116, -115, -115, -115, -115, -114, -114, -114, -113, -113, -113, -112, -112, -112, -111, -111, -111, -110, -110, -110, -109, -109, -108, -108, -108, -107, -107, -106, -106, -105, -105, -104, -104, -103, -103, -102, -102, -101, -101, -100, -100, -99, -98, -98, -97, -97, -96, -95, -95, -94, -93, -93, -92, -91, -91, -90, -89, -88, -88, -87, -86, -85, -84, -84, -83, -82, -81, -80, -79, -78, -77, -77, -76, -75, -74, -73, -72, -71, -70, -69, -68, -67, -65, -64, -63, -62, -61, -60, -59, -58, -56, -55, -54, -53, -51, -50, -49, -48, -46, -45, -44, -42, -41, -40, -38, -37, -36, -34, -33, -32, -30, -29, -27, -26, -24, -23, -21, -20, -18, -17, -15, -14, -12, -11, -9, -8, -6, -5, -3, -2, 0, 1, 3, 5, 6, 8, 9, 11, 12, 14, 15, 17, 19, 20, 22, 23, 25, 26, 28, 29, 31, 33, 34, 36, 37, 39, 40, 42, 43, 45, 46, 48, 49, 50, 52, 53, 55, 56, 58, 59, 60, 62, 63, 64, 66, 67, 68, 70, 71, 72, 74, 75, 76, 77, 79, 80, 81, 82, 83, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 107, 108, 109, 110, 111, 112, 112, 113, 114, 115, 115, 116, 117, 117, 118, 119, 119, 120, 121, 121, 122, 123, 123, 124, 124, 125, 125, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_nl_params_data, _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_layer, 574,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv3_0_cv3_0_1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_layer, 565,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_chain,
  NULL, &_model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_value_data[] = { -108 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_value_data, _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_layer, 565,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output, &_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Mul_output_0_layer, 556,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv3_0_cv3_0_0_act_Mul_output_0_chain,
  NULL, &_model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_nl_params_data[] = { -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -105, -105, -104, -104, -103, -102, -102, -101, -100, -100, -99, -98, -98, -97, -96, -95, -94, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -78, -77, -76, -74, -73, -72, -71, -70, -68, -67, -66, -64, -63, -62, -60, -59, -57, -56, -54, -53, -51, -50, -48, -47, -45, -44, -42, -41, -39, -37, -36, -34, -32, -30, -29, -27, -25, -24, -22, -20, -18, -16, -15, -13, -11, -9, -7, -6, -4, -2, 0, 2, 4, 5, 7, 9, 11, 13, 14, 16, 18, 20, 22, 24, 25, 27, 29, 31, 32, 34, 36, 38, 39, 41, 43, 44, 46, 48, 49, 51, 52, 54, 56, 57, 59, 60, 62, 63, 64, 66, 67, 69, 70, 71, 73, 74, 75, 77, 78, 79, 80, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 101, 102, 103, 104, 105, 105, 106, 107, 107, 108, 109, 109, 110, 111, 111, 112, 113, 113, 114, 114, 115, 115, 116, 116, 117, 117, 118, 118, 119, 119, 119, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_nl_params_data, _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_layer, 547,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv3_0_cv3_0_0_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_layer, 538,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_chain,
  NULL, &_model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_value_data, _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_layer, 538,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Concat_1_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_1_cv2_1_2_Conv_output_0_output, &_model_22_cv3_1_cv3_1_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Concat_1_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Concat_1_output_0_layer, 705,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_22_Concat_1_output_0_chain,
  NULL, &_model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_1_cv2_1_2_Conv_output_0_weights, &_model_22_cv2_1_cv2_1_2_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_2_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_2_Conv_output_0_layer, 697,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_22_cv2_1_cv2_1_2_Conv_output_0_chain,
  NULL, &_model_22_Concat_1_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output, &_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Mul_output_0_layer, 688,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv2_1_cv2_1_1_act_Mul_output_0_chain,
  NULL, &_model_22_cv2_1_cv2_1_2_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -124, -124, -124, -123, -123, -123, -122, -122, -122, -121, -121, -120, -119, -119, -118, -118, -117, -116, -115, -114, -113, -112, -111, -110, -109, -107, -106, -105, -103, -101, -100, -98, -96, -94, -92, -89, -87, -84, -82, -79, -76, -73, -70, -66, -63, -60, -56, -52, -48, -44, -40, -36, -32, -27, -23, -19, -14, -10, -5, 0, 4, 9, 13, 18, 22, 26, 31, 35, 39, 43, 47, 51, 55, 59, 62, 65, 69, 72, 75, 78, 81, 83, 86, 88, 91, 93, 95, 97, 99, 100, 102, 104, 105, 106, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 117, 118, 118, 119, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_nl_params_data, _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_layer, 679,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv2_1_cv2_1_1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_layer, 670,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_chain,
  NULL, &_model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_value_data[] = { -114 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_value_data, _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_layer, 670,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output, &_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Mul_output_0_layer, 661,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv2_1_cv2_1_0_act_Mul_output_0_chain,
  NULL, &_model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -122, -121, -121, -121, -120, -120, -119, -119, -119, -118, -118, -117, -117, -116, -116, -115, -114, -114, -113, -112, -112, -111, -110, -109, -108, -108, -107, -106, -105, -104, -103, -101, -100, -99, -98, -97, -95, -94, -92, -91, -89, -88, -86, -84, -83, -81, -79, -77, -75, -73, -71, -69, -66, -64, -62, -59, -57, -54, -52, -49, -47, -44, -41, -38, -35, -33, -30, -27, -24, -21, -18, -15, -12, -9, -6, -2, 1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 42, 45, 48, 51, 53, 56, 58, 61, 63, 65, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 87, 89, 91, 92, 94, 95, 97, 98, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 112, 113, 114, 114, 115, 116, 116, 117, 117, 118, 119, 119, 119, 120, 120, 121, 121, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_nl_params_data, _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_layer, 652,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv2_1_cv2_1_0_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_layer, 643,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_chain,
  NULL, &_model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_value_data[] = { -106 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_value_data, _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_layer, 643,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_1_cv3_1_2_Conv_output_0_weights, &_model_22_cv3_1_cv3_1_2_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_2_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_2_Conv_output_0_layer, 696,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_integer_SSSA,
  &_model_22_cv3_1_cv3_1_2_Conv_output_0_chain,
  NULL, &_model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output, &_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Mul_output_0_layer, 687,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv3_1_cv3_1_1_act_Mul_output_0_chain,
  NULL, &_model_22_cv3_1_cv3_1_2_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_nl_params_data[] = { -121, -120, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -118, -117, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -113, -112, -112, -111, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -106, -105, -105, -104, -104, -103, -103, -102, -101, -101, -100, -99, -99, -98, -97, -97, -96, -95, -95, -94, -93, -92, -91, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -78, -77, -76, -75, -74, -73, -72, -71, -69, -68, -67, -66, -65, -63, -62, -61, -59, -58, -57, -55, -54, -53, -51, -50, -48, -47, -45, -44, -42, -41, -39, -38, -36, -35, -33, -32, -30, -28, -27, -25, -23, -22, -20, -18, -17, -15, -13, -12, -10, -8, -7, -5, -3, -1, 0, 2, 4, 5, 7, 9, 11, 12, 14, 16, 17, 19, 21, 23, 24, 26, 28, 29, 31, 33, 34, 36, 38, 39, 41, 42, 44, 46, 47, 49, 50, 52, 53, 55, 56, 58, 59, 61, 62, 63, 65, 66, 68, 69, 70, 72, 73, 74, 75, 77, 78, 79, 80, 81, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 101, 102, 103, 104, 105, 105, 106, 107, 108, 108, 109, 110, 110, 111, 112, 112, 113, 113, 114, 115, 115, 116, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 122, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_nl_params_data, _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_layer, 678,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv3_1_cv3_1_1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_layer, 669,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_chain,
  NULL, &_model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_value_data, _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_layer, 669,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output, &_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Mul_output_0_layer, 660,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv3_1_cv3_1_0_act_Mul_output_0_chain,
  NULL, &_model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_nl_params_data[] = { -113, -112, -112, -112, -111, -111, -110, -110, -110, -109, -109, -109, -108, -108, -107, -107, -106, -106, -106, -105, -105, -104, -104, -103, -103, -102, -102, -101, -101, -100, -100, -99, -98, -98, -97, -97, -96, -95, -95, -94, -93, -93, -92, -91, -91, -90, -89, -88, -88, -87, -86, -85, -85, -84, -83, -82, -81, -80, -80, -79, -78, -77, -76, -75, -74, -73, -72, -71, -70, -69, -68, -67, -66, -65, -64, -63, -62, -61, -59, -58, -57, -56, -55, -54, -53, -51, -50, -49, -48, -46, -45, -44, -43, -41, -40, -39, -37, -36, -35, -33, -32, -31, -29, -28, -26, -25, -24, -22, -21, -19, -18, -16, -15, -14, -12, -11, -9, -8, -6, -5, -3, -2, 0, 1, 3, 4, 6, 7, 9, 10, 12, 13, 15, 16, 18, 19, 21, 22, 23, 25, 26, 28, 29, 31, 32, 34, 35, 36, 38, 39, 41, 42, 43, 45, 46, 48, 49, 50, 52, 53, 54, 56, 57, 58, 59, 61, 62, 63, 64, 66, 67, 68, 69, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 96, 97, 98, 99, 100, 100, 101, 102, 103, 103, 104, 105, 106, 106, 107, 108, 108, 109, 110, 110, 111, 111, 112, 113, 113, 114, 114, 115, 115, 116, 116, 117, 118, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 122, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_nl_params_data, _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_layer, 651,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv3_1_cv3_1_0_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_layer, 642,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_chain,
  NULL, &_model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_value_data[] = { -106 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_value_data, _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_layer, 642,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_Concat_2_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_2_cv2_2_2_Conv_output_0_output, &_model_22_cv3_2_cv3_2_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_Concat_2_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_Concat_2_output_0_layer, 787,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_22_Concat_2_output_0_chain,
  NULL, &_model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_2_cv2_2_2_Conv_output_0_weights, &_model_22_cv2_2_cv2_2_2_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_2_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_2_Conv_output_0_layer, 782,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_22_cv2_2_cv2_2_2_Conv_output_0_chain,
  NULL, &_model_22_Concat_2_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output, &_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Mul_output_0_layer, 776,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv2_2_cv2_2_1_act_Mul_output_0_chain,
  NULL, &_model_22_cv2_2_cv2_2_2_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -123, -123, -123, -122, -122, -122, -121, -121, -120, -120, -119, -119, -118, -118, -117, -116, -115, -115, -114, -113, -112, -111, -110, -109, -108, -107, -105, -104, -103, -101, -100, -98, -96, -95, -93, -91, -89, -87, -84, -82, -80, -77, -74, -72, -69, -66, -63, -60, -57, -53, -50, -47, -43, -39, -36, -32, -28, -24, -20, -16, -12, -8, -4, 0, 4, 8, 12, 16, 19, 23, 27, 31, 35, 38, 42, 46, 49, 52, 56, 59, 62, 65, 68, 71, 73, 76, 79, 81, 83, 86, 88, 90, 92, 94, 95, 97, 99, 100, 102, 103, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_nl_params_data, _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_layer, 770,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv2_2_cv2_2_1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_layer, 764,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_chain,
  NULL, &_model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_value_data[] = { -111 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_value_data, _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_layer, 764,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output, &_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Mul_output_0_layer, 758,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv2_2_cv2_2_0_act_Mul_output_0_chain,
  NULL, &_model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_nl_params_data[] = { -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -109, -108, -107, -107, -106, -105, -105, -104, -103, -102, -102, -101, -100, -99, -98, -97, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -84, -83, -82, -81, -79, -78, -76, -75, -74, -72, -71, -69, -67, -66, -64, -63, -61, -59, -57, -56, -54, -52, -50, -48, -46, -45, -43, -41, -39, -37, -35, -33, -31, -28, -26, -24, -22, -20, -18, -16, -14, -11, -9, -7, -5, -3, 0, 2, 4, 6, 9, 11, 13, 15, 17, 19, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 59, 61, 63, 65, 66, 68, 70, 71, 73, 74, 76, 77, 79, 80, 82, 83, 84, 86, 87, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 105, 106, 107, 108, 108, 109, 110, 111, 111, 112, 112, 113, 114, 114, 115, 115, 116, 116, 117, 117, 118, 118, 119, 119, 119, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 126, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_nl_params_data, _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_layer, 752,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv2_2_cv2_2_0_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_layer, 746,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_chain,
  NULL, &_model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_value_data, _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_layer, 746,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_2_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_2_cv3_2_2_Conv_output_0_weights, &_model_22_cv3_2_cv3_2_2_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_2_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_2_Conv_output_0_layer, 781,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_integer_SSSA,
  &_model_22_cv3_2_cv3_2_2_Conv_output_0_chain,
  NULL, &_model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output, &_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Mul_output_0_layer, 775,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv3_2_cv3_2_1_act_Mul_output_0_chain,
  NULL, &_model_22_cv3_2_cv3_2_2_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_nl_params_data[] = { -88, -88, -87, -87, -86, -86, -85, -85, -84, -84, -83, -83, -82, -81, -81, -80, -80, -79, -78, -78, -77, -77, -76, -75, -75, -74, -73, -73, -72, -71, -71, -70, -69, -69, -68, -67, -67, -66, -65, -64, -64, -63, -62, -61, -61, -60, -59, -58, -58, -57, -56, -55, -54, -54, -53, -52, -51, -50, -49, -49, -48, -47, -46, -45, -44, -43, -42, -42, -41, -40, -39, -38, -37, -36, -35, -34, -33, -32, -31, -30, -29, -28, -27, -26, -25, -25, -24, -23, -22, -21, -20, -19, -18, -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 77, 78, 79, 80, 81, 82, 83, 84, 85, 85, 86, 87, 88, 89, 90, 90, 91, 92, 93, 94, 94, 95, 96, 97, 98, 98, 99, 100, 101, 101, 102, 103, 103, 104, 105, 106, 106, 107, 108, 108, 109, 110, 110, 111, 112, 112, 113, 114, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 120, 121, 121, 122, 122, 123, 123, 124, 124, 125, 125, 126, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_nl_params_data, _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_layer, 769,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv3_2_cv3_2_1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_layer, 763,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_chain,
  NULL, &_model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_value_data[] = { -102 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_value_data, _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_layer, 763,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output, &_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Mul_output_0_layer, 757,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_22_cv3_2_cv3_2_0_act_Mul_output_0_chain,
  NULL, &_model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_nl_params_data[] = { -97, -96, -96, -95, -95, -94, -93, -93, -92, -92, -91, -91, -90, -89, -89, -88, -88, -87, -86, -86, -85, -84, -84, -83, -82, -82, -81, -80, -79, -79, -78, -77, -76, -76, -75, -74, -73, -72, -72, -71, -70, -69, -68, -67, -67, -66, -65, -64, -63, -62, -61, -60, -59, -58, -57, -57, -56, -55, -54, -53, -52, -51, -50, -49, -48, -46, -45, -44, -43, -42, -41, -40, -39, -38, -37, -36, -35, -33, -32, -31, -30, -29, -28, -26, -25, -24, -23, -22, -21, -19, -18, -17, -16, -15, -13, -12, -11, -10, -8, -7, -6, -5, -4, -2, -1, 0, 1, 3, 4, 5, 6, 8, 9, 10, 11, 13, 14, 15, 16, 18, 19, 20, 21, 23, 24, 25, 26, 28, 29, 30, 31, 32, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 84, 85, 86, 87, 88, 89, 90, 90, 91, 92, 93, 94, 94, 95, 96, 97, 97, 98, 99, 99, 100, 101, 102, 102, 103, 103, 104, 105, 105, 106, 107, 107, 108, 108, 109, 110, 110, 111, 111, 112, 112, 113, 113, 114, 114, 115, 115, 116, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 121, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_nl_params_data, _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_layer, 751,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_chain,
  NULL, &_model_22_cv3_2_cv3_2_0_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_layer, 745,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_chain,
  NULL, &_model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_value_data, _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_layer, 745,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_21_cv2_conv_Conv_output_0_output, &_model_21_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_cv2_act_Mul_output_0_layer, 742,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_21_cv2_act_Mul_output_0_chain,
  NULL, &_model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_21_cv2_act_Sigmoid_output_0_nl_params_data[] = { -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -115, -115, -115, -114, -114, -113, -113, -112, -112, -111, -110, -110, -109, -109, -108, -107, -107, -106, -105, -104, -104, -103, -102, -101, -100, -99, -98, -97, -96, -95, -94, -93, -92, -91, -90, -89, -88, -86, -85, -84, -83, -81, -80, -78, -77, -75, -74, -72, -71, -69, -68, -66, -64, -62, -61, -59, -57, -55, -53, -51, -49, -47, -45, -43, -41, -39, -37, -35, -33, -30, -28, -26, -24, -21, -19, -17, -14, -12, -10, -7, -5, -3, 0, 2, 5, 7, 9, 12, 14, 17, 19, 21, 24, 26, 28, 31, 33, 35, 38, 40, 42, 44, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 67, 69, 71, 73, 75, 76, 78, 80, 82, 83, 85, 86, 88, 90, 91, 92, 94, 95, 97, 98, 99, 101, 102, 103, 104, 105, 106, 108, 109, 110, 111, 112, 113, 113, 114, 115, 116, 117, 118, 118, 119, 120, 121, 121, 122, 123, 123, 124, 125, 125, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_21_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_21_cv2_act_Sigmoid_output_0_nl_params_data, _model_21_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_cv2_act_Sigmoid_output_0_layer, 739,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_21_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_21_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_21_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_21_cv2_conv_Conv_output_0_weights, &_model_21_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_21_cv2_conv_Conv_output_0_layer, 736,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_21_cv2_conv_Conv_output_0_chain,
  NULL, &_model_21_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_21_Split_output_0_output0, &_model_21_Split_output_0_output1, &_model_21_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_Concat_output_0_layer, 733,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_21_Concat_output_0_chain,
  NULL, &_model_21_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_21_m_0_cv2_conv_Conv_output_0_output, &_model_21_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Mul_output_0_layer, 730,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_21_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_21_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_21_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -113, -113, -113, -112, -112, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -106, -105, -104, -104, -103, -102, -102, -101, -100, -100, -99, -98, -97, -97, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -78, -76, -75, -74, -73, -71, -70, -69, -67, -66, -65, -63, -62, -60, -59, -57, -56, -54, -53, -51, -50, -48, -46, -45, -43, -41, -40, -38, -36, -34, -33, -31, -29, -27, -25, -24, -22, -20, -18, -16, -14, -12, -10, -8, -7, -5, -3, -1, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 20, 22, 24, 26, 28, 30, 32, 34, 35, 37, 39, 41, 43, 44, 46, 48, 50, 51, 53, 55, 56, 58, 60, 61, 63, 64, 66, 68, 69, 70, 72, 73, 75, 76, 78, 79, 80, 82, 83, 84, 85, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 99, 100, 101, 101, 102, 103, 104, 105, 106, 107, 107, 108, 109, 110, 110, 111, 112, 113, 113, 114, 114, 115, 116, 116, 117, 117, 118, 119, 119, 120, 120, 121, 121, 121, 122, 122, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_21_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_21_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_21_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv2_act_Sigmoid_output_0_layer, 727,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_21_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_21_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_21_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_21_m_0_cv2_conv_Conv_output_0_weights, &_model_21_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_layer, 724,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_21_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_21_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_21_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -105 };
AI_ARRAY_OBJ_DECLARE(
    _model_21_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_21_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_21_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv2_conv_Conv_output_0_pad_before_layer, 724,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_21_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_21_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_21_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_21_m_0_cv1_conv_Conv_output_0_output, &_model_21_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Mul_output_0_layer, 721,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_21_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_21_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_21_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -117, -116, -116, -116, -115, -115, -114, -114, -114, -113, -113, -112, -112, -112, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -105, -105, -104, -103, -103, -102, -101, -101, -100, -99, -99, -98, -97, -96, -95, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -78, -77, -76, -75, -74, -72, -71, -70, -68, -67, -66, -64, -63, -61, -60, -58, -57, -55, -54, -52, -51, -49, -47, -46, -44, -42, -41, -39, -37, -36, -34, -32, -30, -28, -27, -25, -23, -21, -19, -17, -15, -14, -12, -10, -8, -6, -4, -2, 0, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 34, 36, 38, 40, 42, 44, 45, 47, 49, 51, 52, 54, 56, 57, 59, 61, 62, 64, 65, 67, 68, 70, 71, 73, 74, 76, 77, 79, 80, 81, 83, 84, 85, 86, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 99, 100, 101, 102, 103, 103, 104, 105, 106, 107, 108, 109, 109, 110, 111, 112, 112, 113, 114, 114, 115, 116, 116, 117, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 123, 123, 124, 124, 124, 125, 125, 126, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_21_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_21_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_21_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv1_act_Sigmoid_output_0_layer, 718,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_21_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_21_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_21_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_21_m_0_cv1_conv_Conv_output_0_weights, &_model_21_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_layer, 712,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_21_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_21_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_21_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -113 };
AI_ARRAY_OBJ_DECLARE(
    _model_21_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_21_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_21_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_m_0_cv1_conv_Conv_output_0_pad_before_layer, 712,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_21_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_21_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_21_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_21_Split_output_0_output0, &_model_21_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_Split_output_0_layer, 704,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_21_Split_output_0_chain,
  NULL, &_model_21_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 25, 
  .outer_elems_stride = 256, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_21_cv1_conv_Conv_output_0_output, &_model_21_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_cv1_act_Mul_output_0_layer, 695,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_21_cv1_act_Mul_output_0_chain,
  NULL, &_model_21_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_21_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -121, -121, -121, -120, -120, -120, -119, -119, -119, -118, -118, -117, -117, -116, -116, -115, -115, -114, -113, -113, -112, -111, -110, -110, -109, -108, -107, -106, -105, -104, -103, -102, -101, -100, -99, -98, -96, -95, -94, -92, -91, -89, -88, -86, -84, -83, -81, -79, -77, -75, -73, -71, -69, -67, -65, -62, -60, -58, -55, -53, -50, -48, -45, -43, -40, -37, -34, -32, -29, -26, -23, -20, -17, -14, -11, -8, -5, -2, 1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 30, 33, 36, 39, 42, 44, 47, 49, 52, 55, 57, 59, 62, 64, 66, 69, 71, 73, 75, 77, 79, 81, 83, 84, 86, 88, 89, 91, 92, 94, 95, 97, 98, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 111, 112, 113, 114, 114, 115, 116, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 121, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_21_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_21_cv1_act_Sigmoid_output_0_nl_params_data, _model_21_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_21_cv1_act_Sigmoid_output_0_layer, 686,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_21_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_21_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_21_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_20_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_21_cv1_conv_Conv_output_0_weights, &_model_21_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_21_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_21_cv1_conv_Conv_output_0_layer, 677,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_21_cv1_conv_Conv_output_0_chain,
  NULL, &_model_21_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_20_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_19_act_Mul_output_0_output, &_model_9_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_20_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_20_Concat_output_0_layer, 668,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_20_Concat_output_0_chain,
  NULL, &_model_21_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_19_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_19_conv_Conv_output_0_output, &_model_19_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_19_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_19_act_Mul_output_0_layer, 659,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_19_act_Mul_output_0_chain,
  NULL, &_model_20_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_19_act_Sigmoid_output_0_nl_params_data[] = { -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -117, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -109, -108, -108, -107, -106, -106, -105, -105, -104, -103, -103, -102, -101, -100, -100, -99, -98, -97, -96, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -81, -80, -79, -78, -77, -75, -74, -73, -71, -70, -69, -67, -66, -64, -63, -62, -60, -58, -57, -55, -54, -52, -50, -49, -47, -45, -44, -42, -40, -38, -37, -35, -33, -31, -29, -27, -26, -24, -22, -20, -18, -16, -14, -12, -10, -8, -6, -4, -2, 0, 2, 4, 6, 8, 10, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 34, 36, 38, 40, 42, 43, 45, 47, 49, 50, 52, 54, 55, 57, 59, 60, 62, 63, 65, 66, 68, 69, 71, 72, 73, 75, 76, 77, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 101, 102, 103, 104, 104, 105, 106, 107, 107, 108, 109, 109, 110, 110, 111, 111, 112, 113, 113, 114, 114, 115, 115, 115, 116, 116, 117, 117, 118, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_19_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_19_act_Sigmoid_output_0_nl_params_data, _model_19_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_19_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_19_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_19_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_19_act_Sigmoid_output_0_layer, 650,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_19_act_Sigmoid_output_0_chain,
  NULL, &_model_19_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_19_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_19_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_19_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_19_conv_Conv_output_0_weights, &_model_19_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_19_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_layer, 641,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_sssa8_ch,
  &_model_19_conv_Conv_output_0_chain,
  NULL, &_model_19_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(2, 2), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_19_conv_Conv_output_0_pad_before_value_data[] = { -106 };
AI_ARRAY_OBJ_DECLARE(
    _model_19_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_19_conv_Conv_output_0_pad_before_value_data, _model_19_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_19_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_19_conv_Conv_output_0_pad_before_layer, 641,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_19_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_19_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_19_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_18_cv2_conv_Conv_output_0_output, &_model_18_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_cv2_act_Mul_output_0_layer, 638,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_18_cv2_act_Mul_output_0_chain,
  NULL, &_model_19_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_18_cv2_act_Sigmoid_output_0_nl_params_data[] = { -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -105, -105, -104, -104, -103, -102, -102, -101, -100, -99, -99, -98, -97, -96, -95, -94, -93, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -82, -81, -80, -79, -78, -76, -75, -74, -73, -71, -70, -69, -67, -66, -64, -63, -61, -60, -58, -57, -55, -54, -52, -50, -49, -47, -45, -44, -42, -40, -39, -37, -35, -33, -31, -29, -28, -26, -24, -22, -20, -18, -16, -14, -12, -10, -8, -6, -4, -2, 0, 2, 4, 6, 8, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 40, 42, 44, 46, 48, 50, 51, 53, 55, 57, 58, 60, 62, 63, 65, 66, 68, 69, 71, 72, 74, 75, 77, 78, 80, 81, 82, 84, 85, 86, 87, 89, 90, 91, 92, 93, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 105, 106, 107, 108, 109, 110, 110, 111, 112, 113, 113, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 123, 123, 124, 124, 125, 125, 125, 126, 126, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_18_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_18_cv2_act_Sigmoid_output_0_nl_params_data, _model_18_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_cv2_act_Sigmoid_output_0_layer, 635,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_18_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_18_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_18_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_18_cv2_conv_Conv_output_0_weights, &_model_18_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_18_cv2_conv_Conv_output_0_layer, 632,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_18_cv2_conv_Conv_output_0_chain,
  NULL, &_model_18_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_18_Split_output_0_output0, &_model_18_Split_output_0_output1, &_model_18_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_Concat_output_0_layer, 629,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_18_Concat_output_0_chain,
  NULL, &_model_18_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_18_m_0_cv2_conv_Conv_output_0_output, &_model_18_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Mul_output_0_layer, 626,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_18_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_18_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_18_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -109, -108, -108, -107, -106, -106, -105, -104, -104, -103, -102, -102, -101, -100, -99, -98, -98, -97, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -80, -79, -78, -77, -75, -74, -73, -71, -70, -68, -67, -65, -64, -62, -61, -59, -58, -56, -54, -53, -51, -49, -48, -46, -44, -42, -41, -39, -37, -35, -33, -31, -29, -27, -26, -24, -22, -20, -18, -16, -14, -12, -10, -8, -6, -4, -2, 0, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 34, 36, 38, 40, 42, 44, 46, 47, 49, 51, 53, 54, 56, 58, 59, 61, 63, 64, 66, 67, 69, 70, 72, 73, 75, 76, 78, 79, 80, 82, 83, 84, 85, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 104, 105, 106, 107, 107, 108, 109, 109, 110, 111, 111, 112, 113, 113, 114, 114, 115, 115, 116, 116, 117, 117, 118, 118, 119, 119, 119, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 126, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_18_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_18_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_18_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv2_act_Sigmoid_output_0_layer, 623,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_18_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_18_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_18_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_18_m_0_cv2_conv_Conv_output_0_weights, &_model_18_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_layer, 620,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_18_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_18_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_18_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -94 };
AI_ARRAY_OBJ_DECLARE(
    _model_18_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_18_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_18_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv2_conv_Conv_output_0_pad_before_layer, 620,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_18_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_18_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_18_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_18_m_0_cv1_conv_Conv_output_0_output, &_model_18_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Mul_output_0_layer, 617,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_18_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_18_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_18_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -114, -114, -113, -113, -113, -112, -112, -112, -112, -111, -111, -111, -110, -110, -110, -109, -109, -109, -108, -108, -107, -107, -107, -106, -106, -106, -105, -105, -104, -104, -103, -103, -102, -102, -102, -101, -101, -100, -100, -99, -99, -98, -98, -97, -96, -96, -95, -95, -94, -94, -93, -92, -92, -91, -90, -90, -89, -88, -88, -87, -86, -86, -85, -84, -84, -83, -82, -81, -80, -80, -79, -78, -77, -76, -76, -75, -74, -73, -72, -71, -70, -69, -68, -68, -67, -66, -65, -64, -63, -62, -61, -60, -59, -58, -57, -55, -54, -53, -52, -51, -50, -49, -48, -47, -45, -44, -43, -42, -41, -40, -38, -37, -36, -35, -33, -32, -31, -30, -28, -27, -26, -24, -23, -22, -20, -19, -18, -16, -15, -14, -12, -11, -10, -8, -7, -5, -4, -3, -1, 0, 1, 3, 4, 6, 7, 9, 10, 11, 13, 14, 16, 17, 18, 20, 21, 23, 24, 26, 27, 28, 30, 31, 33, 34, 35, 37, 38, 39, 41, 42, 44, 45, 46, 48, 49, 50, 52, 53, 54, 56, 57, 58, 59, 61, 62, 63, 65, 66, 67, 68, 70, 71, 72, 73, 74, 75, 77, 78, 79, 80, 81, 82, 83, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 102, 103, 104, 105, 106, 107, 108, 108, 109, 110, 111, 112, 112, 113, 114, 115, 115, 116, 117, 118, 118, 119, 120, 120, 121, 122, 122, 123, 124, 124, 125, 125, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_18_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_18_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_18_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv1_act_Sigmoid_output_0_layer, 614,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_18_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_18_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_18_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_18_m_0_cv1_conv_Conv_output_0_weights, &_model_18_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_layer, 608,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_18_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_18_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_18_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -105 };
AI_ARRAY_OBJ_DECLARE(
    _model_18_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_18_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_18_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_m_0_cv1_conv_Conv_output_0_pad_before_layer, 608,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_18_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_18_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_18_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_18_Split_output_0_output0, &_model_18_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_Split_output_0_layer, 600,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_18_Split_output_0_chain,
  NULL, &_model_18_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 100, 
  .outer_elems_stride = 128, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_18_cv1_conv_Conv_output_0_output, &_model_18_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_cv1_act_Mul_output_0_layer, 591,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_18_cv1_act_Mul_output_0_chain,
  NULL, &_model_18_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_18_cv1_act_Sigmoid_output_0_nl_params_data[] = { -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -105, -105, -104, -104, -103, -102, -102, -101, -100, -100, -99, -98, -97, -97, -96, -95, -94, -93, -92, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -77, -76, -75, -74, -73, -71, -70, -69, -67, -66, -65, -63, -62, -61, -59, -58, -56, -55, -53, -52, -50, -49, -47, -46, -44, -42, -41, -39, -37, -36, -34, -32, -30, -29, -27, -25, -23, -22, -20, -18, -16, -14, -12, -11, -9, -7, -5, -3, -1, 1, 3, 4, 6, 8, 10, 12, 14, 16, 18, 20, 21, 23, 25, 27, 29, 31, 32, 34, 36, 38, 40, 41, 43, 45, 47, 48, 50, 52, 53, 55, 57, 58, 60, 61, 63, 65, 66, 68, 69, 71, 72, 73, 75, 76, 78, 79, 80, 82, 83, 84, 85, 87, 88, 89, 90, 91, 92, 93, 95, 96, 97, 98, 99, 100, 101, 102, 103, 103, 104, 105, 106, 107, 108, 109, 109, 110, 111, 112, 112, 113, 114, 114, 115, 116, 116, 117, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 123, 123, 124, 124, 125, 125, 125, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_18_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_18_cv1_act_Sigmoid_output_0_nl_params_data, _model_18_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_18_cv1_act_Sigmoid_output_0_layer, 582,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_18_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_18_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_18_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_17_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_18_cv1_conv_Conv_output_0_weights, &_model_18_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_18_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_18_cv1_conv_Conv_output_0_layer, 573,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_18_cv1_conv_Conv_output_0_chain,
  NULL, &_model_18_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_17_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_16_act_Mul_output_0_output, &_model_12_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_17_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_17_Concat_output_0_layer, 564,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_17_Concat_output_0_chain,
  NULL, &_model_18_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_16_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_16_conv_Conv_output_0_output, &_model_16_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_16_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_16_act_Mul_output_0_layer, 555,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_16_act_Mul_output_0_chain,
  NULL, &_model_17_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_16_act_Sigmoid_output_0_nl_params_data[] = { -123, -123, -123, -122, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -120, -119, -119, -119, -119, -119, -118, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -113, -112, -112, -111, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -106, -105, -105, -104, -104, -103, -102, -102, -101, -100, -100, -99, -98, -98, -97, -96, -95, -95, -94, -93, -92, -91, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -78, -77, -76, -75, -74, -72, -71, -70, -69, -68, -66, -65, -64, -63, -61, -60, -58, -57, -56, -54, -53, -51, -50, -48, -47, -45, -44, -42, -41, -39, -38, -36, -34, -33, -31, -30, -28, -26, -24, -23, -21, -19, -18, -16, -14, -12, -11, -9, -7, -5, -4, -2, 0, 2, 4, 5, 7, 9, 11, 13, 14, 16, 18, 20, 21, 23, 25, 27, 29, 30, 32, 34, 35, 37, 39, 41, 42, 44, 46, 47, 49, 50, 52, 54, 55, 57, 58, 60, 61, 63, 64, 66, 67, 69, 70, 71, 73, 74, 76, 77, 78, 79, 81, 82, 83, 84, 86, 87, 88, 89, 90, 91, 92, 94, 95, 96, 97, 98, 99, 100, 101, 101, 102, 103, 104, 105, 106, 107, 108, 108, 109, 110, 111, 111, 112, 113, 113, 114, 115, 115, 116, 117, 117, 118, 119, 119, 120, 120, 121, 121, 122, 122, 123, 123, 124, 124, 125, 125, 125, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_16_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_16_act_Sigmoid_output_0_nl_params_data, _model_16_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_16_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_16_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_16_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_16_act_Sigmoid_output_0_layer, 546,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_16_act_Sigmoid_output_0_chain,
  NULL, &_model_16_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_16_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_16_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_16_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_16_conv_Conv_output_0_weights, &_model_16_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_16_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_layer, 537,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_sssa8_ch,
  &_model_16_conv_Conv_output_0_chain,
  NULL, &_model_16_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(2, 2), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_16_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_16_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_16_conv_Conv_output_0_pad_before_value_data, _model_16_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_16_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_16_conv_Conv_output_0_pad_before_layer, 537,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_16_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_16_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_16_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_15_cv2_conv_Conv_output_0_output, &_model_15_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_cv2_act_Mul_output_0_layer, 534,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_15_cv2_act_Mul_output_0_chain,
  NULL, &_model_16_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_15_cv2_act_Sigmoid_output_0_nl_params_data[] = { -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -110, -110, -109, -109, -108, -107, -107, -106, -105, -104, -104, -103, -102, -101, -100, -100, -99, -98, -97, -96, -95, -94, -93, -92, -90, -89, -88, -87, -86, -84, -83, -82, -80, -79, -78, -76, -75, -73, -72, -70, -68, -67, -65, -63, -62, -60, -58, -56, -54, -53, -51, -49, -47, -45, -43, -41, -39, -37, -34, -32, -30, -28, -26, -23, -21, -19, -17, -14, -12, -10, -7, -5, -3, 0, 2, 4, 7, 9, 11, 14, 16, 18, 21, 23, 25, 28, 30, 32, 35, 37, 39, 41, 43, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 73, 75, 77, 79, 80, 82, 83, 85, 87, 88, 90, 91, 92, 94, 95, 97, 98, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 116, 117, 118, 119, 119, 120, 121, 121, 122, 123, 123, 124, 124, 125, 125, 126, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_15_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_15_cv2_act_Sigmoid_output_0_nl_params_data, _model_15_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_cv2_act_Sigmoid_output_0_layer, 531,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_15_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_15_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_15_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_15_cv2_conv_Conv_output_0_weights, &_model_15_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_15_cv2_conv_Conv_output_0_layer, 528,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_15_cv2_conv_Conv_output_0_chain,
  NULL, &_model_15_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_15_Split_output_0_output0, &_model_15_Split_output_0_output1, &_model_15_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_Concat_output_0_layer, 525,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_15_Concat_output_0_chain,
  NULL, &_model_15_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_15_m_0_cv2_conv_Conv_output_0_output, &_model_15_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Mul_output_0_layer, 522,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_15_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_15_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_15_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -106, -106, -105, -105, -104, -103, -103, -102, -102, -101, -100, -100, -99, -98, -98, -97, -96, -95, -95, -94, -93, -92, -91, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -78, -77, -76, -75, -74, -73, -71, -70, -69, -68, -67, -65, -64, -63, -62, -60, -59, -58, -56, -55, -53, -52, -51, -49, -48, -46, -45, -43, -42, -40, -39, -37, -35, -34, -32, -31, -29, -27, -26, -24, -23, -21, -19, -18, -16, -14, -13, -11, -9, -7, -6, -4, -2, -1, 1, 3, 5, 6, 8, 10, 11, 13, 15, 16, 18, 20, 21, 23, 25, 26, 28, 30, 31, 33, 35, 36, 38, 39, 41, 42, 44, 45, 47, 48, 50, 51, 53, 54, 56, 57, 58, 60, 61, 62, 64, 65, 66, 68, 69, 70, 71, 72, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 94, 95, 96, 97, 98, 98, 99, 100, 100, 101, 102, 102, 103, 104, 104, 105, 106, 106, 107, 107, 108, 108, 109, 109, 110, 110, 111, 111, 112, 112, 113, 113, 114, 114, 114, 115, 115, 116, 116, 116, 117, 117, 117, 118, 118, 118, 118, 119, 119, 119, 120, 120, 120, 120, 121, 121, 121, 121, 122, 122, 122, 122, 122, 123, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_15_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_15_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_15_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv2_act_Sigmoid_output_0_layer, 519,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_15_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_15_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_15_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_15_m_0_cv2_conv_Conv_output_0_weights, &_model_15_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_layer, 516,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_15_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_15_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_15_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -94 };
AI_ARRAY_OBJ_DECLARE(
    _model_15_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_15_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_15_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv2_conv_Conv_output_0_pad_before_layer, 516,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_15_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_15_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_15_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_15_m_0_cv1_conv_Conv_output_0_output, &_model_15_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Mul_output_0_layer, 513,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_15_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_15_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_15_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -122, -122, -122, -121, -121, -121, -121, -121, -121, -120, -120, -120, -120, -120, -120, -119, -119, -119, -119, -119, -118, -118, -118, -118, -117, -117, -117, -117, -116, -116, -116, -116, -115, -115, -115, -115, -114, -114, -114, -113, -113, -113, -112, -112, -112, -111, -111, -110, -110, -110, -109, -109, -108, -108, -108, -107, -107, -106, -106, -105, -105, -104, -104, -103, -103, -102, -102, -101, -101, -100, -99, -99, -98, -98, -97, -96, -96, -95, -94, -94, -93, -92, -92, -91, -90, -89, -89, -88, -87, -86, -85, -84, -84, -83, -82, -81, -80, -79, -78, -77, -76, -75, -74, -73, -72, -71, -70, -69, -68, -67, -66, -65, -64, -62, -61, -60, -59, -58, -56, -55, -54, -53, -51, -50, -49, -47, -46, -45, -43, -42, -41, -39, -38, -36, -35, -33, -32, -30, -29, -27, -26, -24, -23, -21, -20, -18, -17, -15, -14, -12, -10, -9, -7, -6, -4, -2, -1, 1, 3, 4, 6, 8, 9, 11, 13, 14, 16, 17, 19, 21, 22, 24, 26, 27, 29, 31, 32, 34, 36, 37, 39, 40, 42, 44, 45, 47, 48, 50, 51, 53, 55, 56, 58, 59, 61, 62, 64, 65, 66, 68, 69, 71, 72, 74, 75, 76, 78, 79, 80, 82, 83, 84, 85, 87, 88, 89, 90, 92, 93, 94, 95, 96, 97, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 114, 115, 116, 117, 118, 119, 119, 120, 121, 122, 122, 123, 124, 125, 125, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_15_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_15_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_15_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv1_act_Sigmoid_output_0_layer, 510,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_15_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_15_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_15_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_15_m_0_cv1_conv_Conv_output_0_weights, &_model_15_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_layer, 507,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_15_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_15_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_15_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -100 };
AI_ARRAY_OBJ_DECLARE(
    _model_15_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_15_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_15_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_m_0_cv1_conv_Conv_output_0_pad_before_layer, 507,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_15_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_15_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_15_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_15_Split_output_0_output0, &_model_15_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_Split_output_0_layer, 502,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_15_Split_output_0_chain,
  NULL, &_model_15_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 400, 
  .outer_elems_stride = 64, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_15_cv1_conv_Conv_output_0_output, &_model_15_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_cv1_act_Mul_output_0_layer, 499,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_15_cv1_act_Mul_output_0_chain,
  NULL, &_model_15_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_15_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -116, -116, -116, -115, -115, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -108, -108, -107, -106, -106, -105, -104, -103, -103, -102, -101, -100, -99, -98, -97, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -85, -84, -83, -81, -80, -79, -77, -76, -74, -73, -71, -70, -68, -66, -65, -63, -61, -60, -58, -56, -54, -52, -50, -48, -46, -44, -42, -40, -38, -36, -34, -32, -29, -27, -25, -23, -20, -18, -16, -13, -11, -9, -6, -4, -2, 1, 3, 6, 8, 10, 13, 15, 18, 20, 23, 25, 27, 30, 32, 34, 37, 39, 41, 44, 46, 48, 50, 52, 55, 57, 59, 61, 63, 65, 67, 69, 71, 73, 75, 77, 79, 81, 82, 84, 86, 87, 89, 91, 92, 94, 95, 97, 98, 100, 101, 102, 104, 105, 106, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 124, 125, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_15_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_15_cv1_act_Sigmoid_output_0_nl_params_data, _model_15_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_15_cv1_act_Sigmoid_output_0_layer, 496,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_15_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_15_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_15_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_14_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_15_cv1_conv_Conv_output_0_weights, &_model_15_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_15_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_15_cv1_conv_Conv_output_0_layer, 493,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_15_cv1_conv_Conv_output_0_chain,
  NULL, &_model_15_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_14_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_13_Resize_output_0_output, &_model_4_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_14_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_14_Concat_output_0_layer, 490,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_14_Concat_output_0_chain,
  NULL, &_model_15_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)


AI_STATIC_CONST ai_float _model_13_Resize_output_0_scales_data[] = { 2.0, 2.0, 1.0, 1.0 };
AI_ARRAY_OBJ_DECLARE(
    _model_13_Resize_output_0_scales, AI_ARRAY_FORMAT_FLOAT,
    _model_13_Resize_output_0_scales_data, _model_13_Resize_output_0_scales_data, 4, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_13_Resize_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_13_Resize_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_13_Resize_output_0_layer, 487,
  UPSAMPLE_TYPE, 0x0, NULL,
  upsample, forward_upsample_nearest,
  &_model_13_Resize_output_0_chain,
  NULL, &_model_14_Concat_output_0_layer, AI_STATIC, 
  .scales = &_model_13_Resize_output_0_scales, 
  .center = false, 
  .mode = AI_UPSAMPLE_NEAREST, 
  .nearest_mode = AI_ROUND_FLOOR, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_12_cv2_conv_Conv_output_0_output, &_model_12_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_cv2_act_Mul_output_0_layer, 484,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_12_cv2_act_Mul_output_0_chain,
  NULL, &_model_13_Resize_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_12_cv2_act_Sigmoid_output_0_nl_params_data[] = { -119, -119, -119, -118, -118, -118, -118, -118, -117, -117, -117, -117, -116, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -113, -113, -112, -112, -111, -111, -111, -110, -110, -110, -109, -109, -108, -108, -108, -107, -107, -106, -106, -105, -105, -104, -104, -103, -103, -102, -102, -101, -101, -100, -99, -99, -98, -98, -97, -96, -96, -95, -94, -94, -93, -92, -92, -91, -90, -89, -89, -88, -87, -86, -85, -85, -84, -83, -82, -81, -80, -79, -79, -78, -77, -76, -75, -74, -73, -72, -71, -70, -69, -67, -66, -65, -64, -63, -62, -61, -60, -58, -57, -56, -55, -54, -52, -51, -50, -48, -47, -46, -45, -43, -42, -40, -39, -38, -36, -35, -33, -32, -31, -29, -28, -26, -25, -23, -22, -20, -19, -17, -16, -14, -13, -11, -10, -8, -6, -5, -3, -2, 0, 1, 3, 5, 6, 8, 9, 11, 12, 14, 16, 17, 19, 20, 22, 23, 25, 27, 28, 30, 31, 33, 34, 36, 37, 39, 40, 42, 43, 45, 46, 48, 49, 51, 52, 54, 55, 57, 58, 59, 61, 62, 63, 65, 66, 67, 69, 70, 71, 73, 74, 75, 76, 78, 79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 105, 106, 107, 108, 109, 110, 110, 111, 112, 113, 113, 114, 115, 115, 116, 117, 117, 118, 119, 119, 120, 121, 121, 122, 122, 123, 123, 124, 124, 125, 125, 126, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_12_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_12_cv2_act_Sigmoid_output_0_nl_params_data, _model_12_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_cv2_act_Sigmoid_output_0_layer, 481,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_12_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_12_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_12_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_12_cv2_conv_Conv_output_0_weights, &_model_12_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_12_cv2_conv_Conv_output_0_layer, 478,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_12_cv2_conv_Conv_output_0_chain,
  NULL, &_model_12_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_12_Split_output_0_output0, &_model_12_Split_output_0_output1, &_model_12_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_Concat_output_0_layer, 475,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_12_Concat_output_0_chain,
  NULL, &_model_12_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_12_m_0_cv2_conv_Conv_output_0_output, &_model_12_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Mul_output_0_layer, 472,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_12_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_12_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_12_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -112, -112, -112, -111, -111, -111, -110, -110, -110, -109, -109, -109, -108, -108, -108, -107, -107, -107, -106, -106, -105, -105, -105, -104, -104, -103, -103, -102, -102, -101, -101, -101, -100, -100, -99, -99, -98, -98, -97, -97, -96, -95, -95, -94, -94, -93, -93, -92, -91, -91, -90, -89, -89, -88, -88, -87, -86, -86, -85, -84, -83, -83, -82, -81, -80, -80, -79, -78, -77, -77, -76, -75, -74, -73, -72, -71, -71, -70, -69, -68, -67, -66, -65, -64, -63, -62, -61, -60, -59, -58, -57, -56, -55, -54, -53, -52, -51, -50, -49, -48, -47, -46, -44, -43, -42, -41, -40, -39, -37, -36, -35, -34, -33, -31, -30, -29, -28, -26, -25, -24, -23, -21, -20, -19, -17, -16, -15, -14, -12, -11, -10, -8, -7, -6, -4, -3, -1, 0, 1, 3, 4, 5, 7, 8, 9, 11, 12, 14, 15, 16, 18, 19, 21, 22, 23, 25, 26, 27, 29, 30, 31, 33, 34, 36, 37, 38, 40, 41, 42, 44, 45, 46, 48, 49, 50, 51, 53, 54, 55, 57, 58, 59, 60, 62, 63, 64, 65, 67, 68, 69, 70, 71, 73, 74, 75, 76, 77, 78, 79, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 102, 103, 104, 105, 106, 107, 108, 108, 109, 110, 111, 112, 112, 113, 114, 115, 115, 116, 117, 118, 118, 119, 120, 120, 121, 122, 122, 123, 123, 124, 125, 125, 126, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_12_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_12_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_12_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv2_act_Sigmoid_output_0_layer, 469,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_12_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_12_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_12_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_12_m_0_cv2_conv_Conv_output_0_weights, &_model_12_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_layer, 466,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_12_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_12_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_12_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -94 };
AI_ARRAY_OBJ_DECLARE(
    _model_12_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_12_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_12_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv2_conv_Conv_output_0_pad_before_layer, 466,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_12_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_12_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_12_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_12_m_0_cv1_conv_Conv_output_0_output, &_model_12_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Mul_output_0_layer, 463,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_12_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_12_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_12_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -121, -121, -121, -120, -120, -120, -120, -120, -120, -119, -119, -119, -119, -119, -118, -118, -118, -118, -117, -117, -117, -117, -117, -116, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -113, -113, -112, -112, -112, -111, -111, -110, -110, -110, -109, -109, -109, -108, -108, -107, -107, -106, -106, -105, -105, -105, -104, -104, -103, -102, -102, -101, -101, -100, -100, -99, -99, -98, -97, -97, -96, -95, -95, -94, -94, -93, -92, -91, -91, -90, -89, -88, -88, -87, -86, -85, -84, -84, -83, -82, -81, -80, -79, -78, -77, -76, -76, -75, -74, -73, -72, -71, -69, -68, -67, -66, -65, -64, -63, -62, -61, -59, -58, -57, -56, -55, -53, -52, -51, -50, -48, -47, -46, -44, -43, -42, -40, -39, -38, -36, -35, -33, -32, -31, -29, -28, -26, -25, -23, -22, -20, -19, -17, -16, -14, -13, -11, -9, -8, -6, -5, -3, -1, 0, 2, 3, 5, 7, 8, 10, 11, 13, 15, 16, 18, 19, 21, 23, 24, 26, 28, 29, 31, 32, 34, 36, 37, 39, 40, 42, 43, 45, 46, 48, 50, 51, 53, 54, 56, 57, 59, 60, 62, 63, 64, 66, 67, 69, 70, 71, 73, 74, 76, 77, 78, 80, 81, 82, 83, 85, 86, 87, 88, 90, 91, 92, 93, 94, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 113, 114, 115, 116, 117, 118, 119, 119, 120, 121, 122, 122, 123, 124, 125, 125, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_12_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_12_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_12_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv1_act_Sigmoid_output_0_layer, 460,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_12_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_12_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_12_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_12_m_0_cv1_conv_Conv_output_0_weights, &_model_12_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_layer, 457,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_12_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_12_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_12_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -112 };
AI_ARRAY_OBJ_DECLARE(
    _model_12_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_12_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_12_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_m_0_cv1_conv_Conv_output_0_pad_before_layer, 457,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_12_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_12_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_12_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_12_Split_output_0_output0, &_model_12_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_Split_output_0_layer, 452,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_12_Split_output_0_chain,
  NULL, &_model_12_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 100, 
  .outer_elems_stride = 128, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_12_cv1_conv_Conv_output_0_output, &_model_12_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_cv1_act_Mul_output_0_layer, 449,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_12_cv1_act_Mul_output_0_chain,
  NULL, &_model_12_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_12_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -121, -121, -121, -120, -120, -119, -119, -119, -118, -118, -117, -117, -116, -115, -115, -114, -113, -113, -112, -111, -110, -109, -108, -107, -106, -105, -104, -103, -102, -101, -99, -98, -97, -95, -94, -92, -90, -89, -87, -85, -83, -81, -79, -77, -75, -73, -70, -68, -66, -63, -61, -58, -55, -52, -50, -47, -44, -41, -38, -35, -32, -29, -25, -22, -19, -16, -12, -9, -6, -2, 1, 5, 8, 11, 15, 18, 21, 24, 28, 31, 34, 37, 40, 43, 46, 49, 52, 55, 58, 60, 63, 65, 68, 70, 73, 75, 77, 79, 81, 83, 85, 87, 89, 91, 93, 94, 96, 97, 99, 100, 102, 103, 104, 105, 107, 108, 109, 110, 111, 112, 112, 113, 114, 115, 116, 116, 117, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_12_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_12_cv1_act_Sigmoid_output_0_nl_params_data, _model_12_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_12_cv1_act_Sigmoid_output_0_layer, 446,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_12_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_12_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_12_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_11_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_12_cv1_conv_Conv_output_0_weights, &_model_12_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_12_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_12_cv1_conv_Conv_output_0_layer, 443,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_12_cv1_conv_Conv_output_0_chain,
  NULL, &_model_12_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_11_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_10_Resize_output_0_output, &_model_6_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_11_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_11_Concat_output_0_layer, 440,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_11_Concat_output_0_chain,
  NULL, &_model_12_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)


AI_STATIC_CONST ai_float _model_10_Resize_output_0_scales_data[] = { 2.0, 2.0, 1.0, 1.0 };
AI_ARRAY_OBJ_DECLARE(
    _model_10_Resize_output_0_scales, AI_ARRAY_FORMAT_FLOAT,
    _model_10_Resize_output_0_scales_data, _model_10_Resize_output_0_scales_data, 4, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_10_Resize_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_10_Resize_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_10_Resize_output_0_layer, 437,
  UPSAMPLE_TYPE, 0x0, NULL,
  upsample, forward_upsample_nearest,
  &_model_10_Resize_output_0_chain,
  NULL, &_model_11_Concat_output_0_layer, AI_STATIC, 
  .scales = &_model_10_Resize_output_0_scales, 
  .center = false, 
  .mode = AI_UPSAMPLE_NEAREST, 
  .nearest_mode = AI_ROUND_FLOOR, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_9_cv2_conv_Conv_output_0_output, &_model_9_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_cv2_act_Mul_output_0_layer, 434,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_9_cv2_act_Mul_output_0_chain,
  NULL, &_model_10_Resize_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_9_cv2_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -122, -121, -121, -121, -121, -120, -120, -120, -119, -119, -119, -118, -118, -117, -117, -116, -116, -115, -115, -114, -114, -113, -113, -112, -112, -111, -110, -110, -109, -108, -107, -106, -106, -105, -104, -103, -102, -101, -100, -99, -98, -97, -96, -94, -93, -92, -91, -89, -88, -86, -85, -83, -82, -80, -79, -77, -75, -73, -72, -70, -68, -66, -64, -62, -60, -58, -56, -53, -51, -49, -47, -44, -42, -40, -37, -35, -32, -30, -27, -25, -22, -19, -17, -14, -11, -9, -6, -3, -1, 2, 5, 7, 10, 13, 15, 18, 21, 23, 26, 29, 31, 34, 36, 39, 41, 44, 46, 48, 51, 53, 55, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 79, 81, 83, 84, 86, 87, 89, 90, 92, 93, 95, 96, 97, 98, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 110, 111, 112, 113, 114, 114, 115, 116, 116, 117, 117, 118, 119, 119, 120, 120, 120, 121, 121, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_9_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_9_cv2_act_Sigmoid_output_0_nl_params_data, _model_9_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_cv2_act_Sigmoid_output_0_layer, 431,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_9_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_9_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_9_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_9_cv2_conv_Conv_output_0_weights, &_model_9_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_9_cv2_conv_Conv_output_0_layer, 428,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_9_cv2_conv_Conv_output_0_chain,
  NULL, &_model_9_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 4, &_model_9_cv1_act_Mul_output_0_output, &_model_9_m_MaxPool_output_0_output, &_model_9_m_1_MaxPool_output_0_output, &_model_9_m_2_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_Concat_output_0_layer, 425,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_9_Concat_output_0_chain,
  NULL, &_model_9_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_m_2_MaxPool_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_m_1_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_m_2_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_m_2_MaxPool_output_0_layer, 422,
  POOL_TYPE, 0x0, NULL,
  pool, forward_mp_integer_INT8,
  &_model_9_m_2_MaxPool_output_0_chain,
  NULL, &_model_9_Concat_output_0_layer, AI_STATIC, 
  .pool_size = AI_SHAPE_2D_INIT(5, 5), 
  .pool_stride = AI_SHAPE_2D_INIT(1, 1), 
  .pool_pad = AI_SHAPE_INIT(4, 2, 2, 2, 2), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_m_1_MaxPool_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_m_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_m_1_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_m_1_MaxPool_output_0_layer, 419,
  POOL_TYPE, 0x0, NULL,
  pool, forward_mp_integer_INT8,
  &_model_9_m_1_MaxPool_output_0_chain,
  NULL, &_model_9_m_2_MaxPool_output_0_layer, AI_STATIC, 
  .pool_size = AI_SHAPE_2D_INIT(5, 5), 
  .pool_stride = AI_SHAPE_2D_INIT(1, 1), 
  .pool_pad = AI_SHAPE_INIT(4, 2, 2, 2, 2), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_m_MaxPool_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_m_MaxPool_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_m_MaxPool_output_0_layer, 416,
  POOL_TYPE, 0x0, NULL,
  pool, forward_mp_integer_INT8,
  &_model_9_m_MaxPool_output_0_chain,
  NULL, &_model_9_m_1_MaxPool_output_0_layer, AI_STATIC, 
  .pool_size = AI_SHAPE_2D_INIT(5, 5), 
  .pool_stride = AI_SHAPE_2D_INIT(1, 1), 
  .pool_pad = AI_SHAPE_INIT(4, 2, 2, 2, 2), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_9_cv1_conv_Conv_output_0_output, &_model_9_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_cv1_act_Mul_output_0_layer, 413,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_9_cv1_act_Mul_output_0_chain,
  NULL, &_model_9_m_MaxPool_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_9_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -122, -122, -122, -121, -121, -121, -120, -120, -119, -119, -119, -118, -117, -117, -116, -116, -115, -114, -114, -113, -112, -111, -110, -109, -108, -107, -106, -105, -104, -103, -101, -100, -99, -97, -96, -94, -92, -91, -89, -87, -85, -83, -81, -79, -77, -74, -72, -70, -67, -64, -62, -59, -56, -53, -50, -47, -44, -41, -38, -35, -31, -28, -25, -21, -18, -14, -11, -7, -4, 0, 3, 7, 10, 14, 17, 21, 24, 27, 31, 34, 37, 41, 44, 47, 50, 53, 56, 58, 61, 64, 66, 69, 71, 74, 76, 78, 80, 83, 85, 86, 88, 90, 92, 94, 95, 97, 98, 99, 101, 102, 103, 105, 106, 107, 108, 109, 110, 111, 111, 112, 113, 114, 114, 115, 116, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_9_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_9_cv1_act_Sigmoid_output_0_nl_params_data, _model_9_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_9_cv1_act_Sigmoid_output_0_layer, 410,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_9_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_9_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_9_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_9_cv1_conv_Conv_output_0_weights, &_model_9_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_9_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_9_cv1_conv_Conv_output_0_layer, 407,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_9_cv1_conv_Conv_output_0_chain,
  NULL, &_model_9_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_8_cv2_conv_Conv_output_0_output, &_model_8_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_cv2_act_Mul_output_0_layer, 404,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_8_cv2_act_Mul_output_0_chain,
  NULL, &_model_9_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_8_cv2_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -121, -121, -120, -120, -120, -119, -119, -118, -118, -117, -116, -116, -115, -114, -114, -113, -112, -111, -110, -109, -108, -107, -106, -105, -104, -102, -101, -100, -98, -97, -95, -94, -92, -90, -88, -86, -84, -82, -80, -78, -76, -73, -71, -68, -66, -63, -60, -57, -54, -51, -48, -45, -42, -39, -35, -32, -29, -25, -22, -18, -15, -11, -8, -4, 0, 3, 7, 10, 14, 17, 21, 24, 28, 31, 35, 38, 41, 44, 47, 50, 53, 56, 59, 62, 65, 67, 70, 72, 75, 77, 79, 81, 83, 85, 87, 89, 91, 93, 94, 96, 97, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 113, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_8_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_8_cv2_act_Sigmoid_output_0_nl_params_data, _model_8_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_cv2_act_Sigmoid_output_0_layer, 401,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_8_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_8_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_8_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_8_cv2_conv_Conv_output_0_weights, &_model_8_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_8_cv2_conv_Conv_output_0_layer, 398,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_8_cv2_conv_Conv_output_0_chain,
  NULL, &_model_8_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_8_Split_output_0_output0, &_model_8_Split_output_0_output1, &_model_8_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_Concat_output_0_layer, 395,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_8_Concat_output_0_chain,
  NULL, &_model_8_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_Add_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_8_Split_output_0_output1, &_model_8_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_Add_output_0_layer, 392,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_8_m_0_Add_output_0_chain,
  NULL, &_model_8_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_8_m_0_cv2_conv_Conv_output_0_output, &_model_8_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Mul_output_0_layer, 389,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_8_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_8_m_0_Add_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_8_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -121, -121, -120, -120, -119, -119, -118, -118, -117, -117, -116, -115, -115, -114, -113, -112, -111, -110, -109, -108, -107, -106, -105, -104, -103, -101, -100, -98, -97, -95, -93, -92, -90, -88, -86, -84, -82, -79, -77, -75, -72, -70, -67, -64, -61, -59, -56, -53, -49, -46, -43, -40, -36, -33, -29, -26, -22, -19, -15, -11, -8, -4, 0, 3, 7, 11, 14, 18, 22, 25, 29, 32, 36, 39, 42, 45, 49, 52, 55, 58, 61, 63, 66, 69, 71, 74, 76, 79, 81, 83, 85, 87, 89, 91, 93, 94, 96, 98, 99, 100, 102, 103, 104, 105, 107, 108, 109, 110, 111, 111, 112, 113, 114, 115, 115, 116, 116, 117, 118, 118, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_8_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_8_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_8_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv2_act_Sigmoid_output_0_layer, 386,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_8_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_8_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_8_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_8_m_0_cv2_conv_Conv_output_0_weights, &_model_8_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_layer, 383,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_8_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_8_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_8_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -113 };
AI_ARRAY_OBJ_DECLARE(
    _model_8_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_8_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_8_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv2_conv_Conv_output_0_pad_before_layer, 383,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_8_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_8_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_8_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_8_m_0_cv1_conv_Conv_output_0_output, &_model_8_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Mul_output_0_layer, 380,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_8_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_8_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_8_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -124, -124, -124, -124, -123, -123, -123, -122, -122, -122, -121, -121, -120, -120, -120, -119, -118, -118, -117, -117, -116, -115, -114, -113, -113, -112, -111, -110, -109, -107, -106, -105, -104, -102, -101, -99, -97, -96, -94, -92, -90, -88, -86, -83, -81, -79, -76, -73, -71, -68, -65, -62, -59, -56, -52, -49, -45, -42, -38, -34, -31, -27, -23, -19, -15, -11, -7, -3, 1, 5, 9, 13, 17, 21, 25, 29, 33, 36, 40, 44, 47, 51, 54, 57, 61, 64, 67, 70, 73, 75, 78, 81, 83, 85, 88, 90, 92, 94, 96, 98, 99, 101, 103, 104, 105, 107, 108, 109, 110, 112, 113, 114, 115, 115, 116, 117, 118, 118, 119, 120, 120, 121, 121, 122, 122, 123, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 126, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_8_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_8_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_8_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv1_act_Sigmoid_output_0_layer, 377,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_8_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_8_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_8_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_8_m_0_cv1_conv_Conv_output_0_weights, &_model_8_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_layer, 374,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_8_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_8_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_8_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -117 };
AI_ARRAY_OBJ_DECLARE(
    _model_8_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_8_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_8_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_m_0_cv1_conv_Conv_output_0_pad_before_layer, 374,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_8_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_8_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_8_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_8_Split_output_0_output0, &_model_8_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_Split_output_0_layer, 369,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_8_Split_output_0_chain,
  NULL, &_model_8_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 25, 
  .outer_elems_stride = 256, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_8_cv1_conv_Conv_output_0_output, &_model_8_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_cv1_act_Mul_output_0_layer, 366,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_8_cv1_act_Mul_output_0_chain,
  NULL, &_model_8_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_8_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -122, -122, -122, -122, -121, -121, -120, -120, -120, -119, -119, -118, -118, -117, -116, -116, -115, -114, -114, -113, -112, -111, -110, -109, -108, -107, -106, -105, -104, -103, -101, -100, -99, -97, -96, -94, -92, -91, -89, -87, -85, -83, -81, -79, -77, -74, -72, -70, -67, -64, -62, -59, -56, -53, -50, -47, -44, -41, -38, -35, -31, -28, -25, -21, -18, -14, -11, -7, -4, 0, 3, 7, 10, 14, 17, 21, 24, 28, 31, 34, 38, 41, 44, 47, 50, 53, 56, 59, 61, 64, 67, 69, 72, 74, 76, 79, 81, 83, 85, 87, 89, 90, 92, 94, 95, 97, 98, 100, 101, 102, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 113, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 120, 120, 120, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_8_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_8_cv1_act_Sigmoid_output_0_nl_params_data, _model_8_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_8_cv1_act_Sigmoid_output_0_layer, 363,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_8_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_8_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_8_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_8_cv1_conv_Conv_output_0_weights, &_model_8_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_8_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_8_cv1_conv_Conv_output_0_layer, 360,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_8_cv1_conv_Conv_output_0_chain,
  NULL, &_model_8_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_7_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_7_conv_Conv_output_0_output, &_model_7_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_7_act_Mul_output_0_layer, 357,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_7_act_Mul_output_0_chain,
  NULL, &_model_8_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_7_act_Sigmoid_output_0_nl_params_data[] = { -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -122, -121, -121, -121, -120, -120, -120, -119, -119, -119, -118, -118, -117, -117, -116, -116, -116, -115, -114, -114, -113, -113, -112, -111, -111, -110, -109, -109, -108, -107, -106, -105, -104, -104, -103, -102, -101, -100, -98, -97, -96, -95, -94, -92, -91, -90, -88, -87, -85, -84, -82, -81, -79, -77, -76, -74, -72, -70, -68, -66, -64, -62, -60, -58, -56, -54, -51, -49, -47, -44, -42, -39, -37, -34, -32, -29, -27, -24, -21, -19, -16, -13, -11, -8, -5, -3, 0, 3, 5, 8, 11, 14, 16, 19, 22, 24, 27, 29, 32, 35, 37, 39, 42, 44, 47, 49, 51, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 77, 79, 81, 82, 84, 86, 87, 88, 90, 91, 93, 94, 95, 96, 97, 99, 100, 101, 102, 103, 104, 105, 105, 106, 107, 108, 109, 110, 110, 111, 112, 112, 113, 113, 114, 115, 115, 116, 116, 117, 117, 117, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 123, 124, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_7_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_7_act_Sigmoid_output_0_nl_params_data, _model_7_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_7_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_7_act_Sigmoid_output_0_layer, 354,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_7_act_Sigmoid_output_0_chain,
  NULL, &_model_7_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_7_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_7_conv_Conv_output_0_weights, &_model_7_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_layer, 351,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_sssa8_ch,
  &_model_7_conv_Conv_output_0_chain,
  NULL, &_model_7_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(2, 2), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_7_conv_Conv_output_0_pad_before_value_data[] = { -107 };
AI_ARRAY_OBJ_DECLARE(
    _model_7_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_7_conv_Conv_output_0_pad_before_value_data, _model_7_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_7_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_7_conv_Conv_output_0_pad_before_layer, 351,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_7_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_7_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_7_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_cv2_conv_Conv_output_0_output, &_model_6_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_cv2_act_Mul_output_0_layer, 348,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_cv2_act_Mul_output_0_chain,
  NULL, &_model_7_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_6_cv2_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -121, -121, -120, -120, -120, -119, -119, -118, -118, -117, -117, -116, -115, -115, -114, -113, -113, -112, -111, -110, -109, -108, -107, -106, -105, -104, -103, -101, -100, -99, -97, -96, -94, -93, -91, -89, -88, -86, -84, -82, -80, -78, -75, -73, -71, -68, -66, -63, -60, -58, -55, -52, -49, -46, -43, -40, -37, -34, -30, -27, -24, -20, -17, -13, -10, -6, -3, 1, 4, 8, 11, 15, 18, 22, 25, 29, 32, 35, 39, 42, 45, 48, 52, 55, 58, 61, 63, 66, 69, 72, 74, 77, 79, 81, 84, 86, 88, 90, 92, 94, 96, 98, 100, 101, 103, 104, 106, 107, 109, 110, 111, 112, 114, 115, 116, 117, 118, 119, 119, 120, 121, 122, 123, 123, 124, 124, 125, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_6_cv2_act_Sigmoid_output_0_nl_params_data, _model_6_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_cv2_act_Sigmoid_output_0_layer, 345,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_6_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_6_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_6_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_6_cv2_conv_Conv_output_0_weights, &_model_6_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_6_cv2_conv_Conv_output_0_layer, 342,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_6_cv2_conv_Conv_output_0_chain,
  NULL, &_model_6_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 4, &_model_6_Split_output_0_output0, &_model_6_Split_output_0_output1, &_model_6_m_0_Add_output_0_output, &_model_6_m_1_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_Concat_output_0_layer, 339,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_6_Concat_output_0_chain,
  NULL, &_model_6_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_Add_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_m_0_Add_output_0_output, &_model_6_m_1_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_Add_output_0_layer, 336,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_m_1_Add_output_0_chain,
  NULL, &_model_6_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_m_1_cv2_conv_Conv_output_0_output, &_model_6_m_1_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Mul_output_0_layer, 333,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_m_1_cv2_act_Mul_output_0_chain,
  NULL, &_model_6_m_1_Add_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_6_m_1_cv2_act_Sigmoid_output_0_nl_params_data[] = { -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -112, -112, -111, -111, -111, -110, -110, -109, -108, -108, -107, -107, -106, -106, -105, -104, -104, -103, -102, -102, -101, -100, -100, -99, -98, -97, -96, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -77, -76, -75, -74, -72, -71, -70, -68, -67, -66, -64, -63, -61, -60, -58, -57, -55, -54, -52, -51, -49, -47, -46, -44, -42, -41, -39, -37, -36, -34, -32, -30, -28, -27, -25, -23, -21, -19, -17, -15, -14, -12, -10, -8, -6, -4, -2, 0, 2, 4, 6, 7, 9, 11, 13, 15, 17, 19, 21, 23, 24, 26, 28, 30, 32, 34, 35, 37, 39, 41, 42, 44, 46, 48, 49, 51, 52, 54, 56, 57, 59, 60, 62, 63, 65, 66, 68, 69, 70, 72, 73, 75, 76, 77, 78, 80, 81, 82, 83, 84, 85, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 96, 97, 98, 99, 100, 101, 101, 102, 103, 104, 104, 105, 106, 107, 107, 108, 108, 109, 110, 110, 111, 111, 112, 112, 113, 113, 114, 114, 115, 115, 116, 116, 117, 117, 117, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_1_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_6_m_1_cv2_act_Sigmoid_output_0_nl_params_data, _model_6_m_1_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv2_act_Sigmoid_output_0_layer, 330,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_6_m_1_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_6_m_1_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_6_m_1_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_6_m_1_cv2_conv_Conv_output_0_weights, &_model_6_m_1_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_layer, 327,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_6_m_1_cv2_conv_Conv_output_0_chain,
  NULL, &_model_6_m_1_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_6_m_1_cv2_conv_Conv_output_0_pad_before_value_data[] = { -99 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_1_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_6_m_1_cv2_conv_Conv_output_0_pad_before_value_data, _model_6_m_1_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv2_conv_Conv_output_0_pad_before_layer, 327,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_6_m_1_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_6_m_1_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_6_m_1_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_m_1_cv1_conv_Conv_output_0_output, &_model_6_m_1_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Mul_output_0_layer, 324,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_m_1_cv1_act_Mul_output_0_chain,
  NULL, &_model_6_m_1_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_6_m_1_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -115, -115, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -108, -108, -107, -106, -106, -105, -104, -103, -102, -102, -101, -100, -99, -98, -97, -96, -95, -94, -93, -92, -90, -89, -88, -87, -86, -84, -83, -82, -80, -79, -77, -76, -74, -73, -71, -69, -68, -66, -64, -63, -61, -59, -57, -55, -53, -51, -49, -47, -45, -43, -41, -39, -36, -34, -32, -30, -27, -25, -23, -20, -18, -16, -13, -11, -8, -6, -4, -1, 1, 4, 6, 9, 11, 14, 16, 19, 21, 24, 26, 29, 31, 34, 36, 38, 41, 43, 46, 48, 50, 53, 55, 57, 59, 61, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 83, 85, 87, 89, 91, 92, 94, 95, 97, 99, 100, 102, 103, 104, 106, 107, 108, 110, 111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 123, 124, 125, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_1_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_6_m_1_cv1_act_Sigmoid_output_0_nl_params_data, _model_6_m_1_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv1_act_Sigmoid_output_0_layer, 321,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_6_m_1_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_6_m_1_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_6_m_1_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_6_m_1_cv1_conv_Conv_output_0_weights, &_model_6_m_1_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_layer, 318,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_6_m_1_cv1_conv_Conv_output_0_chain,
  NULL, &_model_6_m_1_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_6_m_1_cv1_conv_Conv_output_0_pad_before_value_data[] = { -110 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_1_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_6_m_1_cv1_conv_Conv_output_0_pad_before_value_data, _model_6_m_1_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_1_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_1_cv1_conv_Conv_output_0_pad_before_layer, 318,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_6_m_1_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_6_m_1_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_6_m_1_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_Add_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_Split_output_0_output1, &_model_6_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_Add_output_0_layer, 315,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_m_0_Add_output_0_chain,
  NULL, &_model_6_m_1_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_m_0_cv2_conv_Conv_output_0_output, &_model_6_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Mul_output_0_layer, 312,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_6_m_0_Add_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_6_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -122, -121, -121, -121, -120, -120, -120, -119, -119, -119, -118, -118, -118, -117, -117, -116, -116, -115, -115, -114, -113, -113, -112, -112, -111, -110, -109, -109, -108, -107, -106, -105, -104, -103, -103, -102, -100, -99, -98, -97, -96, -95, -93, -92, -91, -89, -88, -86, -85, -83, -82, -80, -78, -77, -75, -73, -71, -69, -67, -65, -63, -61, -59, -56, -54, -52, -50, -47, -45, -42, -40, -37, -35, -32, -30, -27, -24, -22, -19, -16, -14, -11, -8, -5, -2, 0, 3, 6, 9, 11, 14, 17, 20, 22, 25, 28, 30, 33, 35, 38, 40, 43, 45, 48, 50, 53, 55, 57, 59, 61, 64, 66, 68, 70, 72, 74, 75, 77, 79, 81, 82, 84, 85, 87, 88, 90, 91, 93, 94, 95, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 108, 109, 110, 111, 111, 112, 113, 113, 114, 115, 115, 116, 116, 117, 117, 118, 118, 119, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_6_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_6_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv2_act_Sigmoid_output_0_layer, 309,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_6_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_6_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_6_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_6_m_0_cv2_conv_Conv_output_0_weights, &_model_6_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_layer, 306,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_6_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_6_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_6_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -114 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_6_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_6_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv2_conv_Conv_output_0_pad_before_layer, 306,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_6_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_6_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_6_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_m_0_cv1_conv_Conv_output_0_output, &_model_6_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Mul_output_0_layer, 303,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_6_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_6_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -121, -121, -121, -120, -120, -119, -119, -118, -118, -117, -117, -116, -115, -115, -114, -113, -113, -112, -111, -110, -109, -108, -107, -106, -105, -104, -102, -101, -100, -98, -97, -95, -94, -92, -90, -89, -87, -85, -83, -81, -78, -76, -74, -71, -69, -66, -64, -61, -58, -56, -53, -50, -47, -44, -40, -37, -34, -31, -27, -24, -21, -17, -14, -10, -7, -3, 0, 4, 7, 11, 14, 18, 21, 25, 28, 32, 35, 38, 41, 44, 48, 51, 54, 56, 59, 62, 65, 67, 70, 72, 75, 77, 79, 81, 83, 86, 87, 89, 91, 93, 95, 96, 98, 99, 101, 102, 103, 104, 106, 107, 108, 109, 110, 111, 112, 113, 113, 114, 115, 116, 116, 117, 118, 118, 119, 119, 120, 120, 121, 121, 121, 122, 122, 123, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_6_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_6_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv1_act_Sigmoid_output_0_layer, 300,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_6_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_6_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_6_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_6_m_0_cv1_conv_Conv_output_0_weights, &_model_6_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_layer, 297,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_6_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_6_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_6_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -119 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_6_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_6_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_m_0_cv1_conv_Conv_output_0_pad_before_layer, 297,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_6_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_6_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_6_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_Split_output_0_output0, &_model_6_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_Split_output_0_layer, 292,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_6_Split_output_0_chain,
  NULL, &_model_6_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 100, 
  .outer_elems_stride = 128, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_6_cv1_conv_Conv_output_0_output, &_model_6_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_cv1_act_Mul_output_0_layer, 289,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_6_cv1_act_Mul_output_0_chain,
  NULL, &_model_6_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_6_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -123, -123, -123, -122, -122, -122, -121, -121, -120, -120, -119, -119, -118, -118, -117, -116, -116, -115, -114, -113, -112, -111, -110, -109, -108, -107, -106, -104, -103, -101, -100, -98, -96, -95, -93, -91, -89, -87, -84, -82, -80, -77, -75, -72, -69, -66, -63, -60, -57, -53, -50, -47, -43, -39, -36, -32, -28, -24, -20, -16, -12, -8, -4, 0, 4, 8, 12, 16, 20, 23, 27, 31, 35, 39, 42, 46, 49, 53, 56, 59, 62, 65, 68, 71, 74, 76, 79, 81, 84, 86, 88, 90, 92, 94, 96, 97, 99, 100, 102, 103, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_6_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_6_cv1_act_Sigmoid_output_0_nl_params_data, _model_6_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_6_cv1_act_Sigmoid_output_0_layer, 286,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_6_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_6_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_6_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_6_cv1_conv_Conv_output_0_weights, &_model_6_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_6_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_6_cv1_conv_Conv_output_0_layer, 283,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_6_cv1_conv_Conv_output_0_chain,
  NULL, &_model_6_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_5_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_5_conv_Conv_output_0_output, &_model_5_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_5_act_Mul_output_0_layer, 280,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_5_act_Mul_output_0_chain,
  NULL, &_model_6_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_5_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -121, -121, -121, -120, -120, -119, -119, -118, -118, -117, -117, -116, -115, -115, -114, -113, -112, -112, -111, -110, -109, -108, -107, -106, -105, -104, -102, -101, -100, -98, -97, -95, -94, -92, -90, -88, -87, -85, -83, -81, -78, -76, -74, -72, -69, -67, -64, -61, -59, -56, -53, -50, -47, -44, -41, -38, -34, -31, -28, -24, -21, -18, -14, -11, -7, -4, 0, 3, 7, 10, 14, 17, 20, 24, 27, 30, 34, 37, 40, 43, 46, 49, 52, 55, 58, 61, 63, 66, 68, 71, 73, 76, 78, 80, 82, 84, 86, 88, 90, 91, 93, 95, 96, 98, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 113, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 119, 120, 120, 121, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_5_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_5_act_Sigmoid_output_0_nl_params_data, _model_5_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_5_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_5_act_Sigmoid_output_0_layer, 277,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_5_act_Sigmoid_output_0_chain,
  NULL, &_model_5_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_5_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_5_conv_Conv_output_0_weights, &_model_5_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_layer, 274,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_sssa8_ch,
  &_model_5_conv_Conv_output_0_chain,
  NULL, &_model_5_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(2, 2), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_5_conv_Conv_output_0_pad_before_value_data[] = { -112 };
AI_ARRAY_OBJ_DECLARE(
    _model_5_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_5_conv_Conv_output_0_pad_before_value_data, _model_5_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_5_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_5_conv_Conv_output_0_pad_before_layer, 274,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_5_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_5_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_5_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_cv2_conv_Conv_output_0_output, &_model_4_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_cv2_act_Mul_output_0_layer, 271,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_cv2_act_Mul_output_0_chain,
  NULL, &_model_5_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_4_cv2_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -122, -122, -122, -121, -121, -121, -121, -120, -120, -119, -119, -119, -118, -118, -117, -117, -116, -116, -115, -115, -114, -113, -113, -112, -111, -111, -110, -109, -108, -107, -107, -106, -105, -104, -103, -102, -100, -99, -98, -97, -96, -94, -93, -91, -90, -88, -87, -85, -84, -82, -80, -78, -76, -74, -72, -70, -68, -66, -64, -62, -59, -57, -55, -52, -50, -47, -44, -42, -39, -36, -34, -31, -28, -25, -22, -19, -16, -14, -11, -8, -5, -2, 1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 36, 39, 42, 45, 47, 50, 52, 55, 57, 60, 62, 64, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85, 86, 88, 90, 91, 93, 94, 96, 97, 98, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 113, 114, 115, 116, 116, 117, 117, 118, 119, 119, 120, 120, 121, 121, 121, 122, 122, 123, 123, 123, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 126, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_4_cv2_act_Sigmoid_output_0_nl_params_data, _model_4_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_cv2_act_Sigmoid_output_0_layer, 268,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_4_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_4_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_4_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_4_cv2_conv_Conv_output_0_weights, &_model_4_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_4_cv2_conv_Conv_output_0_layer, 265,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_4_cv2_conv_Conv_output_0_chain,
  NULL, &_model_4_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 4, &_model_4_Split_output_0_output0, &_model_4_Split_output_0_output1, &_model_4_m_0_Add_output_0_output, &_model_4_m_1_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_Concat_output_0_layer, 262,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_4_Concat_output_0_chain,
  NULL, &_model_4_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_Add_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_m_0_Add_output_0_output, &_model_4_m_1_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_Add_output_0_layer, 259,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_m_1_Add_output_0_chain,
  NULL, &_model_4_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_m_1_cv2_conv_Conv_output_0_output, &_model_4_m_1_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Mul_output_0_layer, 256,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_m_1_cv2_act_Mul_output_0_chain,
  NULL, &_model_4_m_1_Add_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_4_m_1_cv2_act_Sigmoid_output_0_nl_params_data[] = { -125, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -114, -114, -113, -113, -112, -112, -111, -111, -110, -110, -109, -109, -108, -107, -107, -106, -105, -105, -104, -103, -102, -102, -101, -100, -99, -98, -97, -97, -96, -95, -94, -93, -92, -91, -89, -88, -87, -86, -85, -84, -82, -81, -80, -78, -77, -76, -74, -73, -71, -70, -68, -67, -65, -64, -62, -60, -59, -57, -55, -53, -51, -50, -48, -46, -44, -42, -40, -38, -36, -34, -32, -30, -28, -26, -24, -22, -20, -18, -15, -13, -11, -9, -7, -5, -2, 0, 2, 4, 6, 8, 11, 13, 15, 17, 19, 21, 23, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 53, 55, 57, 59, 61, 62, 64, 66, 67, 69, 70, 72, 74, 75, 77, 78, 79, 81, 82, 83, 85, 86, 87, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 105, 106, 107, 108, 108, 109, 110, 110, 111, 112, 112, 113, 114, 114, 115, 115, 116, 116, 117, 117, 118, 118, 118, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_1_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_4_m_1_cv2_act_Sigmoid_output_0_nl_params_data, _model_4_m_1_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv2_act_Sigmoid_output_0_layer, 253,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_4_m_1_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_4_m_1_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_4_m_1_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_4_m_1_cv2_conv_Conv_output_0_weights, &_model_4_m_1_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_layer, 250,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_4_m_1_cv2_conv_Conv_output_0_chain,
  NULL, &_model_4_m_1_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_4_m_1_cv2_conv_Conv_output_0_pad_before_value_data[] = { -84 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_1_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_4_m_1_cv2_conv_Conv_output_0_pad_before_value_data, _model_4_m_1_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv2_conv_Conv_output_0_pad_before_layer, 250,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_4_m_1_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_4_m_1_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_4_m_1_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_m_1_cv1_conv_Conv_output_0_output, &_model_4_m_1_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Mul_output_0_layer, 247,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_m_1_cv1_act_Mul_output_0_chain,
  NULL, &_model_4_m_1_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_4_m_1_cv1_act_Sigmoid_output_0_nl_params_data[] = { -122, -122, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -121, -120, -120, -120, -120, -120, -120, -119, -119, -119, -119, -119, -118, -118, -118, -118, -118, -117, -117, -117, -117, -117, -116, -116, -116, -115, -115, -115, -115, -114, -114, -114, -114, -113, -113, -113, -112, -112, -112, -111, -111, -111, -110, -110, -109, -109, -109, -108, -108, -107, -107, -107, -106, -106, -105, -105, -104, -104, -103, -103, -102, -102, -101, -101, -100, -100, -99, -98, -98, -97, -97, -96, -95, -95, -94, -93, -93, -92, -91, -91, -90, -89, -88, -88, -87, -86, -85, -84, -84, -83, -82, -81, -80, -79, -78, -78, -77, -76, -75, -74, -73, -72, -71, -70, -69, -68, -67, -65, -64, -63, -62, -61, -60, -59, -57, -56, -55, -54, -53, -51, -50, -49, -47, -46, -45, -44, -42, -41, -39, -38, -37, -35, -34, -32, -31, -29, -28, -27, -25, -24, -22, -20, -19, -17, -16, -14, -13, -11, -10, -8, -6, -5, -3, -2, 0, 2, 3, 5, 7, 8, 10, 12, 13, 15, 17, 18, 20, 22, 23, 25, 27, 28, 30, 32, 33, 35, 37, 38, 40, 42, 43, 45, 47, 48, 50, 52, 53, 55, 56, 58, 60, 61, 63, 64, 66, 67, 69, 71, 72, 74, 75, 77, 78, 80, 81, 82, 84, 85, 87, 88, 90, 91, 92, 94, 95, 96, 98, 99, 100, 101, 103, 104, 105, 106, 108, 109, 110, 111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_1_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_4_m_1_cv1_act_Sigmoid_output_0_nl_params_data, _model_4_m_1_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv1_act_Sigmoid_output_0_layer, 244,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_4_m_1_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_4_m_1_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_4_m_1_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_4_m_1_cv1_conv_Conv_output_0_weights, &_model_4_m_1_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_layer, 241,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_4_m_1_cv1_conv_Conv_output_0_chain,
  NULL, &_model_4_m_1_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_4_m_1_cv1_conv_Conv_output_0_pad_before_value_data[] = { -97 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_1_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_4_m_1_cv1_conv_Conv_output_0_pad_before_value_data, _model_4_m_1_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_1_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_1_cv1_conv_Conv_output_0_pad_before_layer, 241,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_4_m_1_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_4_m_1_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_4_m_1_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_Add_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_Split_output_0_output1, &_model_4_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_Add_output_0_layer, 238,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_m_0_Add_output_0_chain,
  NULL, &_model_4_m_1_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_m_0_cv2_conv_Conv_output_0_output, &_model_4_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Mul_output_0_layer, 235,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_4_m_0_Add_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_4_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -125, -124, -124, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -123, -123, -123, -123, -122, -122, -122, -122, -122, -122, -121, -121, -121, -121, -121, -120, -120, -120, -120, -119, -119, -119, -119, -118, -118, -118, -118, -117, -117, -117, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -112, -112, -112, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -105, -105, -104, -104, -103, -102, -102, -101, -100, -100, -99, -98, -97, -97, -96, -95, -94, -93, -92, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -80, -79, -78, -77, -76, -75, -73, -72, -71, -70, -68, -67, -66, -64, -63, -61, -60, -59, -57, -56, -54, -52, -51, -49, -48, -46, -45, -43, -41, -40, -38, -36, -34, -33, -31, -29, -27, -26, -24, -22, -20, -18, -16, -14, -13, -11, -9, -7, -5, -3, -1, 1, 3, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 25, 27, 29, 31, 33, 35, 36, 38, 40, 42, 44, 45, 47, 49, 51, 52, 54, 56, 57, 59, 61, 62, 64, 65, 67, 68, 70, 71, 73, 74, 76, 77, 78, 80, 81, 82, 84, 85, 86, 87, 89, 90, 91, 92, 93, 94, 95, 96, 98, 99, 100, 101, 102, 102, 103, 104, 105, 106, 107, 108, 109, 109, 110, 111, 112, 112, 113, 114, 114, 115, 116, 116, 117, 118, 118, 119, 119, 120, 120, 121, 122, 122, 123, 123, 123, 124, 124, 125, 125, 126, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_4_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_4_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv2_act_Sigmoid_output_0_layer, 232,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_4_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_4_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_4_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_4_m_0_cv2_conv_Conv_output_0_weights, &_model_4_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_layer, 229,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_4_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_4_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_4_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -104 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_4_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_4_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv2_conv_Conv_output_0_pad_before_layer, 229,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_4_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_4_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_4_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_m_0_cv1_conv_Conv_output_0_output, &_model_4_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Mul_output_0_layer, 226,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_4_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_4_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -121, -121, -121, -121, -121, -120, -120, -120, -120, -120, -119, -119, -119, -119, -119, -118, -118, -118, -118, -117, -117, -117, -116, -116, -116, -116, -115, -115, -115, -114, -114, -114, -113, -113, -113, -112, -112, -111, -111, -111, -110, -110, -109, -109, -108, -108, -107, -107, -106, -106, -105, -105, -104, -104, -103, -103, -102, -101, -101, -100, -99, -99, -98, -97, -97, -96, -95, -95, -94, -93, -92, -91, -91, -90, -89, -88, -87, -86, -85, -84, -83, -83, -82, -81, -80, -78, -77, -76, -75, -74, -73, -72, -71, -70, -68, -67, -66, -65, -64, -62, -61, -60, -58, -57, -56, -54, -53, -52, -50, -49, -47, -46, -44, -43, -41, -40, -38, -37, -35, -34, -32, -30, -29, -27, -26, -24, -22, -21, -19, -17, -16, -14, -12, -11, -9, -7, -5, -4, -2, 0, 1, 3, 5, 7, 8, 10, 12, 14, 15, 17, 19, 20, 22, 24, 26, 27, 29, 31, 32, 34, 36, 37, 39, 41, 42, 44, 45, 47, 48, 50, 52, 53, 55, 56, 58, 59, 61, 62, 63, 65, 66, 68, 69, 70, 72, 73, 74, 76, 77, 78, 79, 81, 82, 83, 84, 85, 86, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 100, 101, 102, 103, 104, 105, 106, 106, 107, 108, 109, 109, 110, 111, 111, 112, 113, 113, 114, 115, 115, 116, 117, 117, 118, 118, 119, 119, 120, 120, 121, 121, 122, 122, 123, 123, 124, 124, 124, 125, 125, 126, 126, 126, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_4_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_4_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv1_act_Sigmoid_output_0_layer, 223,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_4_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_4_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_4_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_4_m_0_cv1_conv_Conv_output_0_weights, &_model_4_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_layer, 220,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_4_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_4_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_4_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -116 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_4_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_4_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_m_0_cv1_conv_Conv_output_0_pad_before_layer, 220,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_4_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_4_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_4_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_Split_output_0_output0, &_model_4_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_Split_output_0_layer, 215,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_4_Split_output_0_chain,
  NULL, &_model_4_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 400, 
  .outer_elems_stride = 64, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_4_cv1_conv_Conv_output_0_output, &_model_4_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_cv1_act_Mul_output_0_layer, 212,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_4_cv1_act_Mul_output_0_chain,
  NULL, &_model_4_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_4_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -121, -121, -120, -120, -120, -119, -119, -118, -118, -117, -116, -116, -115, -115, -114, -113, -112, -111, -110, -110, -109, -108, -106, -105, -104, -103, -102, -100, -99, -97, -96, -94, -93, -91, -89, -87, -85, -83, -81, -79, -77, -75, -72, -70, -67, -65, -62, -59, -56, -53, -50, -47, -44, -41, -38, -35, -31, -28, -25, -21, -18, -14, -11, -7, -4, 0, 3, 7, 11, 14, 18, 21, 25, 28, 31, 35, 38, 41, 44, 47, 50, 53, 56, 59, 62, 64, 67, 70, 72, 74, 77, 79, 81, 83, 85, 87, 89, 91, 93, 94, 96, 97, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 114, 115, 116, 116, 117, 118, 118, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_4_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_4_cv1_act_Sigmoid_output_0_nl_params_data, _model_4_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_4_cv1_act_Sigmoid_output_0_layer, 209,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_4_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_4_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_4_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_4_cv1_conv_Conv_output_0_weights, &_model_4_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_4_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_4_cv1_conv_Conv_output_0_layer, 206,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_4_cv1_conv_Conv_output_0_chain,
  NULL, &_model_4_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_3_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_3_conv_Conv_output_0_output, &_model_3_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_3_act_Mul_output_0_layer, 203,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_3_act_Mul_output_0_chain,
  NULL, &_model_4_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_3_act_Sigmoid_output_0_nl_params_data[] = { -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -125, -125, -125, -125, -124, -124, -124, -124, -124, -124, -123, -123, -123, -123, -122, -122, -122, -122, -121, -121, -121, -120, -120, -120, -119, -119, -119, -118, -118, -117, -117, -116, -116, -115, -115, -114, -114, -113, -112, -112, -111, -110, -110, -109, -108, -107, -106, -106, -105, -104, -103, -102, -101, -100, -98, -97, -96, -95, -93, -92, -91, -89, -88, -86, -85, -83, -81, -80, -78, -76, -74, -72, -70, -68, -66, -64, -62, -60, -58, -55, -53, -51, -48, -46, -43, -41, -38, -36, -33, -30, -28, -25, -22, -20, -17, -14, -11, -8, -6, -3, 0, 3, 6, 9, 11, 14, 17, 20, 23, 25, 28, 31, 33, 36, 39, 41, 44, 46, 49, 51, 53, 56, 58, 60, 62, 64, 67, 69, 71, 73, 74, 76, 78, 80, 82, 83, 85, 86, 88, 89, 91, 92, 94, 95, 96, 97, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 108, 109, 110, 111, 111, 112, 113, 113, 114, 114, 115, 116, 116, 117, 117, 118, 118, 118, 119, 119, 120, 120, 120, 121, 121, 121, 122, 122, 122, 122, 123, 123, 123, 123, 123, 124, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_3_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_3_act_Sigmoid_output_0_nl_params_data, _model_3_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_3_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_3_act_Sigmoid_output_0_layer, 200,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_3_act_Sigmoid_output_0_chain,
  NULL, &_model_3_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_3_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_3_conv_Conv_output_0_weights, &_model_3_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_layer, 197,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_sssa8_ch,
  &_model_3_conv_Conv_output_0_chain,
  NULL, &_model_3_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(2, 2), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_3_conv_Conv_output_0_pad_before_value_data[] = { -118 };
AI_ARRAY_OBJ_DECLARE(
    _model_3_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_3_conv_Conv_output_0_pad_before_value_data, _model_3_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_3_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_3_conv_Conv_output_0_pad_before_layer, 197,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_3_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_3_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_3_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_2_cv2_conv_Conv_output_0_output, &_model_2_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_cv2_act_Mul_output_0_layer, 194,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_2_cv2_act_Mul_output_0_chain,
  NULL, &_model_3_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_2_cv2_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -126, -126, -126, -125, -125, -125, -125, -124, -124, -124, -124, -123, -123, -123, -122, -122, -121, -121, -120, -120, -119, -118, -117, -117, -116, -115, -114, -113, -112, -111, -109, -108, -107, -105, -104, -102, -100, -98, -96, -94, -92, -89, -87, -84, -81, -78, -75, -72, -69, -65, -62, -58, -54, -50, -46, -42, -38, -33, -29, -24, -19, -15, -10, -5, 0, 4, 9, 14, 19, 23, 28, 32, 37, 41, 45, 49, 53, 57, 61, 65, 68, 71, 75, 78, 81, 83, 86, 89, 91, 93, 95, 97, 99, 101, 103, 104, 106, 107, 109, 110, 111, 112, 113, 114, 115, 116, 117, 117, 118, 119, 119, 120, 120, 121, 121, 122, 122, 122, 123, 123, 123, 124, 124, 124, 124, 125, 125, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_2_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_2_cv2_act_Sigmoid_output_0_nl_params_data, _model_2_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_cv2_act_Sigmoid_output_0_layer, 191,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_2_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_2_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_2_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_2_cv2_conv_Conv_output_0_weights, &_model_2_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_2_cv2_conv_Conv_output_0_layer, 188,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_2_cv2_conv_Conv_output_0_chain,
  NULL, &_model_2_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_Concat_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_2_Split_output_0_output0, &_model_2_Split_output_0_output1, &_model_2_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_Concat_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_Concat_output_0_layer, 185,
  CONCAT_TYPE, 0x0, NULL,
  concat, forward_concat,
  &_model_2_Concat_output_0_chain,
  NULL, &_model_2_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .axis = AI_SHAPE_CHANNEL, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_Add_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_2_Split_output_0_output1, &_model_2_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_Add_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_Add_output_0_layer, 182,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_2_m_0_Add_output_0_chain,
  NULL, &_model_2_Concat_output_0_layer, AI_STATIC, 
  .operation = ai_sum_f32, 
  .buffer_operation = ai_sum_buffer_INT8, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_2_m_0_cv2_conv_Conv_output_0_output, &_model_2_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv2_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Mul_output_0_layer, 179,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_2_m_0_cv2_act_Mul_output_0_chain,
  NULL, &_model_2_m_0_Add_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_2_m_0_cv2_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -126, -126, -126, -125, -125, -125, -124, -123, -122, -121, -120, -119, -117, -115, -113, -111, -108, -105, -101, -97, -92, -87, -81, -74, -67, -59, -50, -41, -31, -21, -11, -1, 10, 20, 30, 40, 49, 58, 66, 73, 80, 86, 91, 96, 100, 104, 107, 110, 112, 114, 116, 118, 119, 120, 121, 122, 123, 124, 124, 124, 125, 125, 125, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_2_m_0_cv2_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_2_m_0_cv2_act_Sigmoid_output_0_nl_params_data, _model_2_m_0_cv2_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv2_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv2_act_Sigmoid_output_0_layer, 176,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_2_m_0_cv2_act_Sigmoid_output_0_chain,
  NULL, &_model_2_m_0_cv2_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_2_m_0_cv2_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv2_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_2_m_0_cv2_conv_Conv_output_0_weights, &_model_2_m_0_cv2_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv2_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_layer, 173,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_2_m_0_cv2_conv_Conv_output_0_chain,
  NULL, &_model_2_m_0_cv2_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_2_m_0_cv2_conv_Conv_output_0_pad_before_value_data[] = { -124 };
AI_ARRAY_OBJ_DECLARE(
    _model_2_m_0_cv2_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_2_m_0_cv2_conv_Conv_output_0_pad_before_value_data, _model_2_m_0_cv2_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv2_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv2_conv_Conv_output_0_pad_before_layer, 173,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_2_m_0_cv2_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_2_m_0_cv2_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_2_m_0_cv2_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_2_m_0_cv1_conv_Conv_output_0_output, &_model_2_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Mul_output_0_layer, 170,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_2_m_0_cv1_act_Mul_output_0_chain,
  NULL, &_model_2_m_0_cv2_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_2_m_0_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -127, -127, -127, -127, -126, -126, -126, -126, -125, -125, -125, -124, -124, -123, -122, -121, -120, -119, -118, -117, -115, -114, -112, -110, -107, -104, -101, -98, -94, -90, -86, -81, -75, -69, -63, -56, -49, -42, -34, -26, -18, -9, -1, 8, 17, 25, 33, 41, 48, 55, 62, 68, 74, 80, 85, 89, 93, 97, 100, 103, 106, 109, 111, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 123, 124, 124, 124, 125, 125, 125, 125, 126, 126, 126, 126, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_2_m_0_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_2_m_0_cv1_act_Sigmoid_output_0_nl_params_data, _model_2_m_0_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv1_act_Sigmoid_output_0_layer, 167,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_2_m_0_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_2_m_0_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_2_m_0_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_2_m_0_cv1_conv_Conv_output_0_weights, &_model_2_m_0_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_layer, 164,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_deep_3x3_sssa8_ch,
  &_model_2_m_0_cv1_conv_Conv_output_0_chain,
  NULL, &_model_2_m_0_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)


AI_STATIC_CONST ai_i8 _model_2_m_0_cv1_conv_Conv_output_0_pad_before_value_data[] = { -124 };
AI_ARRAY_OBJ_DECLARE(
    _model_2_m_0_cv1_conv_Conv_output_0_pad_before_value, AI_ARRAY_FORMAT_S8,
    _model_2_m_0_cv1_conv_Conv_output_0_pad_before_value_data, _model_2_m_0_cv1_conv_Conv_output_0_pad_before_value_data, 1, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_pad_before_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_m_0_cv1_conv_Conv_output_0_pad_before_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_m_0_cv1_conv_Conv_output_0_pad_before_layer, 164,
  PAD_TYPE, 0x0, NULL,
  pad, forward_pad,
  &_model_2_m_0_cv1_conv_Conv_output_0_pad_before_chain,
  NULL, &_model_2_m_0_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .value = &_model_2_m_0_cv1_conv_Conv_output_0_pad_before_value, 
  .mode = AI_PAD_CONSTANT, 
  .pads = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_Split_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_2_Split_output_0_output0, &_model_2_Split_output_0_output1),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_Split_output_0_num_or_size_splits),
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_Split_output_0_layer, 159,
  SPLIT_TYPE, 0x0, NULL,
  split, forward_split,
  &_model_2_Split_output_0_chain,
  NULL, &_model_2_m_0_cv1_conv_Conv_output_0_pad_before_layer, AI_STATIC, 
  .outer_elems = 1600, 
  .outer_elems_stride = 32, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_cv1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_2_cv1_conv_Conv_output_0_output, &_model_2_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_cv1_act_Mul_output_0_layer, 156,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_2_cv1_act_Mul_output_0_chain,
  NULL, &_model_2_Split_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_2_cv1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -126, -126, -125, -124, -123, -121, -119, -117, -113, -109, -103, -97, -88, -78, -65, -51, -35, -18, -1, 17, 34, 50, 64, 77, 87, 96, 102, 108, 112, 116, 118, 120, 122, 123, 124, 125, 125, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_2_cv1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_2_cv1_act_Sigmoid_output_0_nl_params_data, _model_2_cv1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_cv1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_2_cv1_act_Sigmoid_output_0_layer, 153,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_2_cv1_act_Sigmoid_output_0_chain,
  NULL, &_model_2_cv1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_2_cv1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_2_cv1_conv_Conv_output_0_weights, &_model_2_cv1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_2_cv1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_2_cv1_conv_Conv_output_0_layer, 150,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_pw_sssa8_ch,
  &_model_2_cv1_conv_Conv_output_0_chain,
  NULL, &_model_2_cv1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(1, 1), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 0, 0, 0, 0), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_1_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_1_conv_Conv_output_0_output, &_model_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_1_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_1_act_Mul_output_0_layer, 147,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_1_act_Mul_output_0_chain,
  NULL, &_model_2_cv1_conv_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_1_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -126, -125, -124, -121, -117, -110, -99, -83, -60, -32, -1, 31, 59, 82, 98, 109, 116, 120, 123, 124, 125, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_1_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_1_act_Sigmoid_output_0_nl_params_data, _model_1_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_1_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_1_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_1_act_Sigmoid_output_0_layer, 144,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_1_act_Sigmoid_output_0_chain,
  NULL, &_model_1_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_1_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_1_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_1_conv_Conv_output_0_weights, &_model_1_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_1_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_1_conv_Conv_output_0_layer, 141,
  CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_sssa8_ch,
  &_model_1_conv_Conv_output_0_chain,
  NULL, &_model_1_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(2, 2), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_SAME, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_0_act_Mul_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 2, &_model_0_conv_Conv_output_0_output, &_model_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_0_act_Mul_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_0_act_Mul_output_0_layer, 138,
  ELTWISE_INTEGER_TYPE, 0x0, NULL,
  eltwise_integer, forward_eltwise_integer_INT8,
  &_model_0_act_Mul_output_0_chain,
  NULL, &_model_1_conv_Conv_output_0_layer, AI_STATIC, 
  .operation = ai_mul_f32, 
  .buffer_operation = ai_mul_buffer_INT8, 
)


AI_STATIC_CONST ai_i8 _model_0_act_Sigmoid_output_0_nl_params_data[] = { -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -128, -127, -127, -127, -127, -126, -126, -125, -125, -124, -123, -121, -119, -117, -113, -109, -105, -99, -91, -83, -72, -60, -47, -32, -17, -1, 16, 31, 46, 59, 71, 82, 90, 98, 104, 108, 112, 116, 118, 120, 122, 123, 124, 124, 125, 125, 126, 126, 126, 126, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
AI_ARRAY_OBJ_DECLARE(
    _model_0_act_Sigmoid_output_0_nl_params, AI_ARRAY_FORMAT_S8,
    _model_0_act_Sigmoid_output_0_nl_params_data, _model_0_act_Sigmoid_output_0_nl_params_data, 256, AI_STATIC_CONST)
AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_0_act_Sigmoid_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_0_act_Sigmoid_output_0_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  _model_0_act_Sigmoid_output_0_layer, 135,
  NL_TYPE, 0x0, NULL,
  nl, forward_nl_integer,
  &_model_0_act_Sigmoid_output_0_chain,
  NULL, &_model_0_act_Mul_output_0_layer, AI_STATIC, 
  .nl_params = &_model_0_act_Sigmoid_output_0_nl_params, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &images_Transpose_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_0_conv_Conv_output_0_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 3, &_model_0_conv_Conv_output_0_weights, &_model_0_conv_Conv_output_0_bias, NULL),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &_model_0_conv_Conv_output_0_scratch0)
)

AI_LAYER_OBJ_DECLARE(
  _model_0_conv_Conv_output_0_layer, 132,
  OPTIMIZED_CONV2D_TYPE, 0x0, NULL,
  conv2d, forward_conv2d_rgb_sssa8_ch,
  &_model_0_conv_Conv_output_0_chain,
  NULL, &_model_0_act_Sigmoid_output_0_layer, AI_STATIC, 
  .groups = 1, 
  .filter_stride = AI_SHAPE_2D_INIT(2, 2), 
  .dilation = AI_SHAPE_2D_INIT(1, 1), 
  .filter_pad = AI_SHAPE_INIT(4, 1, 1, 1, 1), 
  .in_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_SAME, 
  .out_ch_format = AI_LAYER_FORMAT_CHANNEL_LAST_VALID, 
)

AI_TENSOR_CHAIN_OBJ_DECLARE(
  images_Transpose_chain, AI_STATIC_CONST, 4,
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &images_output),
  AI_TENSOR_LIST_OBJ_INIT(AI_FLAG_NONE, 1, &images_Transpose_output),
  AI_TENSOR_LIST_OBJ_EMPTY,
  AI_TENSOR_LIST_OBJ_EMPTY
)

AI_LAYER_OBJ_DECLARE(
  images_Transpose_layer, 2,
  TRANSPOSE_TYPE, 0x0, NULL,
  transpose, forward_transpose,
  &images_Transpose_chain,
  NULL, &_model_0_conv_Conv_output_0_layer, AI_STATIC, 
  .out_mapping = AI_SHAPE_INIT(6, AI_SHAPE_IN_CHANNEL, AI_SHAPE_HEIGHT, AI_SHAPE_CHANNEL, AI_SHAPE_WIDTH, AI_SHAPE_DEPTH, AI_SHAPE_EXTENSION), 
)


#if (AI_TOOLS_API_VERSION < AI_TOOLS_API_VERSION_1_5)

AI_NETWORK_OBJ_DECLARE(
  AI_NET_OBJ_INSTANCE, AI_STATIC,
  AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
    AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 3027856, 1, 1),
    3027856, NULL, NULL),
  AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
    AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 322128, 1, 1),
    322128, NULL, NULL),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_NETWORK_IN_NUM, &images_output),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_NETWORK_OUT_NUM, &output0_QuantizeLinear_Input_Transpose_0_output),
  &images_Transpose_layer, 0xf1ca50be, NULL)

#else

AI_NETWORK_OBJ_DECLARE(
  AI_NET_OBJ_INSTANCE, AI_STATIC,
  AI_BUFFER_ARRAY_OBJ_INIT_STATIC(
  	AI_FLAG_NONE, 1,
    AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
      AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 3027856, 1, 1),
      3027856, NULL, NULL)
  ),
  AI_BUFFER_ARRAY_OBJ_INIT_STATIC(
  	AI_FLAG_NONE, 1,
    AI_BUFFER_INIT(AI_FLAG_NONE,  AI_BUFFER_FORMAT_U8,
      AI_BUFFER_SHAPE_INIT(AI_SHAPE_BCWH, 4, 1, 322128, 1, 1),
      322128, NULL, NULL)
  ),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_NETWORK_IN_NUM, &images_output),
  AI_TENSOR_LIST_IO_OBJ_INIT(AI_FLAG_NONE, AI_NETWORK_OUT_NUM, &output0_QuantizeLinear_Input_Transpose_0_output),
  &images_Transpose_layer, 0xf1ca50be, NULL)

#endif	/*(AI_TOOLS_API_VERSION < AI_TOOLS_API_VERSION_1_5)*/



/******************************************************************************/
AI_DECLARE_STATIC
ai_bool network_configure_activations(
  ai_network* net_ctx, const ai_network_params* params)
{
  AI_ASSERT(net_ctx)

  if (ai_platform_get_activations_map(g_network_activations_map, 1, params)) {
    /* Updating activations (byte) offsets */
    
    images_output_array.data = AI_PTR(g_network_activations_map[0] + 52496);
    images_output_array.data_start = AI_PTR(g_network_activations_map[0] + 52496);
    images_Transpose_output_array.data = AI_PTR(g_network_activations_map[0] + 129296);
    images_Transpose_output_array.data_start = AI_PTR(g_network_activations_map[0] + 129296);
    _model_0_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 52496);
    _model_0_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 52496);
    _model_0_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_0_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_0_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 0);
    _model_0_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 0);
    _model_0_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_0_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 0);
    _model_1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 0);
    _model_1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 6144);
    _model_1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 6144);
    _model_1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 57344);
    _model_1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 57344);
    _model_1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 108544);
    _model_1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 108544);
    _model_2_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 0);
    _model_2_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 0);
    _model_2_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 448);
    _model_2_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 448);
    _model_2_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 51648);
    _model_2_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 51648);
    _model_2_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 102848);
    _model_2_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 102848);
    _model_2_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 0);
    _model_2_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 0);
    _model_2_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 25600);
    _model_2_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 25600);
    _model_2_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 79424);
    _model_2_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 79424);
    _model_2_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 84832);
    _model_2_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 84832);
    _model_2_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 110432);
    _model_2_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 110432);
    _model_2_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 79424);
    _model_2_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 79424);
    _model_2_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 84832);
    _model_2_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 84832);
    _model_2_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 110432);
    _model_2_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 110432);
    _model_2_m_0_Add_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_m_0_Add_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_2_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_2_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_2_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_2_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_2_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_2_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_3_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 97152);
    _model_3_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 97152);
    _model_3_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_3_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_3_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 58368);
    _model_3_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 58368);
    _model_3_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 83968);
    _model_3_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 83968);
    _model_3_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 109568);
    _model_3_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 109568);
    _model_4_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_4_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_4_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 52096);
    _model_4_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 52096);
    _model_4_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 77696);
    _model_4_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 77696);
    _model_4_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 103296);
    _model_4_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 103296);
    _model_4_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 51200);
    _model_4_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 51200);
    _model_4_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 64000);
    _model_4_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 64000);
    _model_4_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 92288);
    _model_4_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 92288);
    _model_4_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 99008);
    _model_4_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 99008);
    _model_4_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 92288);
    _model_4_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 92288);
    _model_4_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 99008);
    _model_4_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 99008);
    _model_4_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_0_Add_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_0_Add_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_m_1_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 105088);
    _model_4_m_1_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 105088);
    _model_4_m_1_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_1_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_1_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 124608);
    _model_4_m_1_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 124608);
    _model_4_m_1_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 105088);
    _model_4_m_1_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 105088);
    _model_4_m_1_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_1_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 111808);
    _model_4_m_1_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 124608);
    _model_4_m_1_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 124608);
    _model_4_m_1_Add_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_m_1_Add_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_4_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_4_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_4_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_4_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_4_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_4_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_4_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_5_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_5_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_5_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_5_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_5_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 86016);
    _model_5_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 86016);
    _model_5_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_5_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_5_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_5_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_6_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_6_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_6_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 78592);
    _model_6_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 78592);
    _model_6_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_6_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_6_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 76800);
    _model_6_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 76800);
    _model_6_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 83200);
    _model_6_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 83200);
    _model_6_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 136320);
    _model_6_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 136320);
    _model_6_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 137216);
    _model_6_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 137216);
    _model_6_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_0_Add_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_0_Add_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_m_1_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 137216);
    _model_6_m_1_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 137216);
    _model_6_m_1_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_1_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_1_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_6_m_1_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_6_m_1_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_6_m_1_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_6_m_1_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_1_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_1_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_m_1_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_6_m_1_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_6_m_1_Add_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_m_1_Add_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_6_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_6_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_6_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_6_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_6_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_7_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_7_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_7_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 159232);
    _model_7_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 159232);
    _model_7_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_7_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_7_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_7_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_7_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_7_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_8_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_8_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 93184);
    _model_8_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 93184);
    _model_8_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 147200);
    _model_8_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 147200);
    _model_8_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 89600);
    _model_8_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 89600);
    _model_8_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 92800);
    _model_8_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 92800);
    _model_8_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 152320);
    _model_8_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 152320);
    _model_8_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 99200);
    _model_8_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 99200);
    _model_8_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 147072);
    _model_8_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 147072);
    _model_8_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 99200);
    _model_8_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 99200);
    _model_8_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_m_0_Add_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_m_0_Add_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 150400);
    _model_8_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 150400);
    _model_8_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_8_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_8_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_9_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 98304);
    _model_9_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 98304);
    _model_9_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_9_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_9_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 144000);
    _model_9_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 144000);
    _model_9_m_MaxPool_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_m_MaxPool_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_m_1_MaxPool_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 99200);
    _model_9_m_1_MaxPool_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 99200);
    _model_9_m_2_MaxPool_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_9_m_2_MaxPool_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_9_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 147200);
    _model_9_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 147200);
    _model_9_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_9_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_9_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_9_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 147200);
    _model_9_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 147200);
    _model_10_Resize_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_10_Resize_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_11_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_11_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_12_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_12_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_12_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_12_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_12_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_12_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_12_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 96000);
    _model_12_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 96000);
    _model_12_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 128000);
    _model_12_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 128000);
    _model_12_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 161920);
    _model_12_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 161920);
    _model_12_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_12_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_12_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 162816);
    _model_12_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162816);
    _model_12_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_12_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_12_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 172800);
    _model_12_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 172800);
    _model_12_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_12_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_12_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_13_Resize_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_13_Resize_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_14_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 217600);
    _model_14_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 217600);
    _model_15_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_15_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_15_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_15_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_15_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 192000);
    _model_15_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 192000);
    _model_15_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 102400);
    _model_15_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 102400);
    _model_15_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 115200);
    _model_15_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 115200);
    _model_15_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 181888);
    _model_15_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 181888);
    _model_15_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_15_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_15_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_15_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_15_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 192000);
    _model_15_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 192000);
    _model_15_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_15_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_15_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 192000);
    _model_15_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 192000);
    _model_15_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 217600);
    _model_15_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 217600);
    _model_16_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_16_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_16_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_16_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_16_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 197376);
    _model_16_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 197376);
    _model_16_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_16_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_16_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_16_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_17_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_17_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_18_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_18_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_18_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_18_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 134400);
    _model_18_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 134400);
    _model_18_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 140800);
    _model_18_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 140800);
    _model_18_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 162816);
    _model_18_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 162816);
    _model_18_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 171136);
    _model_18_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 171136);
    _model_18_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 160000);
    _model_18_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 160000);
    _model_18_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 175616);
    _model_18_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 175616);
    _model_18_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 160000);
    _model_18_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 160000);
    _model_18_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 185600);
    _model_18_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 185600);
    _model_18_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_18_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166400);
    _model_18_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166400);
    _model_19_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_19_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_19_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_19_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_19_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 197632);
    _model_19_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 197632);
    _model_19_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_19_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_19_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 156800);
    _model_19_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 156800);
    _model_20_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_20_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 147200);
    _model_21_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 147200);
    _model_21_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 151296);
    _model_21_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 151296);
    _model_21_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 157696);
    _model_21_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 157696);
    _model_21_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 147200);
    _model_21_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 147200);
    _model_21_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 150400);
    _model_21_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 150400);
    _model_21_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_m_0_cv1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_m_0_cv1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 159872);
    _model_21_m_0_cv1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 159872);
    _model_21_m_0_cv1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 163072);
    _model_21_m_0_cv1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 163072);
    _model_21_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv2_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_m_0_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_m_0_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 159872);
    _model_21_m_0_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 159872);
    _model_21_m_0_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_m_0_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 163072);
    _model_21_m_0_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 163072);
    _model_21_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_cv2_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_cv2_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_21_cv2_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 157696);
    _model_21_cv2_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 157696);
    _model_21_cv2_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_cv2_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_21_cv2_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 185600);
    _model_21_cv2_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 185600);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 192000);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 192000);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_0_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_0_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155200);
    _model_22_cv3_2_cv3_2_0_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155200);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 156800);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 156800);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 192000);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 192000);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155200);
    _model_22_cv3_2_cv3_2_1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155200);
    _model_22_cv3_2_cv3_2_1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 156800);
    _model_22_cv3_2_cv3_2_1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 156800);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153856);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153856);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 192000);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 192000);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155484);
    _model_22_cv2_2_cv2_2_0_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155484);
    _model_22_cv2_2_cv2_2_0_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 157084);
    _model_22_cv2_2_cv2_2_0_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 157084);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 157020);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 157020);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155484);
    _model_22_cv2_2_cv2_2_1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155484);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 157084);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 157084);
    _model_22_Concat_2_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_Concat_2_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153884);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 197632);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 197632);
    _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_0_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_0_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_0_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 187520);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 187520);
    _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155512);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 179200);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 166236);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 166236);
    _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_0_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_0_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 172636);
    _model_22_cv2_1_cv2_1_0_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 172636);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 164828);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 164828);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 173148);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 173148);
    _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 162012);
    _model_22_cv2_1_cv2_1_1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162012);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 168412);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 168412);
    _model_22_Concat_1_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_Concat_1_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155612);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 193088);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 193088);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv3_0_cv3_0_0_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv3_0_cv3_0_0_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 187712);
    _model_22_cv3_0_cv3_0_0_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 187712);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 170432);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 170432);
    _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv3_0_cv3_0_1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 243200);
    _model_22_cv3_0_cv3_0_1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 268800);
    _model_22_cv3_0_cv3_0_1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 268800);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162112);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 193488);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 193488);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 201808);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 201808);
    _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_0_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_0_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 227408);
    _model_22_cv2_0_cv2_0_0_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 227408);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output_array.data = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_pad_before_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 193488);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 193488);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 201808);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 201808);
    _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_1_act_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_1_act_Mul_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 227408);
    _model_22_cv2_0_cv2_0_1_act_Mul_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 227408);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 162512);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 163408);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 163408);
    _model_22_Concat_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 189008);
    _model_22_Concat_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 189008);
    _model_22_Concat_3_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 215008);
    _model_22_Concat_3_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 215008);
    _model_22_Split_output_0_output0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_Split_output_0_output0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_Split_output_0_output1_array.data = AI_PTR(g_network_activations_map[0] + 187200);
    _model_22_Split_output_0_output1_array.data_start = AI_PTR(g_network_activations_map[0] + 187200);
    _model_22_dfl_Reshape_output_0_to_chlast_output_array.data = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_Reshape_output_0_to_chlast_output_array.data_start = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_Reshape_output_0_to_chfirst_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_dfl_Reshape_output_0_to_chfirst_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_output_array.data = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_Reshape_output_0_to_chfirst_0_0__model_22_dfl_Softmax_conversion_output_array.data_start = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_Softmax_output_array.data = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_Softmax_output_array.data_start = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_dfl_Softmax_0_0__model_22_dfl_Transpose_1_output_0_conversion_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_dfl_Transpose_1_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_Transpose_1_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 187728);
    _model_22_dfl_conv_Conv_output_0_scratch0_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_dfl_conv_Conv_output_0_scratch0_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_dfl_conv_Conv_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153664);
    _model_22_dfl_conv_Conv_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153664);
    _model_22_dfl_Reshape_1_output_0_to_chlast_output_array.data = AI_PTR(g_network_activations_map[0] + 155764);
    _model_22_dfl_Reshape_1_output_0_to_chlast_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155764);
    _model_22_dfl_Reshape_1_output_0_to_chfirst_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_dfl_Reshape_1_output_0_to_chfirst_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_Slice_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155700);
    _model_22_Slice_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155700);
    _model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_output_array.data = AI_PTR(g_network_activations_map[0] + 156752);
    _model_22_Slice_output_0_0_1__model_22_Sub_output_0_conversion_output_array.data_start = AI_PTR(g_network_activations_map[0] + 156752);
    _model_22_Slice_1_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155700);
    _model_22_Slice_1_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155700);
    _model_22_Add_1_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_Add_1_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_Sigmoid_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 154652);
    _model_22_Sigmoid_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 154652);
    _model_22_Sub_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 160952);
    _model_22_Sub_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 160952);
    _model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output_array.data = AI_PTR(g_network_activations_map[0] + 155180);
    _model_22_Sub_output_0_0_0__model_22_Add_2_output_0_conversion_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155180);
    _model_22_Sub_1_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 156232);
    _model_22_Sub_1_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 156232);
    _model_22_Add_2_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 157284);
    _model_22_Add_2_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 157284);
    _model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_output_array.data = AI_PTR(g_network_activations_map[0] + 158336);
    _model_22_Add_2_output_0_0_0__model_22_Div_1_output_0_conversion_output_array.data_start = AI_PTR(g_network_activations_map[0] + 158336);
    _model_22_Div_1_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 162536);
    _model_22_Div_1_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 162536);
    _model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_Div_1_output_0_0_0__model_22_Concat_4_output_0_conversion_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    _model_22_Concat_4_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 157284);
    _model_22_Concat_4_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 157284);
    _model_22_Mul_2_output_0_output_array.data = AI_PTR(g_network_activations_map[0] + 155180);
    _model_22_Mul_2_output_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 155180);
    output0_QuantizeLinear_Input_output_array.data = AI_PTR(g_network_activations_map[0] + 157280);
    output0_QuantizeLinear_Input_output_array.data_start = AI_PTR(g_network_activations_map[0] + 157280);
    output0_QuantizeLinear_Input_Transpose_0_output_array.data = AI_PTR(g_network_activations_map[0] + 153600);
    output0_QuantizeLinear_Input_Transpose_0_output_array.data_start = AI_PTR(g_network_activations_map[0] + 153600);
    return true;
  }
  AI_ERROR_TRAP(net_ctx, INIT_FAILED, NETWORK_ACTIVATIONS);
  return false;
}




/******************************************************************************/
AI_DECLARE_STATIC
ai_bool network_configure_weights(
  ai_network* net_ctx, const ai_network_params* params)
{
  AI_ASSERT(net_ctx)

  if (ai_platform_get_weights_map(g_network_weights_map, 1, params)) {
    /* Updating weights (byte) offsets */
    
    _model_22_Constant_11_output_0_3D_array.format |= AI_FMT_FLAG_CONST;
    _model_22_Constant_11_output_0_3D_array.data = AI_PTR(g_network_weights_map[0] + 0);
    _model_22_Constant_11_output_0_3D_array.data_start = AI_PTR(g_network_weights_map[0] + 0);
    _model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D_array.format |= AI_FMT_FLAG_CONST;
    _model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D_array.data = AI_PTR(g_network_weights_map[0] + 4);
    _model_22_Constant_12_output_0_DequantizeLinear_Output_const_3D_array.data_start = AI_PTR(g_network_weights_map[0] + 4);
    _model_22_Constant_10_output_0_DequantizeLinear_Output_const_array.format |= AI_FMT_FLAG_CONST;
    _model_22_Constant_10_output_0_DequantizeLinear_Output_const_array.data = AI_PTR(g_network_weights_map[0] + 532);
    _model_22_Constant_10_output_0_DequantizeLinear_Output_const_array.data_start = AI_PTR(g_network_weights_map[0] + 532);
    _model_0_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_0_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1584);
    _model_0_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1584);
    _model_0_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_0_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2016);
    _model_0_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2016);
    _model_1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2080);
    _model_1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2080);
    _model_1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 6688);
    _model_1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 6688);
    _model_2_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_2_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 6816);
    _model_2_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 6816);
    _model_2_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_2_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 7840);
    _model_2_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 7840);
    _model_2_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_2_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 7968);
    _model_2_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 7968);
    _model_2_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_2_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 7972);
    _model_2_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 7972);
    _model_2_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_2_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 10276);
    _model_2_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 10276);
    _model_2_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_2_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 10340);
    _model_2_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 10340);
    _model_2_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_2_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 12644);
    _model_2_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 12644);
    _model_2_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_2_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 12708);
    _model_2_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 12708);
    _model_2_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_2_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 14244);
    _model_2_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 14244);
    _model_3_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_3_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 14372);
    _model_3_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 14372);
    _model_3_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_3_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 32804);
    _model_3_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 32804);
    _model_4_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_4_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 33060);
    _model_4_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 33060);
    _model_4_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_4_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 37156);
    _model_4_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 37156);
    _model_4_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_4_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 37412);
    _model_4_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 37412);
    _model_4_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 37416);
    _model_4_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 37416);
    _model_4_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 46632);
    _model_4_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 46632);
    _model_4_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 46760);
    _model_4_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 46760);
    _model_4_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 55976);
    _model_4_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 55976);
    _model_4_m_1_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_1_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 56104);
    _model_4_m_1_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 56104);
    _model_4_m_1_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_1_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 65320);
    _model_4_m_1_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 65320);
    _model_4_m_1_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_1_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 65448);
    _model_4_m_1_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 65448);
    _model_4_m_1_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_4_m_1_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 74664);
    _model_4_m_1_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 74664);
    _model_4_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_4_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 74792);
    _model_4_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 74792);
    _model_4_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_4_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 82984);
    _model_4_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 82984);
    _model_5_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_5_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 83240);
    _model_5_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 83240);
    _model_5_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_5_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 156968);
    _model_5_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 156968);
    _model_6_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_6_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 157480);
    _model_6_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 157480);
    _model_6_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_6_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 173864);
    _model_6_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 173864);
    _model_6_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_6_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 174376);
    _model_6_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 174376);
    _model_6_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 174380);
    _model_6_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 174380);
    _model_6_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 211244);
    _model_6_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 211244);
    _model_6_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 211500);
    _model_6_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 211500);
    _model_6_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 248364);
    _model_6_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 248364);
    _model_6_m_1_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_1_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 248620);
    _model_6_m_1_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 248620);
    _model_6_m_1_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_1_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 285484);
    _model_6_m_1_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 285484);
    _model_6_m_1_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_1_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 285740);
    _model_6_m_1_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 285740);
    _model_6_m_1_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_6_m_1_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 322604);
    _model_6_m_1_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 322604);
    _model_6_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_6_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 322860);
    _model_6_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 322860);
    _model_6_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_6_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 355628);
    _model_6_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 355628);
    _model_7_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_7_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 356140);
    _model_7_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 356140);
    _model_7_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_7_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 651052);
    _model_7_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 651052);
    _model_8_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_8_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 652076);
    _model_8_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 652076);
    _model_8_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_8_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 717612);
    _model_8_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 717612);
    _model_8_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_8_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 718636);
    _model_8_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 718636);
    _model_8_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_8_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 718640);
    _model_8_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 718640);
    _model_8_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_8_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 866096);
    _model_8_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 866096);
    _model_8_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_8_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 866608);
    _model_8_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 866608);
    _model_8_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_8_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1014064);
    _model_8_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1014064);
    _model_8_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_8_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1014576);
    _model_8_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1014576);
    _model_8_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_8_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1112880);
    _model_8_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1112880);
    _model_9_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_9_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1113904);
    _model_9_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1113904);
    _model_9_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_9_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1146672);
    _model_9_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1146672);
    _model_9_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_9_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1147184);
    _model_9_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1147184);
    _model_9_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_9_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1278256);
    _model_9_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1278256);
    _model_12_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_12_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1279280);
    _model_12_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1279280);
    _model_12_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_12_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1328432);
    _model_12_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1328432);
    _model_12_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_12_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 1328944);
    _model_12_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 1328944);
    _model_12_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_12_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1328948);
    _model_12_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1328948);
    _model_12_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_12_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1365812);
    _model_12_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1365812);
    _model_12_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_12_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1366068);
    _model_12_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1366068);
    _model_12_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_12_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1402932);
    _model_12_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1402932);
    _model_12_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_12_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1403188);
    _model_12_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1403188);
    _model_12_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_12_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1427764);
    _model_12_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1427764);
    _model_15_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_15_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1428276);
    _model_15_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1428276);
    _model_15_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_15_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1440564);
    _model_15_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1440564);
    _model_15_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_15_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 1440820);
    _model_15_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 1440820);
    _model_15_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_15_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1440824);
    _model_15_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1440824);
    _model_15_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_15_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1450040);
    _model_15_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1450040);
    _model_15_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_15_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1450168);
    _model_15_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1450168);
    _model_15_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_15_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1459384);
    _model_15_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1459384);
    _model_15_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_15_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1459512);
    _model_15_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1459512);
    _model_15_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_15_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1465656);
    _model_15_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1465656);
    _model_16_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_16_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1465912);
    _model_16_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1465912);
    _model_16_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_16_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1502776);
    _model_16_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1502776);
    _model_18_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_18_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1503032);
    _model_18_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1503032);
    _model_18_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_18_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1527608);
    _model_18_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1527608);
    _model_18_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_18_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 1528120);
    _model_18_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 1528120);
    _model_18_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_18_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1528124);
    _model_18_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1528124);
    _model_18_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_18_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1564988);
    _model_18_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1564988);
    _model_18_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_18_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1565244);
    _model_18_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1565244);
    _model_18_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_18_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1602108);
    _model_18_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1602108);
    _model_18_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_18_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1602364);
    _model_18_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1602364);
    _model_18_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_18_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1626940);
    _model_18_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1626940);
    _model_19_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_19_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1627452);
    _model_19_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1627452);
    _model_19_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_19_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1774908);
    _model_19_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1774908);
    _model_21_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_21_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1775420);
    _model_21_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1775420);
    _model_21_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_21_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 1873724);
    _model_21_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 1873724);
    _model_21_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_21_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 1874748);
    _model_21_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 1874748);
    _model_21_m_0_cv1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_21_m_0_cv1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 1874752);
    _model_21_m_0_cv1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 1874752);
    _model_21_m_0_cv1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_21_m_0_cv1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2022208);
    _model_21_m_0_cv1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2022208);
    _model_21_m_0_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_21_m_0_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2022720);
    _model_21_m_0_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2022720);
    _model_21_m_0_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_21_m_0_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2170176);
    _model_21_m_0_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2170176);
    _model_21_cv2_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_21_cv2_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2170688);
    _model_21_cv2_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2170688);
    _model_21_cv2_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_21_cv2_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2268992);
    _model_21_cv2_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2268992);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2270016);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2270016);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2417472);
    _model_22_cv3_2_cv3_2_0_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2417472);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2417728);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2417728);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2454592);
    _model_22_cv3_2_cv3_2_1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2454592);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_2_cv3_2_2_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2454848);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2454848);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_2_cv3_2_2_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2454912);
    _model_22_cv3_2_cv3_2_2_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2454912);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2454916);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2454916);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2602372);
    _model_22_cv2_2_cv2_2_0_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2602372);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2602628);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2602628);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2639492);
    _model_22_cv2_2_cv2_2_1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2639492);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_2_cv2_2_2_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2639748);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2639748);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_2_cv2_2_2_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2643844);
    _model_22_cv2_2_cv2_2_2_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2643844);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2644100);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2644100);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2717828);
    _model_22_cv3_1_cv3_1_0_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2717828);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2718084);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2718084);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2754948);
    _model_22_cv3_1_cv3_1_1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2754948);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_1_cv3_1_2_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2755204);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2755204);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_1_cv3_1_2_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2755268);
    _model_22_cv3_1_cv3_1_2_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2755268);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2755272);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2755272);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2829000);
    _model_22_cv2_1_cv2_1_0_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2829000);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2829256);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2829256);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2866120);
    _model_22_cv2_1_cv2_1_1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2866120);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_1_cv2_1_2_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2866376);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2866376);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_1_cv2_1_2_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2870472);
    _model_22_cv2_1_cv2_1_2_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2870472);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2870728);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2870728);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2907592);
    _model_22_cv3_0_cv3_0_0_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2907592);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2907848);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2907848);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2944712);
    _model_22_cv3_0_cv3_0_1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2944712);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_0_cv3_0_2_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2944968);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2944968);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv3_0_cv3_0_2_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2945032);
    _model_22_cv3_0_cv3_0_2_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2945032);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2945036);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2945036);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 2981900);
    _model_22_cv2_0_cv2_0_0_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 2981900);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 2982156);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 2982156);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 3019020);
    _model_22_cv2_0_cv2_0_1_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 3019020);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_0_cv2_0_2_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 3019276);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 3019276);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_cv2_0_cv2_0_2_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 3023372);
    _model_22_cv2_0_cv2_0_2_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 3023372);
    _model_22_Split_output_0_num_or_size_splits_array.format |= AI_FMT_FLAG_CONST;
    _model_22_Split_output_0_num_or_size_splits_array.data = AI_PTR(g_network_weights_map[0] + 3023628);
    _model_22_Split_output_0_num_or_size_splits_array.data_start = AI_PTR(g_network_weights_map[0] + 3023628);
    _model_22_dfl_conv_Conv_output_0_weights_array.format |= AI_FMT_FLAG_CONST;
    _model_22_dfl_conv_Conv_output_0_weights_array.data = AI_PTR(g_network_weights_map[0] + 3023636);
    _model_22_dfl_conv_Conv_output_0_weights_array.data_start = AI_PTR(g_network_weights_map[0] + 3023636);
    _model_22_dfl_conv_Conv_output_0_bias_array.format |= AI_FMT_FLAG_CONST;
    _model_22_dfl_conv_Conv_output_0_bias_array.data = AI_PTR(g_network_weights_map[0] + 3023652);
    _model_22_dfl_conv_Conv_output_0_bias_array.data_start = AI_PTR(g_network_weights_map[0] + 3023652);
    _model_22_Constant_9_output_0_array.format |= AI_FMT_FLAG_CONST;
    _model_22_Constant_9_output_0_array.data = AI_PTR(g_network_weights_map[0] + 3023656);
    _model_22_Constant_9_output_0_array.data_start = AI_PTR(g_network_weights_map[0] + 3023656);
    return true;
  }
  AI_ERROR_TRAP(net_ctx, INIT_FAILED, NETWORK_WEIGHTS);
  return false;
}


/**  PUBLIC APIs SECTION  *****************************************************/



AI_DEPRECATED
AI_API_ENTRY
ai_bool ai_network_get_info(
  ai_handle network, ai_network_report* report)
{
  ai_network* net_ctx = AI_NETWORK_ACQUIRE_CTX(network);

  if (report && net_ctx)
  {
    ai_network_report r = {
      .model_name        = AI_NETWORK_MODEL_NAME,
      .model_signature   = AI_NETWORK_MODEL_SIGNATURE,
      .model_datetime    = AI_TOOLS_DATE_TIME,
      
      .compile_datetime  = AI_TOOLS_COMPILE_TIME,
      
      .runtime_revision  = ai_platform_runtime_get_revision(),
      .runtime_version   = ai_platform_runtime_get_version(),

      .tool_revision     = AI_TOOLS_REVISION_ID,
      .tool_version      = {AI_TOOLS_VERSION_MAJOR, AI_TOOLS_VERSION_MINOR,
                            AI_TOOLS_VERSION_MICRO, 0x0},
      .tool_api_version  = AI_STRUCT_INIT,

      .api_version            = ai_platform_api_get_version(),
      .interface_api_version  = ai_platform_interface_api_get_version(),
      
      .n_macc            = 255351683,
      .n_inputs          = 0,
      .inputs            = NULL,
      .n_outputs         = 0,
      .outputs           = NULL,
      .params            = AI_STRUCT_INIT,
      .activations       = AI_STRUCT_INIT,
      .n_nodes           = 0,
      .signature         = 0xf1ca50be,
    };

    if (!ai_platform_api_get_network_report(network, &r)) return false;

    *report = r;
    return true;
  }
  return false;
}



AI_API_ENTRY
ai_bool ai_network_get_report(
  ai_handle network, ai_network_report* report)
{
  ai_network* net_ctx = AI_NETWORK_ACQUIRE_CTX(network);

  if (report && net_ctx)
  {
    ai_network_report r = {
      .model_name        = AI_NETWORK_MODEL_NAME,
      .model_signature   = AI_NETWORK_MODEL_SIGNATURE,
      .model_datetime    = AI_TOOLS_DATE_TIME,
      
      .compile_datetime  = AI_TOOLS_COMPILE_TIME,
      
      .runtime_revision  = ai_platform_runtime_get_revision(),
      .runtime_version   = ai_platform_runtime_get_version(),

      .tool_revision     = AI_TOOLS_REVISION_ID,
      .tool_version      = {AI_TOOLS_VERSION_MAJOR, AI_TOOLS_VERSION_MINOR,
                            AI_TOOLS_VERSION_MICRO, 0x0},
      .tool_api_version  = AI_STRUCT_INIT,

      .api_version            = ai_platform_api_get_version(),
      .interface_api_version  = ai_platform_interface_api_get_version(),
      
      .n_macc            = 255351683,
      .n_inputs          = 0,
      .inputs            = NULL,
      .n_outputs         = 0,
      .outputs           = NULL,
      .map_signature     = AI_MAGIC_SIGNATURE,
      .map_weights       = AI_STRUCT_INIT,
      .map_activations   = AI_STRUCT_INIT,
      .n_nodes           = 0,
      .signature         = 0xf1ca50be,
    };

    if (!ai_platform_api_get_network_report(network, &r)) return false;

    *report = r;
    return true;
  }
  return false;
}


AI_API_ENTRY
ai_error ai_network_get_error(ai_handle network)
{
  return ai_platform_network_get_error(network);
}


AI_API_ENTRY
ai_error ai_network_create(
  ai_handle* network, const ai_buffer* network_config)
{
  return ai_platform_network_create(
    network, network_config, 
    AI_CONTEXT_OBJ(&AI_NET_OBJ_INSTANCE),
    AI_TOOLS_API_VERSION_MAJOR, AI_TOOLS_API_VERSION_MINOR, AI_TOOLS_API_VERSION_MICRO);
}


AI_API_ENTRY
ai_error ai_network_create_and_init(
  ai_handle* network, const ai_handle activations[], const ai_handle weights[])
{
  ai_error err;
  ai_network_params params;

  err = ai_network_create(network, AI_NETWORK_DATA_CONFIG);
  if (err.type != AI_ERROR_NONE) {
    return err;
  }
  
  if (ai_network_data_params_get(&params) != true) {
    err = ai_network_get_error(*network);
    return err;
  }
#if defined(AI_NETWORK_DATA_ACTIVATIONS_COUNT)
  /* set the addresses of the activations buffers */
  for (ai_u16 idx=0; activations && idx<params.map_activations.size; idx++) {
    AI_BUFFER_ARRAY_ITEM_SET_ADDRESS(&params.map_activations, idx, activations[idx]);
  }
#endif
#if defined(AI_NETWORK_DATA_WEIGHTS_COUNT)
  /* set the addresses of the weight buffers */
  for (ai_u16 idx=0; weights && idx<params.map_weights.size; idx++) {
    AI_BUFFER_ARRAY_ITEM_SET_ADDRESS(&params.map_weights, idx, weights[idx]);
  }
#endif
  if (ai_network_init(*network, &params) != true) {
    err = ai_network_get_error(*network);
  }
  return err;
}


AI_API_ENTRY
ai_buffer* ai_network_inputs_get(ai_handle network, ai_u16 *n_buffer)
{
  if (network == AI_HANDLE_NULL) {
    network = (ai_handle)&AI_NET_OBJ_INSTANCE;
    AI_NETWORK_OBJ(network)->magic = AI_MAGIC_CONTEXT_TOKEN;
  }
  return ai_platform_inputs_get(network, n_buffer);
}


AI_API_ENTRY
ai_buffer* ai_network_outputs_get(ai_handle network, ai_u16 *n_buffer)
{
  if (network == AI_HANDLE_NULL) {
    network = (ai_handle)&AI_NET_OBJ_INSTANCE;
    AI_NETWORK_OBJ(network)->magic = AI_MAGIC_CONTEXT_TOKEN;
  }
  return ai_platform_outputs_get(network, n_buffer);
}


AI_API_ENTRY
ai_handle ai_network_destroy(ai_handle network)
{
  return ai_platform_network_destroy(network);
}


AI_API_ENTRY
ai_bool ai_network_init(
  ai_handle network, const ai_network_params* params)
{
  ai_network* net_ctx = AI_NETWORK_OBJ(ai_platform_network_init(network, params));
  ai_bool ok = true;

  if (!net_ctx) return false;
  ok &= network_configure_weights(net_ctx, params);
  ok &= network_configure_activations(net_ctx, params);

  ok &= ai_platform_network_post_init(network);

  return ok;
}


AI_API_ENTRY
ai_i32 ai_network_run(
  ai_handle network, const ai_buffer* input, ai_buffer* output)
{
  return ai_platform_network_process(network, input, output);
}


AI_API_ENTRY
ai_i32 ai_network_forward(ai_handle network, const ai_buffer* input)
{
  return ai_platform_network_process(network, input, NULL);
}



#undef AI_NETWORK_MODEL_SIGNATURE
#undef AI_NET_OBJ_INSTANCE
#undef AI_TOOLS_DATE_TIME
#undef AI_TOOLS_COMPILE_TIME

